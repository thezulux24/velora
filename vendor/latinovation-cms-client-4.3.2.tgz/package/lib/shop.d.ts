import { type TrackingContext } from './tracking/core.js';
export interface ShopAddress {
    id: string;
    label?: string;
    recipientName?: string;
    phone?: string;
    address: string;
    city: string;
    department?: string;
    country?: string;
    postalCode?: string;
    notes?: string;
    isDefault?: boolean;
}
/** Dirección para crear o editar (el backend asigna `id`). */
export type ShopAddressInput = Omit<ShopAddress, 'id'> & {
    id?: string;
};
export interface ShopCustomer {
    id: string;
    email: string;
    name: string;
    phone?: string | null;
    documentType?: string | null;
    documentId?: string | null;
    addresses: ShopAddress[];
    acceptsMarketing: boolean;
    createdAt: string;
}
export type ShopOrderStatus = 'PENDING' | 'PENDING_PAYMENT' | 'PAYMENT_FAILED' | 'PROCESSING' | 'PAID_PROCESSING' | 'IN_PRODUCTION' | 'SHIPPED' | 'IN_TRANSIT' | 'OUT_FOR_DELIVERY' | 'DELIVERED'
/** Novedad en la entrega (el envío está en EXCEPTION). */
 | 'SHIPPING_EXCEPTION'
/** Devuelto al remitente (el envío llegó RETURNED). */
 | 'RETURNED' | 'CANCELLED' | 'REFUNDED' | (string & {});
/** Estado normalizado de un envío (docs/LOGISTICS.md §3), igual para Dropi, Interrapidísimo, webhook y manual. */
export type ShipmentStatus = 'DRAFT' | 'CREATED' | 'LABEL_CREATED' | 'PICKED_UP' | 'IN_TRANSIT' | 'OUT_FOR_DELIVERY' | 'DELIVERED' | 'EXCEPTION' | 'RETURNING' | 'RETURNED' | 'CANCELLED';
export declare const SHIPMENT_STATUSES: readonly ShipmentStatus[];
export type ShipmentProvider = 'manual' | 'dropi' | 'interrapidisimo' | 'webhook' | (string & {});
/** Evento de un envío (lo que reporta la transportadora o la tienda). */
export interface ShopShipmentEvent {
    timestamp: string;
    status: ShipmentStatus | (string & {});
    title: string;
    location?: string;
    description?: string;
}
/** Envío público de un pedido (rastreo): sin borradores ni anulados. */
export interface ShopShipment {
    /** Puede no venir en el rastreo público. */
    provider?: ShipmentProvider | null;
    carrier: string | null;
    trackingNumber: string | null;
    trackingUrl: string | null;
    status: ShipmentStatus;
    deliveredAt?: string | null;
    events: ShopShipmentEvent[];
}
type Locale = 'es' | 'en' | (string & {});
/** Etiqueta legible de un estado de envío (`es` por defecto; `en` disponible). Un estado desconocido se devuelve tal cual. */
export declare function shipmentStatusLabel(status: ShipmentStatus | (string & {}) | null | undefined, locale?: Locale): string;
/** Etiqueta legible de un estado de pedido (`es` por defecto). */
export declare function orderStatusLabel(status: ShopOrderStatus | null | undefined, locale?: Locale): string;
/** true si el envío ya no cambia (entregado, devuelto o anulado). */
export declare function isShipmentFinal(status: ShipmentStatus | (string & {}) | null | undefined): boolean;
export type ShopPaymentStatus = 'PENDING' | 'PAID' | 'FAILED' | 'REFUNDED' | (string & {});
export interface ShopOrderLine {
    title: string;
    quantity: number;
    unitPrice?: number;
    imageUrl?: string | null;
    variantLabel?: string | null;
    [k: string]: unknown;
}
export interface ShopOrderSummary {
    orderNumber: string;
    status: ShopOrderStatus;
    paymentStatus: ShopPaymentStatus;
    totalAmount: number;
    currency: string;
    createdAt: string;
    itemsCount: number;
    items: ShopOrderLine[];
    carrierName?: string | null;
    trackingNumber?: string | null;
    trackingUrl?: string | null;
    /** true si el pago está pendiente o fue rechazado y se puede reintentar. */
    canRetry: boolean;
}
export interface ShopTrackingEvent {
    id?: string;
    status: string;
    title?: string;
    description?: string;
    location?: string;
    timestamp?: string;
}
export interface ShopOrder extends ShopOrderSummary {
    trackingEvents: ShopTrackingEvent[];
    shippingAddress?: Partial<ShopAddress> & Record<string, unknown>;
    subtotal?: number;
    shippingCost?: number;
    [k: string]: unknown;
}
export interface ShopPage<T> {
    items: T[];
    total: number;
    page: number;
    totalPages: number;
}
export interface ShopCustomerAccountsConfig {
    enabled: boolean;
    allowGuestCheckout: boolean;
    privacyPolicyUrl?: string | null;
}
export interface ShopPublicConfig {
    enabled?: boolean;
    currency?: string;
    customerAccounts?: ShopCustomerAccountsConfig;
    [k: string]: unknown;
}
export interface ShopCheckoutItem {
    productId: string;
    quantity: number;
    variant?: string;
    variantLabel?: string;
    sku?: string;
    title?: string;
}
export interface ShopCheckoutInput {
    customerName: string;
    customerEmail: string;
    customerPhone?: string;
    documentType?: string;
    documentId?: string;
    shippingAddress: {
        address: string;
        city: string;
        department?: string;
        country?: string;
        postalCode?: string;
        notes?: string;
        [k: string]: unknown;
    };
    billingAddress?: Record<string, unknown>;
    items: ShopCheckoutItem[];
    notes?: string;
    /** wompi, stripe, mercadopago, bold, transfer, cod (por defecto wompi). */
    provider?: string;
    /** Vuelta tras pagar; debe ser un origen permitido del proyecto. */
    redirectUrl?: string;
    shippingZoneId?: string;
    /** Medición (docs/TRACKING.md): event_id y cookies de Meta para la API de conversiones. El cliente lo llena solo. */
    tracking?: TrackingContext;
    [k: string]: unknown;
}
export interface ShopCheckoutResult {
    orderId: string;
    orderNumber: string;
    transactionId?: string;
    reference?: string;
    status: ShopOrderStatus;
    totalAmount: number;
    currency: string;
    checkoutUrl?: string;
    clientSecret?: string;
    redirectUrl?: string | null;
    /** Datos públicos de la pasarela (Bold: `widget` con la firma de integridad del botón embebido). */
    gatewayData?: Record<string, unknown>;
    /** Solo en checkout de invitado: permite vincular la orden al crear la cuenta (se guarda solo). */
    claimToken?: string;
    [k: string]: unknown;
}
/** Resumen público de la orden: sin correo, teléfono, documento ni dirección completa. */
export interface ShopPublicOrder {
    orderNumber: string;
    status: ShopOrderStatus;
    paymentStatus: ShopPaymentStatus;
    totalAmount: number;
    currency: string;
    destinationCity?: string | null;
    items: ShopOrderLine[];
}
export interface ShopConfirmResult {
    orderNumber: string;
    paymentStatus: ShopPaymentStatus;
    gatewayStatus: 'APPROVED' | 'DECLINED' | 'VOIDED' | 'ERROR' | 'PENDING' | (string & {});
    canRetry: boolean;
    order: ShopPublicOrder;
    duplicatePayment?: boolean;
    [k: string]: unknown;
}
/** Lo que trae la URL de retorno de cada pasarela (ver `readPaymentReturn`). */
export interface ShopPaymentReturn {
    provider?: 'wompi' | 'mercadopago' | 'bold' | 'stripe';
    /** Wompi: `?id=`. */
    transactionId?: string;
    /** MercadoPago: `?payment_id=` / `?collection_id=`. */
    paymentId?: string;
    /** Stripe: `?payment_intent=`. */
    paymentIntentId?: string;
    /** MercadoPago `external_reference` (= referencia de la transacción). */
    reference?: string;
    /** Estado informado por la pasarela en la URL: solo orientativo, el backend verifica. */
    status?: string;
}
/** Pedido con pago en curso que este navegador recuerda tras `checkout()`. */
export interface ShopPendingPayment {
    orderNumber: string;
    reference: string;
    provider: string;
    at: number;
}
export interface ShopRetryResult {
    orderNumber: string;
    reference: string;
    totalAmount: number;
    currency: string;
    checkoutUrl: string;
    redirectUrl?: string | null;
}
export interface ShopTrackResult {
    orderNumber: string;
    status: ShopOrderStatus;
    paymentStatus?: ShopPaymentStatus;
    paymentMethod?: string;
    carrierName?: string | null;
    trackingNumber?: string | null;
    trackingUrl?: string | null;
    estimatedDelivery?: string | null;
    trackingEvents?: ShopTrackingEvent[];
    /** v4.3: envíos del pedido (Dropi, Interrapidísimo, webhook o manual), del más antiguo al más reciente. */
    shipments?: ShopShipment[];
    [k: string]: unknown;
}
export interface ShopRegisterInput {
    email: string;
    password: string;
    name: string;
    phone?: string;
    acceptsMarketing?: boolean;
    /** Debe ser true (aceptación de términos y tratamiento de datos). */
    acceptsTerms: true;
    /** Por defecto: las órdenes de invitado de este navegador (guardadas al hacer checkout). */
    claimOrders?: {
        orderNumber: string;
        claimToken: string;
    }[];
}
export interface ShopAuthResult {
    token: string;
    customer: ShopCustomer;
}
export interface ShopProfilePatch {
    name?: string;
    phone?: string;
    documentType?: string;
    documentId?: string;
    acceptsMarketing?: boolean;
}
/** Almacenamiento compatible con localStorage. */
export interface ShopStorage {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
}
export interface ShopClientOptions {
    /** Slug del proyecto en el CMS. */
    slug: string;
    /** URL del CMS (por defecto https://webproai.tech). */
    apiUrl?: string;
    /** Dónde guardar el token (por defecto localStorage si existe; si no, memoria). `null` = solo memoria. */
    storage?: ShopStorage | null;
    fetch?: typeof fetch;
}
export interface ShopClient {
    readonly slug: string;
    readonly apiUrl: string;
    config(): Promise<ShopPublicConfig>;
    checkout(input: ShopCheckoutInput, opts?: {
        saveAddress?: boolean;
    }): Promise<ShopCheckoutResult>;
    confirmPayment(input: {
        transactionId?: string;
        paymentIntentId?: string;
        paymentId?: string;
        reference?: string;
        orderNumber?: string;
    }, opts?: {
        provider?: string;
    }): Promise<ShopConfirmResult>;
    /** Estado del pago para la página de retorno; `reference` es la que devolvió `checkout()`. */
    paymentStatus(orderNumber: string, reference: string): Promise<ShopConfirmResult>;
    /** Confirma (si la URL trae datos de la pasarela) y sondea hasta PAID/FAILED o el tiempo límite. */
    waitForPayment(input: {
        orderNumber: string;
        reference: string;
        provider?: string;
        returnParams?: ShopPaymentReturn;
    }, opts?: {
        intervalMs?: number;
        timeoutMs?: number;
        signal?: AbortSignal;
    }): Promise<ShopConfirmResult>;
    /** Retoma el pago pendiente guardado por `checkout()`; null si no hay ninguno. */
    resumePayment(opts?: {
        search?: string;
        intervalMs?: number;
        timeoutMs?: number;
        signal?: AbortSignal;
    }): Promise<ShopConfirmResult | null>;
    /** Pedido pendiente guardado en este navegador (o null). */
    pendingPayment(): ShopPendingPayment | null;
    clearPendingPayment(): void;
    retryPayment(orderNumber: string, opts?: {
        email?: string;
        redirectUrl?: string;
    }): Promise<ShopRetryResult>;
    track(code: string): Promise<ShopTrackResult>;
    account: {
        register(input: ShopRegisterInput): Promise<ShopAuthResult & {
            claimedOrders: string[];
        }>;
        login(input: {
            email: string;
            password: string;
        }): Promise<ShopAuthResult>;
        /** Cierra la sesión en este navegador (borra el token local). */
        logout(): void;
        /** Invalida todos los tokens de la cuenta (todos los dispositivos) y borra el local. */
        logoutAll(): Promise<void>;
        /** Siempre responde `{ sent: true }`. `resetUrl` por defecto: <origen actual>/cuenta/restablecer. */
        forgotPassword(input: {
            email: string;
            resetUrl?: string;
        }): Promise<{
            sent: boolean;
        }>;
        resetPassword(input: {
            token: string;
            password: string;
        }): Promise<ShopAuthResult>;
        me(): Promise<ShopCustomer>;
        update(patch: ShopProfilePatch): Promise<ShopCustomer>;
        changePassword(input: {
            currentPassword: string;
            newPassword: string;
        }): Promise<ShopAuthResult>;
        addresses: {
            list(): Promise<ShopAddress[]>;
            add(address: ShopAddressInput): Promise<ShopAddress[]>;
            update(id: string, patch: Partial<ShopAddressInput>): Promise<ShopAddress[]>;
            remove(id: string): Promise<ShopAddress[]>;
        };
        orders: {
            list(opts?: {
                page?: number;
                limit?: number;
            }): Promise<ShopPage<ShopOrderSummary>>;
            get(orderNumber: string): Promise<ShopOrder>;
        };
        deleteAccount(input: {
            password: string;
        }): Promise<{
            deleted: boolean;
        }>;
    };
    getToken(): string | null;
    setToken(token: string | null): void;
    /** Avisa cuando el token cambia (login, logout o 401 por sesión vencida). Devuelve la función para desuscribirse. */
    onTokenChange(listener: (token: string | null) => void): () => void;
}
/** Error de la tienda con el `code` del backend (EMAIL_TAKEN, INVALID_CREDENTIALS, PAYMENT_FAILED, OUT_OF_STOCK…). */
export declare class ShopError extends Error {
    status: number;
    code: string;
    /** Cuerpo completo de la respuesta (p. ej. `canRetry`, `orderNumber`, lista de agotados). */
    body: Record<string, unknown>;
    constructor(message: string, status: number, code: string, body?: Record<string, unknown>);
}
/**
 * Lee los parámetros que cada pasarela añade al volver al sitio:
 * Wompi `?id=…`, MercadoPago `?payment_id=…&status=…&external_reference=…`,
 * Stripe `?payment_intent=…&redirect_status=…`, Bold `?bold-order-id=…&bold-tx-status=…`.
 */
export declare function readPaymentReturn(search?: string): ShopPaymentReturn;
export declare function createShopClient(opts: ShopClientOptions): ShopClient;
export type Customer = ShopCustomer;
export type Address = ShopAddress;
export type OrderSummary = ShopOrderSummary;
export type Shipment = ShopShipment;
export {};
