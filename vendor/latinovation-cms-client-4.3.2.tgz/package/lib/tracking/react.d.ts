import { type StandardEvent, type TrackingConfig, type TrackingHandle, type TrackingScript, type TrackParams } from './core.js';
export interface CmsTrackingProps {
    /** Configuración explícita; por defecto, la de `<CmsProvider>` (global.site.tracking). */
    config?: TrackingConfig | null;
    /** Slug del proyecto; por defecto, el de `<CmsProvider>`. */
    slug?: string;
    /** URL del CMS para el aviso de "probar conexión" en el portal. Por defecto, la del provider. */
    apiBase?: string;
    /** Ruta actual: cada cambio emite page_view. Sin ella, se emite uno al montar. */
    pathname?: string;
    /** false: no emite page_view (lo hace el sitio). */
    pageViews?: boolean;
    /** Cargador propio (p. ej. next/script). Por defecto inserta <script async> en <head>. */
    loadScripts?: (scripts: TrackingScript[], handle: TrackingHandle) => void;
    /** Sin medición (por defecto: dentro del editor o en vista previa). */
    disabled?: boolean;
}
/** Instala píxeles y etiquetas del sitio. No pinta nada. */
export declare function CmsTracking(props: CmsTrackingProps): null;
/**
 * Despachador de eventos estándar. Devuelve el event_id (pásalo como `tracking.eventId` al backend
 * para deduplicar con la API de conversiones). Fuera de `<CmsTracking>` no hace nada.
 */
export declare function useTrack(): (event: StandardEvent, params?: TrackParams) => string;
