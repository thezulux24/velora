'use client';

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { DeliveryPayload } from '../types.js';
import { normalizeBaseUrl, normalizePageSlug, pageSlugFromPath, tryFetchDelivery } from '../delivery.js';
import {
  applyArrayChange,
  applyCollectionItemChange,
  applyElementStyleChange,
  applyFieldChange,
  applyGlobalChange,
  applyLiveState,
  applyNavChange,
  applySectionStyleChange,
  createLivePreviewBridge,
  readPreviewParams,
  type CanvasAction,
  type LivePreviewBridge,
  type LivePreviewStateMessage,
} from '../live.js';
import { createBuilderRuntime, tagSectionElements, type BuilderRuntime, type LocalChange, type SelectedElement } from '../dom.js';
import { BUILDER_CSS } from '../builder-css.js';
import { designSystemFontFaces, designSystemFontLinks, designSystemGlobalCss, designSystemToCss } from '../design-system.js';
import { sanitizeCss } from '../css.js';
import { CmsContext, type CmsActions, type CmsContextValue } from './context.js';
import { ElementStudio } from './studio.js';

export interface LivePreviewOptions {
  /** Slug del proyecto en el CMS. */
  slug: string;
  /** URL del CMS (por defecto https://webproai.tech). Su origen es el único aceptado en postMessage. */
  cmsUrl?: string;
  /** Página del CMS que se muestra ('/', '/producto'…). Si falta, se deduce de `pathname`. */
  pageSlug?: string;
  /** Ruta actual del sitio (p. ej. `usePathname()` de Next); se traduce con `pageSlugFromPath`. */
  pathname?: string;
  /** Prefijo del sitio a quitar de la ruta (p. ej. "/site/demo"). */
  basePath?: string;
  /** Token de vista previa (si no, se lee de `?previewToken=`). */
  previewToken?: string;
  /** Orígenes extra del portal (ej. http://localhost:3005). */
  allowedOrigins?: string[];
  /** Registrar una visita (POST /api/public/analytics/:slug/track) fuera del editor. Por defecto true. */
  trackPageview?: boolean;
  /** Emitir `--cms-*` del design system, fuentes y `globalCss`. Por defecto true. */
  designSystem?: boolean;
  /** Barra de estilos por elemento en el editor. Por defecto true. */
  elementStudio?: boolean;
  fetch?: typeof fetch;
}

/**
 * En vista previa o en el editor, el HTML del servidor trae lo publicado y el borrador llega después
 * por fetch o por el portal: sin esto se veía la versión vieja y luego el salto. Este script corre antes
 * de pintar las secciones y las oculta hasta que llega el borrador (o 3 s como máximo).
 */
const PREVIEW_GATE_ID = 'cms-preview-gate';
const PREVIEW_GATE_SCRIPT = `(function(){try{var q=new URLSearchParams(location.search),p=q.get('preview'),b=q.get('builder');if(p==='1'||p==='true'||b==='1'||b==='true'){var s=document.createElement('style');s.id='${PREVIEW_GATE_ID}';s.textContent='[data-section-key]{visibility:hidden!important}';document.head.appendChild(s);setTimeout(function(){s.remove()},3000)}}catch(e){}})()`;

function openPreviewGate() {
  if (typeof document === 'undefined') return;
  // un cuadro después de aplicar el borrador, para que React ya lo haya pintado
  requestAnimationFrame(() => document.getElementById(PREVIEW_GATE_ID)?.remove());
}

/** Estado del sitio con vista previa en vivo. Úsalo directo o vía <CmsProvider>. */
export function useLivePreview(initial: DeliveryPayload, opts: LivePreviewOptions): CmsContextValue {
  const base = normalizeBaseUrl(opts.cmsUrl);
  const originsKey = (opts.allowedOrigins || []).join(',');
  const [payload, setPayload] = useState<DeliveryPayload>(initial);
  const [mode, setMode] = useState({ isBuilder: false, isPreview: false });
  const [clientPath, setClientPath] = useState<string | undefined>(undefined);
  const [activePage, setActivePageState] = useState<string>('');
  const [selectedKey, setSelectedKey] = useState('');
  const [selectedElement, setSelectedElement] = useState<SelectedElement | null>(null);
  const liveRef = useRef<LivePreviewStateMessage | null>(null);
  const bridgeRef = useRef<LivePreviewBridge | null>(null);
  const runtimeRef = useRef<BuilderRuntime | null>(null);
  const [bridgeState, setBridgeState] = useState<LivePreviewBridge | null>(null);

  const pageSlug = normalizePageSlug(activePage || opts.pageSlug || pageSlugFromPath(opts.pathname ?? clientPath ?? '/', payload, opts.basePath));
  const pageRef = useRef(pageSlug);
  pageRef.current = pageSlug;

  useEffect(() => {
    setPayload(liveRef.current ? applyLiveState(initial, liveRef.current, pageRef.current) : initial);
  }, [initial]);

  useEffect(() => {
    setClientPath(window.location.pathname);
    const params = readPreviewParams();
    const embedded = window.parent !== window;
    setMode({ isBuilder: params.builder && embedded, isPreview: params.preview });
    const token = opts.previewToken || params.previewToken;
    if (params.preview) {
      tryFetchDelivery({ slug: opts.slug, baseUrl: base, preview: true, previewToken: token, fetch: opts.fetch })
        .then((draft) => {
          if (draft) setPayload(liveRef.current ? applyLiveState(draft, liveRef.current, pageRef.current) : draft);
        })
        .finally(openPreviewGate);
    } else if (opts.trackPageview !== false) {
      (opts.fetch || fetch)(`${base}/api/public/analytics/${encodeURIComponent(opts.slug)}/track`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ event: 'pageview', path: window.location.pathname }),
        keepalive: true,
      }).catch(() => {});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [opts.slug, base]);

  useEffect(() => {
    const bridge = createLivePreviewBridge({
      cmsUrl: base,
      allowedOrigins: opts.allowedOrigins,
      onState: (msg) => {
        liveRef.current = msg;
        setPayload((prev) => applyLiveState(prev, msg, pageRef.current));
        openPreviewGate();
        if (msg.selectedSectionKey) {
          setSelectedKey(msg.selectedSectionKey);
          runtimeRef.current?.selectSection(msg.selectedSectionKey);
        }
      },
      onSelectElement: (id) => {
        const sel = runtimeRef.current?.selectElement(id, true);
        if (sel) {
          setSelectedKey(sel.sectionKey);
          document.querySelector(`[data-el-id="${id.replace(/["\\]/g, '\\$&')}"]`)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      },
    });
    bridgeRef.current = bridge;
    setBridgeState(bridge);
    return () => bridge.destroy();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [base, originsKey]);

  const applyLocal = useCallback((change: LocalChange) => {
    setPayload((prev) => {
      switch (change.kind) {
        case 'field':
          return applyFieldChange(prev, pageRef.current, change.section, change.path, change.value);
        case 'global':
          return applyGlobalChange(prev, change.fieldKey, change.value);
        case 'nav':
          return applyNavChange(prev, change.target, change.value);
        case 'item':
          return applyCollectionItemChange(prev, change.collection, change.itemId, change.fieldKey, change.value);
        default:
          return prev;
      }
    });
  }, []);

  // Runtime del lienzo (solo editor)
  useEffect(() => {
    if (!mode.isBuilder || !bridgeRef.current) return;
    const html = document.documentElement;
    html.setAttribute('data-cms-builder', '');
    let style = document.getElementById('cms-builder-css') as HTMLStyleElement | null;
    if (!style) {
      style = document.createElement('style');
      style.id = 'cms-builder-css';
      style.textContent = BUILDER_CSS;
      document.head.appendChild(style);
    }
    const runtime = createBuilderRuntime({
      bridge: bridgeRef.current,
      onLocalChange: applyLocal,
      onSelectSection: (key) => setSelectedKey(key),
      onSelectElement: (sel) => setSelectedElement(sel),
    });
    runtimeRef.current = runtime;
    return () => {
      runtime.destroy();
      runtimeRef.current = null;
      html.removeAttribute('data-cms-builder');
      style?.remove();
    };
  }, [mode.isBuilder, base, originsKey, applyLocal]);

  // Sitio público: etiquetar solo secciones con estilos por elemento posicionales
  useEffect(() => {
    if (mode.isBuilder) {
      runtimeRef.current?.retag();
      return;
    }
    const t = setTimeout(() => tagSectionElements(document, { isBuilder: false }), 0);
    return () => clearTimeout(t);
  }, [payload, mode.isBuilder, pageSlug]);

  const post = useCallback((action: CanvasAction, data?: Record<string, unknown>) => bridgeRef.current?.post(action, data), []);
  const selectSection = useCallback((k: string, id?: string) => {
    setSelectedKey(k);
    runtimeRef.current?.selectSection(k);
    bridgeRef.current?.selectSection(k, id);
  }, []);
  const commitField = useCallback(
    (k: string, id: string, f: string, v: unknown) => {
      bridgeRef.current?.commitField(k, id, f, v);
      applyLocal({ kind: 'field', section: { key: k, id }, path: f, value: v });
    },
    [applyLocal],
  );
  const commitWidgetField = useCallback(
    (k: string, id: string, i: number, f: string, v: unknown) => {
      bridgeRef.current?.commitWidgetField(k, id, i, f, v);
      applyLocal({ kind: 'field', section: { key: k, id }, path: `widgets.${i}.${f}`, value: v });
    },
    [applyLocal],
  );
  const commitGlobal = useCallback(
    (f: string, v: unknown) => {
      bridgeRef.current?.commitGlobal(f, v);
      applyLocal({ kind: 'global', fieldKey: f, value: v });
    },
    [applyLocal],
  );
  const setActivePage = useCallback((slug: string) => setActivePageState(normalizePageSlug(slug)), []);

  const actions = useMemo<CmsActions>(
    () => ({
      field: (s, path, value) => {
        const w = path.match(/^widgets\.(\d+)\.([^.]+)$/);
        if (w) bridgeRef.current?.commitWidgetField(s.key, s.id, Number(w[1]), w[2], value);
        else bridgeRef.current?.commitField(s.key, s.id, path, value);
        applyLocal({ kind: 'field', section: s, path, value });
      },
      arrayItem: (s, path, index, op) => {
        bridgeRef.current?.arrayItemAction(s.key, s.id, path, index, op);
        setPayload((prev) => applyArrayChange(prev, pageRef.current, s, path, index, op));
      },
      focusField: (s, path, type) => bridgeRef.current?.focusField(s.key, s.id, path, type),
      elementStyle: (s, elementId, patch) => {
        bridgeRef.current?.elementStyleChange(s.key, s.id, elementId, patch);
        setPayload((prev) => applyElementStyleChange(prev, pageRef.current, s, elementId, patch));
      },
      sectionStyle: (s, patch) => {
        bridgeRef.current?.sectionStyleChange(s.key, s.id, patch);
        setPayload((prev) => applySectionStyleChange(prev, pageRef.current, s, patch));
      },
      global: (fieldKey, value) => commitGlobal(fieldKey, value),
      nav: (target, value) => {
        bridgeRef.current?.commitNav(target, value);
        applyLocal({ kind: 'nav', target, value });
      },
      item: (collection, itemId, fieldKey, value) => {
        bridgeRef.current?.commitCollectionItem(collection, itemId, fieldKey, value);
        applyLocal({ kind: 'item', collection, itemId, fieldKey, value });
      },
    }),
    [applyLocal, commitGlobal],
  );

  return useMemo(
    () => ({
      payload,
      isBuilder: mode.isBuilder,
      isPreview: mode.isPreview,
      pageSlug,
      slug: opts.slug,
      cmsUrl: base,
      selectedKey,
      selectedElement,
      setSelectedElement: (sel: SelectedElement | null) => {
        setSelectedElement(sel);
        if (!sel) runtimeRef.current?.selectElement(null);
      },
      setActivePage,
      bridge: bridgeState,
      actions,
      selectSection,
      commitField,
      commitWidgetField,
      commitGlobal,
      post,
    }),
    [payload, mode, pageSlug, opts.slug, base, bridgeState, selectedKey, selectedElement, setActivePage, actions, selectSection, commitField, commitWidgetField, commitGlobal, post],
  );
}

/** `--cms-*` del design system, enlaces de Google Fonts, `@font-face` propios y `globalCss` saneado. */
export function CmsDesignSystem({ global }: { global: Record<string, any> | undefined }) {
  const css = useMemo(() => {
    const parts = [designSystemToCss(global, ':root'), designSystemFontFaces(global), sanitizeCss(designSystemGlobalCss(global))];
    return parts.filter(Boolean).join('\n');
  }, [global]);
  const links = useMemo(() => designSystemFontLinks(global), [global]);
  return (
    <>
      {links.map((href) => (
        <link key={href} rel="stylesheet" href={href} data-cms-font="" />
      ))}
      <style data-cms-design-system="" dangerouslySetInnerHTML={{ __html: css }} />
    </>
  );
}

export function CmsProvider({ initial, children, ...opts }: LivePreviewOptions & { initial: DeliveryPayload; children: React.ReactNode }) {
  const value = useLivePreview(initial, opts);
  return (
    <CmsContext.Provider value={value}>
      <script id="cms-preview-gate-init" dangerouslySetInnerHTML={{ __html: PREVIEW_GATE_SCRIPT }} />
      {opts.designSystem !== false ? <CmsDesignSystem global={value.payload?.global} /> : null}
      {children}
      {value.isBuilder && opts.elementStudio !== false ? <ElementStudio /> : null}
    </CmsContext.Provider>
  );
}
