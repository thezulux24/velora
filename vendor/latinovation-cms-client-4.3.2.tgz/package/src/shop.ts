/**
 * Cliente de tienda para storefronts headless (docs/SHOP-ACCOUNTS.md): checkout, confirmación y
 * reintento de pago, rastreo y cuentas de cliente por proyecto.
 *
 *   const shop = createShopClient({ slug: 'arsenal' });
 *   const { customerAccounts } = await shop.config();
 *   await shop.account.login({ email, password });           // guarda el token en localStorage
 *   const order = await shop.checkout(input, { saveAddress: true }); // con Bearer si hay sesión
 *   location.href = order.checkoutUrl!;
 *   // al volver de Wompi (siempre, aprobado o no):
 *   const r = await shop.confirmPayment({ transactionId, orderNumber });
 *   if (r.canRetry) location.href = (await shop.retryPayment(r.orderNumber, { email })).checkoutUrl;
 *
 * Cualquier pasarela con redirección (Wompi, MercadoPago, Bold; docs/PAYMENTS.md): `checkout()` guarda
 * el pedido pendiente y, en la página de retorno, `resumePayment()` lee los parámetros que añade la
 * pasarela, confirma con el backend y sondea hasta que el pago deja de estar pendiente:
 *   const r = await shop.resumePayment();            // null si no hay pago pendiente en este navegador
 *   if (r?.paymentStatus === 'PAID') mostrarGracias(r.orderNumber);
 *
 * El token de cliente solo sirve en /api/shop/:slug/account y en el checkout de esa tienda: nunca en /admin.
 *
 * Rastreo (v4.3, docs/LOGISTICS.md): `track(code)` trae `shipments[]` con estado normalizado y eventos;
 *   const t = await shop.track('ORD-…');
 *   t.shipments?.map((s) => `${s.carrier} ${s.trackingNumber}: ${shipmentStatusLabel(s.status)}`);
 */
import { normalizeBaseUrl } from './delivery.js';
import { orderTrackParams, purchaseOnPlacement, track, trackingContext, type TrackingContext } from './tracking/core.js';

/* ------------------------------------------------------------------ */
/* Tipos                                                               */
/* ------------------------------------------------------------------ */

export interface ShopAddress {
  id: string;
  label?: string;
  recipientName?: string;
  phone?: string;
  address: string;
  city: string;
  department?: string;
  country?: string;
  postalCode?: string;
  notes?: string;
  isDefault?: boolean;
}

/** Dirección para crear o editar (el backend asigna `id`). */
export type ShopAddressInput = Omit<ShopAddress, 'id'> & { id?: string };

export interface ShopCustomer {
  id: string;
  email: string;
  name: string;
  phone?: string | null;
  documentType?: string | null;
  documentId?: string | null;
  addresses: ShopAddress[];
  acceptsMarketing: boolean;
  createdAt: string;
}

export type ShopOrderStatus =
  | 'PENDING'
  | 'PENDING_PAYMENT'
  | 'PAYMENT_FAILED'
  | 'PROCESSING'
  | 'PAID_PROCESSING'
  | 'IN_PRODUCTION'
  | 'SHIPPED'
  | 'IN_TRANSIT'
  | 'OUT_FOR_DELIVERY'
  | 'DELIVERED'
  /** Novedad en la entrega (el envío está en EXCEPTION). */
  | 'SHIPPING_EXCEPTION'
  /** Devuelto al remitente (el envío llegó RETURNED). */
  | 'RETURNED'
  | 'CANCELLED'
  | 'REFUNDED'
  | (string & {});

/** Estado normalizado de un envío (docs/LOGISTICS.md §3), igual para Dropi, Interrapidísimo, webhook y manual. */
export type ShipmentStatus =
  | 'DRAFT'
  | 'CREATED'
  | 'LABEL_CREATED'
  | 'PICKED_UP'
  | 'IN_TRANSIT'
  | 'OUT_FOR_DELIVERY'
  | 'DELIVERED'
  | 'EXCEPTION'
  | 'RETURNING'
  | 'RETURNED'
  | 'CANCELLED';

export const SHIPMENT_STATUSES: readonly ShipmentStatus[] = [
  'DRAFT',
  'CREATED',
  'LABEL_CREATED',
  'PICKED_UP',
  'IN_TRANSIT',
  'OUT_FOR_DELIVERY',
  'DELIVERED',
  'EXCEPTION',
  'RETURNING',
  'RETURNED',
  'CANCELLED',
];

export type ShipmentProvider = 'manual' | 'dropi' | 'interrapidisimo' | 'webhook' | (string & {});

/** Evento de un envío (lo que reporta la transportadora o la tienda). */
export interface ShopShipmentEvent {
  timestamp: string;
  status: ShipmentStatus | (string & {});
  title: string;
  location?: string;
  description?: string;
}

/** Envío público de un pedido (rastreo): sin borradores ni anulados. */
export interface ShopShipment {
  /** Puede no venir en el rastreo público. */
  provider?: ShipmentProvider | null;
  carrier: string | null;
  trackingNumber: string | null;
  trackingUrl: string | null;
  status: ShipmentStatus;
  deliveredAt?: string | null;
  events: ShopShipmentEvent[];
}

type Locale = 'es' | 'en' | (string & {});

const SHIPMENT_LABELS: Record<'es' | 'en', Record<ShipmentStatus, string>> = {
  es: {
    DRAFT: 'Borrador de envío',
    CREATED: 'Envío creado',
    LABEL_CREATED: 'Guía generada',
    PICKED_UP: 'Recogido por la transportadora',
    IN_TRANSIT: 'En tránsito',
    OUT_FOR_DELIVERY: 'En reparto',
    DELIVERED: 'Entregado',
    EXCEPTION: 'Novedad en la entrega',
    RETURNING: 'En devolución',
    RETURNED: 'Devuelto al remitente',
    CANCELLED: 'Envío anulado',
  },
  en: {
    DRAFT: 'Shipment draft',
    CREATED: 'Shipment created',
    LABEL_CREATED: 'Label created',
    PICKED_UP: 'Picked up by carrier',
    IN_TRANSIT: 'In transit',
    OUT_FOR_DELIVERY: 'Out for delivery',
    DELIVERED: 'Delivered',
    EXCEPTION: 'Delivery issue',
    RETURNING: 'Returning to sender',
    RETURNED: 'Returned to sender',
    CANCELLED: 'Shipment cancelled',
  },
};

const ORDER_LABELS: Record<'es' | 'en', Record<string, string>> = {
  es: {
    PENDING: 'Pendiente',
    PENDING_PAYMENT: 'Esperando pago',
    PAYMENT_FAILED: 'Pago rechazado',
    PROCESSING: 'En preparación',
    PAID_PROCESSING: 'Pagado, en preparación',
    IN_PRODUCTION: 'En producción',
    SHIPPED: 'Despachado',
    IN_TRANSIT: 'En tránsito',
    OUT_FOR_DELIVERY: 'En reparto',
    DELIVERED: 'Entregado',
    SHIPPING_EXCEPTION: 'Novedad en la entrega',
    RETURNED: 'Devuelto',
    CANCELLED: 'Cancelado',
    REFUNDED: 'Reembolsado',
  },
  en: {
    PENDING: 'Pending',
    PENDING_PAYMENT: 'Awaiting payment',
    PAYMENT_FAILED: 'Payment declined',
    PROCESSING: 'Processing',
    PAID_PROCESSING: 'Paid, processing',
    IN_PRODUCTION: 'In production',
    SHIPPED: 'Shipped',
    IN_TRANSIT: 'In transit',
    OUT_FOR_DELIVERY: 'Out for delivery',
    DELIVERED: 'Delivered',
    SHIPPING_EXCEPTION: 'Delivery issue',
    RETURNED: 'Returned',
    CANCELLED: 'Cancelled',
    REFUNDED: 'Refunded',
  },
};

const labelsFor = <T>(table: Record<'es' | 'en', T>, locale: Locale): T => (String(locale).toLowerCase().startsWith('en') ? table.en : table.es);

/** Etiqueta legible de un estado de envío (`es` por defecto; `en` disponible). Un estado desconocido se devuelve tal cual. */
export function shipmentStatusLabel(status: ShipmentStatus | (string & {}) | null | undefined, locale: Locale = 'es'): string {
  if (!status) return '';
  const key = String(status).trim().toUpperCase() as ShipmentStatus;
  return labelsFor(SHIPMENT_LABELS, locale)[key] ?? String(status);
}

/** Etiqueta legible de un estado de pedido (`es` por defecto). */
export function orderStatusLabel(status: ShopOrderStatus | null | undefined, locale: Locale = 'es'): string {
  if (!status) return '';
  return labelsFor(ORDER_LABELS, locale)[String(status).trim().toUpperCase()] ?? String(status);
}

/** true si el envío ya no cambia (entregado, devuelto o anulado). */
export function isShipmentFinal(status: ShipmentStatus | (string & {}) | null | undefined): boolean {
  return status === 'DELIVERED' || status === 'RETURNED' || status === 'CANCELLED';
}

export type ShopPaymentStatus = 'PENDING' | 'PAID' | 'FAILED' | 'REFUNDED' | (string & {});

export interface ShopOrderLine {
  title: string;
  quantity: number;
  unitPrice?: number;
  imageUrl?: string | null;
  variantLabel?: string | null;
  [k: string]: unknown;
}

export interface ShopOrderSummary {
  orderNumber: string;
  status: ShopOrderStatus;
  paymentStatus: ShopPaymentStatus;
  totalAmount: number;
  currency: string;
  createdAt: string;
  itemsCount: number;
  items: ShopOrderLine[];
  carrierName?: string | null;
  trackingNumber?: string | null;
  trackingUrl?: string | null;
  /** true si el pago está pendiente o fue rechazado y se puede reintentar. */
  canRetry: boolean;
}

export interface ShopTrackingEvent {
  id?: string;
  status: string;
  title?: string;
  description?: string;
  location?: string;
  timestamp?: string;
}

export interface ShopOrder extends ShopOrderSummary {
  trackingEvents: ShopTrackingEvent[];
  shippingAddress?: Partial<ShopAddress> & Record<string, unknown>;
  subtotal?: number;
  shippingCost?: number;
  [k: string]: unknown;
}

export interface ShopPage<T> {
  items: T[];
  total: number;
  page: number;
  totalPages: number;
}

export interface ShopCustomerAccountsConfig {
  enabled: boolean;
  allowGuestCheckout: boolean;
  privacyPolicyUrl?: string | null;
}

export interface ShopPublicConfig {
  enabled?: boolean;
  currency?: string;
  customerAccounts?: ShopCustomerAccountsConfig;
  [k: string]: unknown;
}

export interface ShopCheckoutItem {
  productId: string;
  quantity: number;
  variant?: string;
  variantLabel?: string;
  sku?: string;
  title?: string;
}

export interface ShopCheckoutInput {
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  documentType?: string;
  documentId?: string;
  shippingAddress: { address: string; city: string; department?: string; country?: string; postalCode?: string; notes?: string; [k: string]: unknown };
  billingAddress?: Record<string, unknown>;
  items: ShopCheckoutItem[];
  notes?: string;
  /** wompi, stripe, mercadopago, bold, transfer, cod (por defecto wompi). */
  provider?: string;
  /** Vuelta tras pagar; debe ser un origen permitido del proyecto. */
  redirectUrl?: string;
  shippingZoneId?: string;
  /** Medición (docs/TRACKING.md): event_id y cookies de Meta para la API de conversiones. El cliente lo llena solo. */
  tracking?: TrackingContext;
  [k: string]: unknown;
}

export interface ShopCheckoutResult {
  orderId: string;
  orderNumber: string;
  transactionId?: string;
  reference?: string;
  status: ShopOrderStatus;
  totalAmount: number;
  currency: string;
  checkoutUrl?: string;
  clientSecret?: string;
  redirectUrl?: string | null;
  /** Datos públicos de la pasarela (Bold: `widget` con la firma de integridad del botón embebido). */
  gatewayData?: Record<string, unknown>;
  /** Solo en checkout de invitado: permite vincular la orden al crear la cuenta (se guarda solo). */
  claimToken?: string;
  [k: string]: unknown;
}

/** Resumen público de la orden: sin correo, teléfono, documento ni dirección completa. */
export interface ShopPublicOrder {
  orderNumber: string;
  status: ShopOrderStatus;
  paymentStatus: ShopPaymentStatus;
  totalAmount: number;
  currency: string;
  destinationCity?: string | null;
  items: ShopOrderLine[];
}

export interface ShopConfirmResult {
  orderNumber: string;
  paymentStatus: ShopPaymentStatus;
  gatewayStatus: 'APPROVED' | 'DECLINED' | 'VOIDED' | 'ERROR' | 'PENDING' | (string & {});
  canRetry: boolean;
  order: ShopPublicOrder;
  duplicatePayment?: boolean;
  [k: string]: unknown;
}

/** Lo que trae la URL de retorno de cada pasarela (ver `readPaymentReturn`). */
export interface ShopPaymentReturn {
  provider?: 'wompi' | 'mercadopago' | 'bold' | 'stripe';
  /** Wompi: `?id=`. */
  transactionId?: string;
  /** MercadoPago: `?payment_id=` / `?collection_id=`. */
  paymentId?: string;
  /** Stripe: `?payment_intent=`. */
  paymentIntentId?: string;
  /** MercadoPago `external_reference` (= referencia de la transacción). */
  reference?: string;
  /** Estado informado por la pasarela en la URL: solo orientativo, el backend verifica. */
  status?: string;
}

/** Pedido con pago en curso que este navegador recuerda tras `checkout()`. */
export interface ShopPendingPayment {
  orderNumber: string;
  reference: string;
  provider: string;
  at: number;
}

export interface ShopRetryResult {
  orderNumber: string;
  reference: string;
  totalAmount: number;
  currency: string;
  checkoutUrl: string;
  redirectUrl?: string | null;
}

export interface ShopTrackResult {
  orderNumber: string;
  status: ShopOrderStatus;
  paymentStatus?: ShopPaymentStatus;
  paymentMethod?: string;
  carrierName?: string | null;
  trackingNumber?: string | null;
  trackingUrl?: string | null;
  estimatedDelivery?: string | null;
  trackingEvents?: ShopTrackingEvent[];
  /** v4.3: envíos del pedido (Dropi, Interrapidísimo, webhook o manual), del más antiguo al más reciente. */
  shipments?: ShopShipment[];
  [k: string]: unknown;
}

export interface ShopRegisterInput {
  email: string;
  password: string;
  name: string;
  phone?: string;
  acceptsMarketing?: boolean;
  /** Debe ser true (aceptación de términos y tratamiento de datos). */
  acceptsTerms: true;
  /** Por defecto: las órdenes de invitado de este navegador (guardadas al hacer checkout). */
  claimOrders?: { orderNumber: string; claimToken: string }[];
}

export interface ShopAuthResult {
  token: string;
  customer: ShopCustomer;
}

export interface ShopProfilePatch {
  name?: string;
  phone?: string;
  documentType?: string;
  documentId?: string;
  acceptsMarketing?: boolean;
}

/** Almacenamiento compatible con localStorage. */
export interface ShopStorage {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

export interface ShopClientOptions {
  /** Slug del proyecto en el CMS. */
  slug: string;
  /** URL del CMS (por defecto https://webproai.tech). */
  apiUrl?: string;
  /** Dónde guardar el token (por defecto localStorage si existe; si no, memoria). `null` = solo memoria. */
  storage?: ShopStorage | null;
  fetch?: typeof fetch;
}

export interface ShopClient {
  readonly slug: string;
  readonly apiUrl: string;
  config(): Promise<ShopPublicConfig>;
  checkout(input: ShopCheckoutInput, opts?: { saveAddress?: boolean }): Promise<ShopCheckoutResult>;
  confirmPayment(
    input: { transactionId?: string; paymentIntentId?: string; paymentId?: string; reference?: string; orderNumber?: string },
    opts?: { provider?: string },
  ): Promise<ShopConfirmResult>;
  /** Estado del pago para la página de retorno; `reference` es la que devolvió `checkout()`. */
  paymentStatus(orderNumber: string, reference: string): Promise<ShopConfirmResult>;
  /** Confirma (si la URL trae datos de la pasarela) y sondea hasta PAID/FAILED o el tiempo límite. */
  waitForPayment(
    input: { orderNumber: string; reference: string; provider?: string; returnParams?: ShopPaymentReturn },
    opts?: { intervalMs?: number; timeoutMs?: number; signal?: AbortSignal },
  ): Promise<ShopConfirmResult>;
  /** Retoma el pago pendiente guardado por `checkout()`; null si no hay ninguno. */
  resumePayment(opts?: { search?: string; intervalMs?: number; timeoutMs?: number; signal?: AbortSignal }): Promise<ShopConfirmResult | null>;
  /** Pedido pendiente guardado en este navegador (o null). */
  pendingPayment(): ShopPendingPayment | null;
  clearPendingPayment(): void;
  retryPayment(orderNumber: string, opts?: { email?: string; redirectUrl?: string }): Promise<ShopRetryResult>;
  track(code: string): Promise<ShopTrackResult>;
  account: {
    register(input: ShopRegisterInput): Promise<ShopAuthResult & { claimedOrders: string[] }>;
    login(input: { email: string; password: string }): Promise<ShopAuthResult>;
    /** Cierra la sesión en este navegador (borra el token local). */
    logout(): void;
    /** Invalida todos los tokens de la cuenta (todos los dispositivos) y borra el local. */
    logoutAll(): Promise<void>;
    /** Siempre responde `{ sent: true }`. `resetUrl` por defecto: <origen actual>/cuenta/restablecer. */
    forgotPassword(input: { email: string; resetUrl?: string }): Promise<{ sent: boolean }>;
    resetPassword(input: { token: string; password: string }): Promise<ShopAuthResult>;
    me(): Promise<ShopCustomer>;
    update(patch: ShopProfilePatch): Promise<ShopCustomer>;
    changePassword(input: { currentPassword: string; newPassword: string }): Promise<ShopAuthResult>;
    addresses: {
      list(): Promise<ShopAddress[]>;
      add(address: ShopAddressInput): Promise<ShopAddress[]>;
      update(id: string, patch: Partial<ShopAddressInput>): Promise<ShopAddress[]>;
      remove(id: string): Promise<ShopAddress[]>;
    };
    orders: {
      list(opts?: { page?: number; limit?: number }): Promise<ShopPage<ShopOrderSummary>>;
      get(orderNumber: string): Promise<ShopOrder>;
    };
    deleteAccount(input: { password: string }): Promise<{ deleted: boolean }>;
  };
  getToken(): string | null;
  setToken(token: string | null): void;
  /** Avisa cuando el token cambia (login, logout o 401 por sesión vencida). Devuelve la función para desuscribirse. */
  onTokenChange(listener: (token: string | null) => void): () => void;
}

/** Error de la tienda con el `code` del backend (EMAIL_TAKEN, INVALID_CREDENTIALS, PAYMENT_FAILED, OUT_OF_STOCK…). */
export class ShopError extends Error {
  status: number;
  code: string;
  /** Cuerpo completo de la respuesta (p. ej. `canRetry`, `orderNumber`, lista de agotados). */
  body: Record<string, unknown>;
  constructor(message: string, status: number, code: string, body: Record<string, unknown> = {}) {
    super(message);
    this.name = 'ShopError';
    this.status = status;
    this.code = code;
    this.body = body;
  }
}

/* ------------------------------------------------------------------ */
/* Implementación                                                      */
/* ------------------------------------------------------------------ */

const DEFAULT_MESSAGES: Record<number, string> = {
  400: 'Revisa los datos enviados.',
  401: 'Tu sesión no es válida. Inicia sesión de nuevo.',
  403: 'No tienes permiso para esta acción.',
  404: 'No encontrado.',
  409: 'La operación no se pudo completar.',
  429: 'Demasiados intentos. Espera un momento e inténtalo de nuevo.',
};

function memoryStorage(): ShopStorage {
  const m = new Map<string, string>();
  return {
    getItem: (k) => (m.has(k) ? (m.get(k) as string) : null),
    setItem: (k, v) => void m.set(k, String(v)),
    removeItem: (k) => void m.delete(k),
  };
}

function defaultStorage(): ShopStorage {
  try {
    const ls = (globalThis as { localStorage?: ShopStorage }).localStorage;
    if (ls) {
      const probe = '__ltn_shop_probe__';
      ls.setItem(probe, '1');
      ls.removeItem(probe);
      return ls;
    }
  } catch {
    // modo privado o almacenamiento bloqueado
  }
  return memoryStorage();
}

/** Lecturas/escrituras que nunca lanzan (almacenamiento lleno o bloqueado). */
function safe(storage: ShopStorage) {
  return {
    get(k: string): string | null {
      try {
        return storage.getItem(k);
      } catch {
        return null;
      }
    },
    set(k: string, v: string | null) {
      try {
        if (v === null) storage.removeItem(k);
        else storage.setItem(k, v);
      } catch {
        // sin persistencia: el token sigue en memoria
      }
    },
  };
}

/**
 * Lee los parámetros que cada pasarela añade al volver al sitio:
 * Wompi `?id=…`, MercadoPago `?payment_id=…&status=…&external_reference=…`,
 * Stripe `?payment_intent=…&redirect_status=…`, Bold `?bold-order-id=…&bold-tx-status=…`.
 */
export function readPaymentReturn(search?: string): ShopPaymentReturn {
  let q = search;
  if (q === undefined) {
    const loc = (globalThis as { location?: { search?: string } }).location;
    q = loc?.search || '';
  }
  const p = new URLSearchParams(q.startsWith('?') ? q.slice(1) : q);
  const get = (k: string) => {
    const v = p.get(k);
    return v && v !== 'null' && v !== 'undefined' ? v : undefined;
  };
  const mpId = get('payment_id') || get('collection_id');
  if (mpId || get('preference_id')) {
    return { provider: 'mercadopago', paymentId: mpId, reference: get('external_reference'), status: get('status') || get('collection_status') };
  }
  if (get('payment_intent')) return { provider: 'stripe', paymentIntentId: get('payment_intent'), status: get('redirect_status') };
  if (get('bold-order-id') || get('bold-tx-status')) return { provider: 'bold', reference: get('bold-order-id'), status: get('bold-tx-status') };
  if (get('id')) return { provider: 'wompi', transactionId: get('id') };
  return {};
}

const sleepFor = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    if (signal?.aborted) return reject(new ShopError('Consulta cancelada', 0, 'ABORTED'));
    const t = setTimeout(resolve, ms);
    signal?.addEventListener?.('abort', () => {
      clearTimeout(t);
      reject(new ShopError('Consulta cancelada', 0, 'ABORTED'));
    });
  });

function codeFromStatus(status: number): string {
  if (status === 401) return 'UNAUTHORIZED';
  if (status === 404) return 'NOT_FOUND';
  if (status === 429) return 'RATE_LIMITED';
  return `HTTP_${status}`;
}

/** `shipments` siempre es un arreglo y cada envío trae `events` (backends anteriores a v4.3 no lo envían). */
function normalizeTrack(r: ShopTrackResult): ShopTrackResult {
  if (!r || typeof r !== 'object') return r;
  const shipments = Array.isArray(r.shipments)
    ? r.shipments.map((s) => ({
        ...s,
        carrier: s.carrier ?? null,
        trackingNumber: s.trackingNumber ?? null,
        trackingUrl: s.trackingUrl ?? null,
        events: Array.isArray(s.events) ? s.events : [],
      }))
    : [];
  return { ...r, shipments };
}

export function createShopClient(opts: ShopClientOptions): ShopClient {
  if (!opts || !opts.slug) throw new Error('createShopClient requiere slug');
  const slug = opts.slug;
  const apiUrl = normalizeBaseUrl(opts.apiUrl);
  const fetchImpl: typeof fetch | undefined = opts.fetch || (typeof fetch === 'function' ? fetch.bind(globalThis) : undefined);
  const store = safe(opts.storage === null ? memoryStorage() : opts.storage || defaultStorage());
  const tokenKey = `ltn_shop_${slug}`;
  const claimsKey = `ltn_shop_${slug}_claims`;
  const pendingKey = `ltn_shop_${slug}_pending`;
  const listeners = new Set<(token: string | null) => void>();
  let token: string | null = store.get(tokenKey);

  const s = encodeURIComponent(slug);
  const publicBase = `/api/ecommerce/public/${s}`;
  const accountBase = `/api/shop/${s}/account`;

  function setToken(next: string | null) {
    const value = next || null;
    if (value === token) return;
    token = value;
    store.set(tokenKey, value);
    for (const l of listeners) {
      try {
        l(value);
      } catch {
        // un listener roto no rompe la sesión
      }
    }
  }

  function readClaims(): { orderNumber: string; claimToken: string }[] {
    try {
      const raw = store.get(claimsKey);
      const list = raw ? JSON.parse(raw) : [];
      return Array.isArray(list) ? list.filter((c) => c && typeof c.orderNumber === 'string' && typeof c.claimToken === 'string') : [];
    } catch {
      return [];
    }
  }

  function writeClaims(list: { orderNumber: string; claimToken: string }[]) {
    store.set(claimsKey, list.length ? JSON.stringify(list.slice(-20)) : null);
  }

  async function request<T>(method: string, path: string, { body, auth = false }: { body?: unknown; auth?: boolean } = {}): Promise<T> {
    if (!fetchImpl) throw new ShopError('No hay fetch disponible: pásalo en createShopClient({ fetch }).', 0, 'NO_FETCH');
    const headers: Record<string, string> = { Accept: 'application/json' };
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    const sentToken = auth ? token : null;
    if (sentToken) headers.Authorization = `Bearer ${sentToken}`;
    let res: Response;
    try {
      res = await fetchImpl(`${apiUrl}${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
    } catch (e) {
      throw new ShopError('No se pudo conectar con la tienda. Revisa tu conexión.', 0, 'NETWORK_ERROR', { cause: String((e as Error)?.message || e) });
    }
    const text = await res.text();
    let data: any = undefined;
    if (text) {
      try {
        data = JSON.parse(text);
      } catch {
        data = { message: text };
      }
    }
    if (!res.ok) {
      const payload = data && typeof data === 'object' ? (data as Record<string, unknown>) : {};
      const raw = payload.message;
      const message = Array.isArray(raw) ? raw.join('. ') : typeof raw === 'string' && raw ? raw : DEFAULT_MESSAGES[res.status] || 'Error de la tienda.';
      const code = typeof payload.code === 'string' && payload.code ? payload.code : codeFromStatus(res.status);
      // Sesión vencida o invalidada (logout-all, cambio de contraseña): se olvida el token.
      if (res.status === 401 && sentToken && sentToken === token) setToken(null);
      throw new ShopError(message, res.status, code, payload);
    }
    return data as T;
  }

  const unwrapCustomer = (r: any): ShopCustomer => (r && r.customer ? r.customer : r);
  const unwrapAddresses = (r: any): ShopAddress[] => (Array.isArray(r) ? r : Array.isArray(r?.addresses) ? r.addresses : []);
  const withToken = <T extends { token?: string }>(r: T): T => {
    if (r && typeof r.token === 'string' && r.token) setToken(r.token);
    return r;
  };

  const client: ShopClient = {
    slug,
    apiUrl,

    config: () => request<ShopPublicConfig>('GET', `${publicBase}/config`),

    async checkout(input, { saveAddress } = {}) {
      // Medición: begin_checkout con los precios del servidor y, en contraentrega, purchase (mismo
      // event_id que el Purchase de la API de conversiones: el número de pedido).
      const withTracking = { ...input, tracking: input.tracking ?? trackingContext() };
      const body = saveAddress === undefined ? withTracking : { ...withTracking, saveAddress };
      const res = await request<ShopCheckoutResult>('POST', `${publicBase}/checkout`, { body, auth: true });
      if (res?.claimToken && res.orderNumber) writeClaims([...readClaims().filter((c) => c.orderNumber !== res.orderNumber), { orderNumber: res.orderNumber, claimToken: res.claimToken }]);
      if (res?.orderNumber) {
        track('begin_checkout', orderTrackParams(res, false));
        if (purchaseOnPlacement(input.provider ?? (res as any).paymentSession?.provider)) track('purchase', orderTrackParams(res, true));
      }
      // Pago con redirección: se recuerda para retomarlo en la página de retorno (resumePayment).
      if (res?.checkoutUrl && res.orderNumber && res.reference) {
        const provider = String(input.provider || (input as any).paymentProvider || 'wompi').toLowerCase();
        store.set(pendingKey, JSON.stringify({ orderNumber: res.orderNumber, reference: res.reference, provider, at: Date.now() }));
      }
      return res;
    },

    async confirmPayment(input, { provider = 'wompi' } = {}) {
      const res = await request<ShopConfirmResult>('POST', `${publicBase}/payments/${encodeURIComponent(provider)}/confirm-order`, { body: input });
      if (res?.paymentStatus === 'PAID' && res.orderNumber) track('purchase', orderTrackParams({ ...(res.order || {}), orderNumber: res.orderNumber }, true));
      return res;
    },

    paymentStatus(orderNumber, reference) {
      return request<ShopConfirmResult>(
        'GET',
        `${publicBase}/orders/${encodeURIComponent(orderNumber)}/payment-status?reference=${encodeURIComponent(reference)}`,
      );
    },

    async waitForPayment({ orderNumber, reference, provider, returnParams }, { intervalMs = 3000, timeoutMs = 60000, signal } = {}) {
      const prov = String(provider || returnParams?.provider || 'wompi').toLowerCase();
      let last: ShopConfirmResult | null = null;
      // 1) Confirmación con lo que trajo la URL (la pasarela es la fuente; el backend verifica).
      const rp = returnParams || {};
      const confirmBody: Record<string, string> = { orderNumber };
      if (prov === 'wompi' && rp.transactionId) confirmBody.transactionId = rp.transactionId;
      if (prov === 'mercadopago' && rp.paymentId) confirmBody.paymentId = rp.paymentId;
      if (prov === 'stripe' && rp.paymentIntentId) confirmBody.paymentIntentId = rp.paymentIntentId;
      const canConfirm = Object.keys(confirmBody).length > 1 || prov === 'bold' || prov === 'mercadopago';
      if (canConfirm) {
        try {
          last = await client.confirmPayment(prov === 'bold' || (prov === 'mercadopago' && !rp.paymentId) ? { orderNumber, reference } : confirmBody, { provider: prov });
        } catch (e) {
          if (!(e instanceof ShopError) || e.status >= 500 || e.status === 0) throw e;
        }
      }
      // 2) Sondeo mientras siga pendiente (PSE, OXXO, SPEI y webhooks tardíos).
      const deadline = Date.now() + timeoutMs;
      while (!last || last.paymentStatus === 'PENDING') {
        if (last && Date.now() + intervalMs > deadline) break;
        if (last) await sleepFor(intervalMs, signal);
        last = await client.paymentStatus(orderNumber, reference);
        // Aprobado durante el sondeo (webhook tardío): purchase con el valor del servidor.
        if (last?.paymentStatus === 'PAID' && last.orderNumber) track('purchase', orderTrackParams({ ...(last.order || {}), orderNumber: last.orderNumber }, true));
      }
      return last;
    },

    async resumePayment({ search, ...opts } = {}) {
      const pending = client.pendingPayment();
      if (!pending) return null;
      const returnParams = readPaymentReturn(search);
      const result = await client.waitForPayment({ ...pending, returnParams }, opts);
      if (result.paymentStatus !== 'PENDING') client.clearPendingPayment();
      return result;
    },

    pendingPayment() {
      try {
        const raw = store.get(pendingKey);
        const v = raw ? JSON.parse(raw) : null;
        return v && typeof v.orderNumber === 'string' && typeof v.reference === 'string' ? (v as ShopPendingPayment) : null;
      } catch {
        return null;
      }
    },

    clearPendingPayment() {
      store.set(pendingKey, null);
    },

    retryPayment(orderNumber, { email, redirectUrl } = {}) {
      const body: Record<string, string> = {};
      if (email) body.email = email;
      if (redirectUrl) body.redirectUrl = redirectUrl;
      return request<ShopRetryResult>('POST', `${publicBase}/orders/${encodeURIComponent(orderNumber)}/retry-payment`, { body, auth: true });
    },

    track: async (code) => normalizeTrack(await request<ShopTrackResult>('GET', `${publicBase}/track/${encodeURIComponent(code)}`)),

    account: {
      async register(input) {
        const claims = input.claimOrders ?? readClaims();
        const body = claims.length ? { ...input, claimOrders: claims } : input;
        const res = withToken(await request<ShopAuthResult & { claimedOrders: string[] }>('POST', `${accountBase}/register`, { body }));
        const claimed = new Set(res.claimedOrders || []);
        if (!input.claimOrders) writeClaims(readClaims().filter((c) => !claimed.has(c.orderNumber)));
        return { ...res, claimedOrders: res.claimedOrders || [] };
      },
      async login(input) {
        return withToken(await request<ShopAuthResult>('POST', `${accountBase}/login`, { body: input }));
      },
      logout() {
        setToken(null);
      },
      async logoutAll() {
        try {
          await request('POST', `${accountBase}/me/logout-all`, { auth: true });
        } finally {
          setToken(null);
        }
      },
      forgotPassword({ email, resetUrl }) {
        const origin = (globalThis as { location?: { origin?: string } }).location?.origin;
        const url = resetUrl || (origin ? `${origin}/cuenta/restablecer` : '');
        if (!url) return Promise.reject(new ShopError('Falta resetUrl (la página del sitio que restablece la contraseña).', 0, 'MISSING_RESET_URL'));
        return request<{ sent: boolean }>('POST', `${accountBase}/forgot-password`, { body: { email, resetUrl: url } });
      },
      async resetPassword(input) {
        return withToken(await request<ShopAuthResult>('POST', `${accountBase}/reset-password`, { body: input }));
      },
      async me() {
        return unwrapCustomer(await request('GET', `${accountBase}/me`, { auth: true }));
      },
      async update(patch) {
        return unwrapCustomer(await request('PATCH', `${accountBase}/me`, { body: patch, auth: true }));
      },
      async changePassword(input) {
        return withToken(await request<ShopAuthResult>('POST', `${accountBase}/me/password`, { body: input, auth: true }));
      },
      addresses: {
        list: async () => unwrapAddresses(await request('GET', `${accountBase}/me/addresses`, { auth: true })),
        add: async (address) => unwrapAddresses(await request('POST', `${accountBase}/me/addresses`, { body: address, auth: true })),
        update: async (id, patch) => unwrapAddresses(await request('PATCH', `${accountBase}/me/addresses/${encodeURIComponent(id)}`, { body: patch, auth: true })),
        remove: async (id) => unwrapAddresses(await request('DELETE', `${accountBase}/me/addresses/${encodeURIComponent(id)}`, { auth: true })),
      },
      orders: {
        list({ page, limit } = {}) {
          const q = new URLSearchParams();
          if (page) q.set('page', String(page));
          if (limit) q.set('limit', String(limit));
          const qs = q.toString();
          return request<ShopPage<ShopOrderSummary>>('GET', `${accountBase}/me/orders${qs ? `?${qs}` : ''}`, { auth: true });
        },
        get: (orderNumber) => request<ShopOrder>('GET', `${accountBase}/me/orders/${encodeURIComponent(orderNumber)}`, { auth: true }),
      },
      async deleteAccount({ password }) {
        const res = await request<{ deleted: boolean }>('DELETE', `${accountBase}/me`, { body: { password }, auth: true });
        setToken(null);
        return res;
      },
    },

    getToken: () => token,
    setToken,
    onTokenChange(listener) {
      listeners.add(listener);
      return () => void listeners.delete(listener);
    },
  };
  return client;
}

/* Alias cortos de los tipos principales. */
export type Customer = ShopCustomer;
export type Address = ShopAddress;
export type OrderSummary = ShopOrderSummary;
export type Shipment = ShopShipment;
