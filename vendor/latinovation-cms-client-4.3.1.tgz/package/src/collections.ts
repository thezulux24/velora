import type { CollectionFilterDef, CollectionItem, DeliveryPayload } from './types.js';
import { CmsDeliveryError, getCollection, getStoreCollectionSlug, normalizeBaseUrl, toNumber, type FetchDeliveryOptions } from './delivery.js';
import { str } from './fields.js';

/**
 * Colecciones dinámicas (docs/EDITING-V4.1.md §C.1): rutas de detalle, búsqueda, filtros,
 * orden y paginación sobre las colecciones que ya trae delivery (sin pedir nada más al servidor).
 */

export interface ItemRouteOptions {
  /** Patrón explícito: "/producto/:slug" (también `:id`). Tiene prioridad sobre `routeBase`. */
  pattern?: string;
  /** Prefijo del sitio (p. ej. "/site/demo"). */
  basePath?: string;
}

/**
 * Ruta de detalle de un ítem: `collectionDefinitions[col].routeBase + '/' + slug`, o el `pattern`.
 * `undefined` si la colección no tiene páginas de detalle.
 */
export function getItemRoute(
  p: DeliveryPayload | null | undefined,
  collection: string,
  item: Pick<CollectionItem, 'slug' | 'id'> | string,
  opts: ItemRouteOptions = {},
): string | undefined {
  const slug = typeof item === 'string' ? item : item.slug || item.id;
  const id = typeof item === 'string' ? item : item.id;
  if (!slug) return undefined;
  const base = (opts.basePath || '').replace(/\/+$/, '');
  if (opts.pattern) return `${base}${opts.pattern.replace(':slug', encodeURIComponent(slug)).replace(':id', encodeURIComponent(id))}`;
  const routeBase = p?.collectionDefinitions?.[collection]?.routeBase;
  if (!routeBase) return undefined;
  const rb = `/${String(routeBase).replace(/^\/+|\/+$/g, '')}`;
  return `${base}${rb === '/' ? '' : rb}/${encodeURIComponent(slug)}`;
}

/** Inverso de getItemRoute: qué colección/ítem corresponde a una ruta (`/blog/mi-post`). */
export function matchItemRoute(p: DeliveryPayload | null | undefined, pathname: string): { collection: string; slug: string; item?: CollectionItem } | undefined {
  const path = `/${String(pathname || '').replace(/^\/+|\/+$/g, '')}`;
  for (const def of Object.values(p?.collectionDefinitions || {})) {
    if (!def?.routeBase) continue;
    const rb = `/${String(def.routeBase).replace(/^\/+|\/+$/g, '')}`;
    if (path.startsWith(`${rb}/`)) {
      const slug = decodeURIComponent(path.slice(rb.length + 1).split('/')[0]);
      if (!slug) continue;
      const item = getCollection(p, def.slug).find((x) => x.slug === slug || x.id === slug);
      return { collection: def.slug, slug, item };
    }
  }
  return undefined;
}

export type FilterValue = string | number | boolean | string[] | { min?: number; max?: number } | null | undefined;

export interface CollectionQuery {
  /** Slug de la colección (por defecto, la de tienda). */
  collection?: string;
  /** `{ category: 'Proteínas', price: { min: 0, max: 90000 }, isFeatured: true, tags: ['vegano'] }`. */
  filters?: Record<string, FilterValue>;
  /** "price:asc", "createdAt:desc", "title" (asc). Por defecto `listDefaults.sort` o el orden del CMS. */
  sort?: string;
  /** Página (desde 1). */
  page?: number;
  /** Por defecto `listDefaults.pageSize` o todo. */
  pageSize?: number;
  /** Busca en título y en todos los campos de texto. */
  search?: string;
  /** Incluir ítems no publicados (solo llegan en preview). */
  includeUnpublished?: boolean;
}

export interface FacetOption {
  value: string;
  count: number;
}

export interface CollectionFacet {
  field: string;
  type: string;
  label?: string;
  /** select: opciones con conteo (sobre el resultado sin ese filtro). */
  options?: FacetOption[];
  /** range: mínimo y máximo disponibles. */
  min?: number;
  max?: number;
  /** boolean: ítems con valor verdadero. */
  count?: number;
}

export interface CollectionQueryResult<T = CollectionItem> {
  collection: string | undefined;
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  pageCount: number;
  facets: CollectionFacet[];
}

function truthy(v: unknown): boolean {
  if (typeof v === 'boolean') return v;
  if (typeof v === 'number') return v !== 0;
  return /^(true|1|si|sí|yes|on)$/i.test(String(v ?? '').trim());
}

function valuesOf(v: unknown): string[] {
  if (Array.isArray(v)) return v.map((x) => str(x) || (x && typeof x === 'object' ? str((x as any).label ?? (x as any).value) : '')).filter(Boolean);
  const s = str(v);
  if (!s) return [];
  return s.includes('|') || s.includes(',') ? s.split(/\s*[|,]\s*/).filter(Boolean) : [s];
}

function norm(s: string): string {
  return s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '');
}

function matchesFilter(item: CollectionItem, field: string, value: FilterValue): boolean {
  if (value === undefined || value === null || value === '') return true;
  const raw = item[field];
  if (typeof value === 'boolean') return truthy(raw) === value;
  if (Array.isArray(value)) {
    if (!value.length) return true;
    const have = valuesOf(raw).map(norm);
    return value.some((v) => have.includes(norm(String(v))));
  }
  if (typeof value === 'object') {
    const n = toNumber(raw);
    if (n === undefined) return false;
    if (typeof value.min === 'number' && n < value.min) return false;
    if (typeof value.max === 'number' && n > value.max) return false;
    return true;
  }
  if (typeof value === 'number') return toNumber(raw) === value;
  const have = valuesOf(raw).map(norm);
  return have.includes(norm(String(value)));
}

function matchesSearch(item: CollectionItem, q: string): boolean {
  const needle = norm(q.trim());
  if (!needle) return true;
  const hay = norm(
    Object.entries(item)
      .filter(([k, v]) => !k.startsWith('_') && (typeof v === 'string' || typeof v === 'number'))
      .map(([, v]) => String(v))
      .join(' '),
  );
  return needle.split(/\s+/).every((w) => hay.includes(w));
}

function compare(a: unknown, b: unknown): number {
  const na = typeof a === 'number' ? a : toNumber(a);
  const nb = typeof b === 'number' ? b : toNumber(b);
  const sa = str(a);
  const sb = str(b);
  const isDate = (s: string) => /^\d{4}-\d{2}-\d{2}/.test(s);
  if (isDate(sa) && isDate(sb)) return sa < sb ? -1 : sa > sb ? 1 : 0;
  if (na !== undefined && nb !== undefined && /^[\s$€\d.,-]+$/.test(sa || String(na)) && /^[\s$€\d.,-]+$/.test(sb || String(nb))) return na - nb;
  if (a === undefined || a === null || a === '') return 1;
  if (b === undefined || b === null || b === '') return -1;
  return sa.localeCompare(sb, 'es', { sensitivity: 'base', numeric: true });
}

/** Aplica búsqueda, filtros, orden y paginación. Puro: úsalo en servidor o cliente. */
export function queryCollection<T extends CollectionItem = CollectionItem>(p: DeliveryPayload | null | undefined, q: CollectionQuery = {}): CollectionQueryResult<T> {
  const slug = q.collection || getStoreCollectionSlug(p);
  const def = slug ? p?.collectionDefinitions?.[slug] : undefined;
  const all = (slug ? getCollection(p, slug) : []).filter((x) => q.includeUnpublished || !x.status || x.status === 'PUBLISHED');
  const filters = q.filters || {};
  const searched = q.search ? all.filter((x) => matchesSearch(x, q.search!)) : all;
  const applyAll = (except?: string) => searched.filter((x) => Object.entries(filters).every(([f, v]) => f === except || matchesFilter(x, f, v)));
  let items = applyAll();

  const sortSpec = q.sort || def?.listDefaults?.sort || '';
  if (sortSpec) {
    const [field, dir] = sortSpec.split(':');
    const sign = String(dir || 'asc').toLowerCase() === 'desc' ? -1 : 1;
    items = items
      .map((x, i) => ({ x, i }))
      .sort((a, b) => {
        const av = a.x[field];
        const bv = b.x[field];
        const empty = (v: unknown) => v === undefined || v === null || v === '';
        if (empty(av) !== empty(bv)) return empty(av) ? 1 : -1; // vacíos al final siempre
        return sign * compare(av, bv) || a.i - b.i;
      })
      .map((e) => e.x);
  }

  // facetas por cada filtro declarado (y los usados aunque no estén declarados)
  const declared: CollectionFilterDef[] = Array.isArray(def?.filters) ? def!.filters! : [];
  const used = Object.keys(filters).filter((f) => !declared.some((d) => d.field === f)).map((f): CollectionFilterDef => ({ field: f, type: inferFilterType(filters[f]) }));
  const facets: CollectionFacet[] = [...declared, ...used]
    .filter((d) => d.type !== 'search')
    .map((d) => {
      const base = applyAll(d.field);
      if (d.type === 'range') {
        const nums = base.map((x) => toNumber(x[d.field])).filter((n): n is number => n !== undefined);
        return { field: d.field, type: d.type, label: d.label, min: nums.length ? Math.min(...nums) : undefined, max: nums.length ? Math.max(...nums) : undefined };
      }
      if (d.type === 'boolean') return { field: d.field, type: d.type, label: d.label, count: base.filter((x) => truthy(x[d.field])).length };
      const counts = new Map<string, number>();
      const order: string[] = d.field === 'category' && def?.categories?.length ? [...def.categories] : [];
      for (const x of base) for (const v of valuesOf(x[d.field])) counts.set(v, (counts.get(v) || 0) + 1);
      for (const k of counts.keys()) if (!order.includes(k)) order.push(k);
      return { field: d.field, type: d.type, label: d.label, options: order.map((value) => ({ value, count: counts.get(value) || 0 })) };
    });

  const total = items.length;
  const pageSize = Math.max(0, Math.floor(q.pageSize ?? def?.listDefaults?.pageSize ?? 0));
  const pageCount = pageSize ? Math.max(1, Math.ceil(total / pageSize)) : 1;
  const page = Math.min(Math.max(1, Math.floor(q.page || 1)), pageCount);
  const paged = pageSize ? items.slice((page - 1) * pageSize, page * pageSize) : items;
  return { collection: slug, items: paged as T[], total, page, pageSize: pageSize || total, pageCount, facets };
}

function inferFilterType(v: FilterValue): string {
  if (typeof v === 'boolean') return 'boolean';
  if (v && typeof v === 'object' && !Array.isArray(v)) return 'range';
  return 'select';
}

/** Ítem por slug o id. */
export function getItem(p: DeliveryPayload | null | undefined, collection: string, slugOrId: string): CollectionItem | undefined {
  return getCollection(p, collection).find((x) => x.slug === slugOrId || x.id === slugOrId);
}

/** URL de `GET /api/v1/delivery/:slug/collections/:col/:itemSlug` (ítem publicado individual, §C.1). */
export function itemDeliveryUrl(opts: Pick<FetchDeliveryOptions, 'slug' | 'baseUrl'> & { collection: string; item: string }): string {
  return `${normalizeBaseUrl(opts.baseUrl)}/api/v1/delivery/${encodeURIComponent(opts.slug || '')}/collections/${encodeURIComponent(opts.collection)}/${encodeURIComponent(opts.item)}`;
}

/** Descarga un ítem individual (útil para rutas de detalle sin bajar todo el sitio). Devuelve null si no existe. */
export async function fetchItem(
  opts: Pick<FetchDeliveryOptions, 'slug' | 'baseUrl' | 'fetch' | 'revalidate' | 'tags' | 'init'> & { collection: string; item: string },
): Promise<CollectionItem | null> {
  const url = itemDeliveryUrl(opts);
  const f = opts.fetch || fetch;
  const init: RequestInit & { next?: { revalidate?: number | false; tags?: string[] } } = { ...(opts.init || {}) };
  if (opts.revalidate === false) init.cache = 'no-store';
  else init.next = { revalidate: opts.revalidate ?? 60, tags: opts.tags || [`cms:${opts.slug}`] };
  const res = await f(url, init);
  if (res.status === 404) return null;
  if (!res.ok) throw new CmsDeliveryError(`Delivery respondió HTTP ${res.status}`, res.status, url);
  const body: any = await res.json();
  const raw = body?.item || body;
  if (!raw || typeof raw !== 'object') return null;
  // aplanar { id, title, slug, data: {...} } si viene sin aplanar
  return raw.data && typeof raw.data === 'object' && !Array.isArray(raw.data) ? { ...raw.data, ...raw, data: undefined } : raw;
}
