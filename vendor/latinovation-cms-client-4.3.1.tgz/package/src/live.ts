import type { CollectionDefinition, CollectionItem, DeliveryPayload, SectionData, SectionRow } from './types.js';
import { normalizeBaseUrl, normalizePageSlug } from './delivery.js';
import { applyArrayOp, setPath, type ArrayOp } from './paths.js';

/**
 * Protocolo de vista previa en vivo entre el portal (/portal) y el sitio dentro del iframe
 * (contrato 2.7, documentado en docs/LIVE-PREVIEW.md).
 *
 *   portal → sitio : CMS_LIVE_PREVIEW_STATE, CMS_SCROLL_TO_SECTION, CMS_HOVER_SECTION, CMS_SELECT_DOM_ELEMENT
 *   sitio  → portal: CMS_CANVAS_ACTION { action, ... }
 */
export const CMS_MESSAGES = {
  LIVE_STATE: 'CMS_LIVE_PREVIEW_STATE',
  SCROLL_TO_SECTION: 'CMS_SCROLL_TO_SECTION',
  HOVER_SECTION: 'CMS_HOVER_SECTION',
  SELECT_DOM_ELEMENT: 'CMS_SELECT_DOM_ELEMENT',
  CANVAS_ACTION: 'CMS_CANVAS_ACTION',
} as const;

/** Acciones que el sitio puede enviar al portal (las que el portal entiende hoy). */
export type CanvasAction =
  | 'SELECT_SECTION'
  | 'SELECT_ELEMENT'
  | 'INLINE_FIELD_CHANGE'
  | 'INLINE_WIDGET_CHANGE'
  | 'INLINE_ELEMENT_STYLE_CHANGE'
  | 'INLINE_GLOBAL_CHANGE'
  | 'INLINE_NAV_CHANGE'
  | 'INLINE_COLLECTION_ITEM_CHANGE'
  | 'DELETE_WIDGET'
  | 'MOVE_SECTION'
  | 'REORDER_DROP'
  | 'DUPLICATE_SECTION'
  | 'DELETE_SECTION'
  | 'OPEN_ADD_BLOCK_MODAL'
  | 'OPEN_COLLECTION_MANAGER'
  | 'OPEN_AI_AGENT_FOR_ELEMENT'
  | 'SECTION_DOM_TREE'
  | 'HISTORY'
  // v4.1 (§8.2)
  | 'FOCUS_FIELD'
  | 'ARRAY_ITEM_ACTION'
  | 'FOCUS_COLLECTION_ITEM'
  | 'CREATE_COLLECTION_ITEM'
  | 'FOCUS_GLOBAL'
  | 'FOCUS_NAV'
  | 'SECTION_STYLE_CHANGE'
  // EDITING-V4.1 §B (compositor)
  | 'COMPOSER_ACTION';

export interface LivePreviewStateMessage {
  type: 'CMS_LIVE_PREVIEW_STATE';
  /** Secciones de la página activa en el editor (con draftData). */
  sectionsList?: SectionRow[];
  globalData?: Record<string, any>;
  navigationConfig?: Record<string, any>;
  collections?: Record<string, CollectionItem[]>;
  /** true: las listas de colecciones reemplazan a las actuales aunque vengan vacías. */
  collectionsAuthoritative?: boolean;
  collectionDefinitions?: Record<string, CollectionDefinition>;
  selectedSectionKey?: string;
  /** Slug de la página que se está editando (si el portal lo envía). */
  pageSlug?: string;
  focusCategory?: string;
}

export interface PreviewParams {
  preview: boolean;
  builder: boolean;
  previewToken: string;
}

/** Lee `?preview=1&builder=1&previewToken=…` de la URL. */
export function readPreviewParams(search?: string): PreviewParams {
  const q = new URLSearchParams(search ?? (typeof window !== 'undefined' ? window.location.search : ''));
  const preview = q.get('preview') === '1' || q.get('preview') === 'true';
  const builder = q.get('builder') === '1' || q.get('builder') === 'true';
  return { preview: preview || builder, builder, previewToken: q.get('previewToken') || '' };
}

function activeData(s: SectionRow): SectionData {
  return s.draftData && Object.keys(s.draftData).length > 0 ? s.draftData : s.data || {};
}

/**
 * Fusiona el estado en vivo del portal en el payload (borradores sin guardar se ven al instante).
 * Las secciones reemplazan las de la página que contiene esas claves, o la página activa.
 */
export function applyLiveState(prev: DeliveryPayload, msg: LivePreviewStateMessage, activePageSlug = '/'): DeliveryPayload {
  const next: DeliveryPayload = { ...prev };
  if (Array.isArray(msg.sectionsList)) {
    const rows: SectionRow[] = msg.sectionsList
      .map((s) => ({ id: s.id, key: s.key, name: s.name, isVisible: s.isVisible, order: s.order, data: activeData(s) }))
      .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
    const keys = new Set(rows.map((r) => r.key));
    const ids = new Set(rows.map((r) => r.id));
    // Coincidir por ID pesa más que por clave (las claves pueden repetirse entre páginas).
    const overlap = (pg: { sectionsList?: SectionRow[] }) =>
      (pg.sectionsList || []).reduce((n, s) => n + (ids.has(s.id) ? 2 : keys.has(s.key) ? 1 : 0), 0);
    // Página destino: la que indique el portal; si no, la activa salvo que otra comparta más secciones (por id/clave).
    let target = msg.pageSlug ? normalizePageSlug(msg.pageSlug) : normalizePageSlug(activePageSlug);
    if (!msg.pageSlug) {
      const active = prev.pages.find((pg) => normalizePageSlug(pg.slug) === target);
      const best = [...prev.pages].sort((a, b) => overlap(b) - overlap(a))[0];
      if (best && overlap(best) > (active ? overlap(active) : 0)) target = normalizePageSlug(best.slug);
    }
    next.pages = prev.pages.map((pg) => {
      if (normalizePageSlug(pg.slug) !== target) return pg;
      const sections: Record<string, SectionData> = {};
      for (const r of rows) if (r.isVisible !== false) sections[r.key] = r.data || {};
      return { ...pg, sectionsList: rows, sections };
    });
  }
  if (msg.globalData && typeof msg.globalData === 'object') next.global = { ...prev.global, ...msg.globalData };
  if (msg.navigationConfig && typeof msg.navigationConfig === 'object') next.navigation = msg.navigationConfig;
  if (msg.collections && typeof msg.collections === 'object') {
    const cols = { ...prev.collections };
    for (const [k, v] of Object.entries(msg.collections)) {
      if (Array.isArray(v) && (v.length > 0 || msg.collectionsAuthoritative)) cols[k] = v;
    }
    next.collections = cols;
  }
  if (msg.collectionDefinitions && typeof msg.collectionDefinitions === 'object') {
    next.collectionDefinitions = { ...prev.collectionDefinitions, ...msg.collectionDefinitions };
  }
  return next;
}

export interface LivePreviewBridgeOptions {
  /** URL del CMS/portal (su origen es el único aceptado). Por defecto https://webproai.tech. */
  cmsUrl?: string;
  /** Orígenes adicionales permitidos (ej. http://localhost:3005 en desarrollo). */
  allowedOrigins?: string[];
  onState?: (msg: LivePreviewStateMessage) => void;
  /** Por defecto hace scroll a `#cms-section-<key>` o `[data-section-key=<key>]`. */
  onScrollTo?: (sectionKey: string) => void;
  /** Por defecto marca la sección con `data-cms-hover`. */
  onHover?: (sectionKey: string) => void;
  /** CMS_SELECT_DOM_ELEMENT: el portal pide resaltar `[data-el-id]`. */
  onSelectElement?: (elementId: string, msg: Record<string, any>) => void;
  /** Cualquier mensaje válido del portal (después de los manejadores propios). */
  onMessage?: (msg: Record<string, any>) => void;
  /** Ventana del sitio (por defecto `window`). */
  win?: Window;
}

export interface LivePreviewBridge {
  /** true si el sitio está dentro de un iframe (modo editor). */
  embedded: boolean;
  post(action: CanvasAction, payload?: Record<string, unknown>): void;
  selectSection(sectionKey: string, sectionId?: string): void;
  commitField(sectionKey: string, sectionId: string, fieldKey: string, value: unknown): void;
  commitWidgetField(sectionKey: string, sectionId: string, widgetIndex: number, fieldKey: string, value: unknown): void;
  commitGlobal(fieldKey: string, value: unknown): void;
  commitCollectionItem(collectionSlug: string, itemId: string, fieldKey: string, value: unknown): void;
  /** INLINE_NAV_CHANGE: enlace (`linkIndex` + `fieldKey`; `navList: 'footerLinks'` para el pie), `promoField` o campo plano. */
  commitNav(target: NavChangeTarget, value: unknown): void;
  focusField(sectionKey: string, sectionId: string, fieldPath: string, fieldType?: string): void;
  arrayItemAction(sectionKey: string, sectionId: string, fieldPath: string, index: number, op: ArrayOp): void;
  focusCollectionItem(collectionSlug: string, itemId: string, fieldKey?: string): void;
  createCollectionItem(collectionSlug: string, category?: string): void;
  focusGlobal(fieldKey: string): void;
  focusNav(linkIndex?: number, navList?: 'headerLinks' | 'footerLinks'): void;
  sectionStyleChange(sectionKey: string, sectionId: string, stylePatch: Record<string, unknown>): void;
  elementStyleChange(sectionKey: string, sectionId: string, elementId: string, stylePatch: Record<string, unknown> | null): void;
  openAddBlock(afterSectionId?: string): void;
  moveSection(sectionId: string, direction: 'UP' | 'DOWN'): void;
  reorderDrop(sourceSectionId: string, targetSectionId: string): void;
  duplicateSection(sectionId: string): void;
  deleteSection(sectionId: string): void;
  history(direction: 'undo' | 'redo'): void;
  destroy(): void;
}

export interface NavChangeTarget {
  linkIndex?: number;
  navList?: 'headerLinks' | 'footerLinks';
  promoField?: string;
  fieldKey?: string;
}

export function findSectionElement(doc: Document, key: string): HTMLElement | null {
  return (doc.getElementById(`cms-section-${key}`) as HTMLElement | null) || (doc.querySelector(`[data-section-key="${CSS.escape(key)}"]`) as HTMLElement | null);
}

/**
 * Conecta el sitio con el portal. Solo acepta mensajes de `window.parent` con origen permitido
 * y envía siempre al origen del CMS (nunca `*`).
 */
export function createLivePreviewBridge(opts: LivePreviewBridgeOptions = {}): LivePreviewBridge {
  const win = opts.win || (typeof window !== 'undefined' ? window : (undefined as unknown as Window));
  const cmsOrigin = new URL(normalizeBaseUrl(opts.cmsUrl)).origin;
  const allowed = new Set([cmsOrigin, ...(opts.allowedOrigins || []).map((o) => new URL(o).origin)]);
  const embedded = Boolean(win && win.parent && win.parent !== win);
  let hovered: HTMLElement | null = null;
  // Responder al origen real del portal (p. ej. localhost en desarrollo) si está permitido; nunca "*".
  let targetOrigin = cmsOrigin;
  let lastSelected = "";
  try {
    const ref = win?.document?.referrer ? new URL(win.document.referrer).origin : "";
    if (ref && allowed.has(ref)) targetOrigin = ref;
  } catch {
    /* referrer inválido */
  }

  const scrollTo =
    opts.onScrollTo ||
    ((key: string) => {
      const el = findSectionElement(win.document, key);
      if (!el) return;
      const r = el.getBoundingClientRect();
      if (r.top > win.innerHeight * 0.6 || r.bottom < win.innerHeight * 0.2) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  const hover =
    opts.onHover ||
    ((key: string) => {
      hovered?.removeAttribute('data-cms-hover');
      hovered = key ? findSectionElement(win.document, key) : null;
      const host = (hovered?.closest('[data-section-key]') as HTMLElement | null) || hovered;
      hovered = host;
      host?.setAttribute('data-cms-hover', 'true');
    });

  const onMessage = (event: MessageEvent) => {
    if (event.source !== win.parent || !allowed.has(event.origin)) return;
    targetOrigin = event.origin;
    const msg = event.data;
    if (!msg || typeof msg !== 'object') return;
    if (msg.type === CMS_MESSAGES.LIVE_STATE) {
      opts.onState?.(msg as LivePreviewStateMessage);
      // Solo cuando la selección cambia (no en cada pulsación del inspector).
      if (msg.selectedSectionKey && msg.selectedSectionKey !== lastSelected) scrollTo(msg.selectedSectionKey);
      lastSelected = msg.selectedSectionKey || lastSelected;
    } else if (msg.type === CMS_MESSAGES.SCROLL_TO_SECTION && msg.sectionKey) {
      lastSelected = msg.sectionKey;
      scrollTo(msg.sectionKey);
    }
    else if (msg.type === CMS_MESSAGES.HOVER_SECTION) hover(msg.sectionKey || '');
    else if (msg.type === CMS_MESSAGES.SELECT_DOM_ELEMENT && msg.elementId) opts.onSelectElement?.(String(msg.elementId), msg);
    opts.onMessage?.(msg);
  };
  if (embedded) win.addEventListener('message', onMessage);

  const post = (action: CanvasAction, payload: Record<string, unknown> = {}) => {
    if (!embedded) return;
    win.parent.postMessage({ type: CMS_MESSAGES.CANVAS_ACTION, action, ...payload }, targetOrigin);
  };

  return {
    embedded,
    post,
    selectSection: (sectionKey, sectionId) => post('SELECT_SECTION', { sectionKey, sectionId }),
    commitField: (sectionKey, sectionId, fieldKey, value) => post('INLINE_FIELD_CHANGE', { sectionKey, sectionId, fieldKey, value }),
    commitWidgetField: (sectionKey, sectionId, widgetIndex, fieldKey, value) => post('INLINE_WIDGET_CHANGE', { sectionKey, sectionId, widgetIndex, fieldKey, value }),
    commitGlobal: (fieldKey, value) => post('INLINE_GLOBAL_CHANGE', { fieldKey, value }),
    commitCollectionItem: (collectionSlug, itemId, fieldKey, value) => post('INLINE_COLLECTION_ITEM_CHANGE', { collectionSlug, itemId, fieldKey, value }),
    commitNav: (target, value) => post('INLINE_NAV_CHANGE', { ...target, value }),
    focusField: (sectionKey, sectionId, fieldPath, fieldType) => post('FOCUS_FIELD', { sectionKey, sectionId, fieldPath, ...(fieldType ? { fieldType } : {}) }),
    arrayItemAction: (sectionKey, sectionId, fieldPath, index, op) => post('ARRAY_ITEM_ACTION', { sectionKey, sectionId, fieldPath, index, op }),
    focusCollectionItem: (collectionSlug, itemId, fieldKey) => post('FOCUS_COLLECTION_ITEM', { collectionSlug, itemId, ...(fieldKey ? { fieldKey } : {}) }),
    createCollectionItem: (collectionSlug, category) => post('CREATE_COLLECTION_ITEM', { collectionSlug, ...(category ? { category } : {}) }),
    focusGlobal: (fieldKey) => post('FOCUS_GLOBAL', { fieldKey }),
    focusNav: (linkIndex, navList) => post('FOCUS_NAV', { ...(typeof linkIndex === 'number' ? { linkIndex } : {}), ...(navList ? { navList } : {}) }),
    sectionStyleChange: (sectionKey, sectionId, stylePatch) => post('SECTION_STYLE_CHANGE', { sectionKey, sectionId, stylePatch }),
    elementStyleChange: (sectionKey, sectionId, elementId, stylePatch) => post('INLINE_ELEMENT_STYLE_CHANGE', { sectionKey, sectionId, elementId, stylePatch }),
    openAddBlock: (afterSectionId) => post('OPEN_ADD_BLOCK_MODAL', afterSectionId ? { afterSectionId } : {}),
    moveSection: (sectionId, direction) => post('MOVE_SECTION', { sectionId, direction }),
    reorderDrop: (sourceSectionId, targetSectionId) => post('REORDER_DROP', { sourceSectionId, targetSectionId }),
    duplicateSection: (sectionId) => post('DUPLICATE_SECTION', { sectionId }),
    deleteSection: (sectionId) => post('DELETE_SECTION', { sectionId }),
    history: (direction) => post('HISTORY', { direction }),
    destroy: () => {
      if (embedded) win.removeEventListener('message', onMessage);
      hovered?.removeAttribute('data-cms-hover');
    },
  };
}

// ---------- cambios locales optimistas (el portal confirma con CMS_LIVE_PREVIEW_STATE) ----------

export interface SectionTarget {
  id?: string;
  key: string;
}

/** Reemplaza `data` de la sección (por id; si no hay id, por clave) en la página indicada. */
export function updateSectionData(p: DeliveryPayload, pageSlug: string, section: SectionTarget, update: (data: SectionData) => SectionData): DeliveryPayload {
  const target = normalizePageSlug(pageSlug);
  let touched = false;
  const pages = p.pages.map((pg) => {
    if (normalizePageSlug(pg.slug) !== target) return pg;
    const byId = Boolean(section.id) && (pg.sectionsList || []).some((s) => s.id === section.id);
    const list = (pg.sectionsList || []).map((s) => {
      if (byId ? s.id === section.id : s.key === section.key) {
        touched = true;
        return { ...s, data: update(s.data || {}) };
      }
      return s;
    });
    const sections = { ...(pg.sections || {}) };
    const row = list.find((s) => s.key === section.key);
    if (row && row.isVisible !== false) sections[section.key] = row.data || {};
    return { ...pg, sectionsList: list, sections };
  });
  return touched ? { ...p, pages } : p;
}

/** `INLINE_FIELD_CHANGE` local: asigna `path` (con puntos) sin perder hermanos. */
export function applyFieldChange(p: DeliveryPayload, pageSlug: string, section: SectionTarget, path: string, value: unknown): DeliveryPayload {
  return updateSectionData(p, pageSlug, section, (d) => setPath(d, path, value));
}

/** `ARRAY_ITEM_ACTION` local (excepto `add`, que espera los valores por defecto del portal). */
export function applyArrayChange(p: DeliveryPayload, pageSlug: string, section: SectionTarget, path: string, index: number, op: ArrayOp): DeliveryPayload {
  if (op === 'add') return p;
  return updateSectionData(p, pageSlug, section, (d) => applyArrayOp(d, path, index, op));
}

/** `INLINE_ELEMENT_STYLE_CHANGE` local (`null` borra el estilo del elemento). */
export function applyElementStyleChange(p: DeliveryPayload, pageSlug: string, section: SectionTarget, elementId: string, patch: Record<string, unknown> | null): DeliveryPayload {
  return updateSectionData(p, pageSlug, section, (d) => {
    const map = { ...(d._elementStyles || {}) } as Record<string, any>;
    if (patch === null) delete map[elementId];
    else map[elementId] = { ...(map[elementId] || {}), ...patch };
    return { ...d, _elementStyles: map };
  });
}

/** `SECTION_STYLE_CHANGE` local: fusiona en `_style`. */
export function applySectionStyleChange(p: DeliveryPayload, pageSlug: string, section: SectionTarget, patch: Record<string, unknown>): DeliveryPayload {
  return updateSectionData(p, pageSlug, section, (d) => ({ ...d, _style: { ...(d._style || {}), ...patch } }));
}

/** `INLINE_GLOBAL_CHANGE` local (acepta ruta con puntos). */
export function applyGlobalChange(p: DeliveryPayload, fieldKey: string, value: unknown): DeliveryPayload {
  return { ...p, global: setPath(p.global || {}, fieldKey, value) };
}

/** `INLINE_NAV_CHANGE` local. */
export function applyNavChange(p: DeliveryPayload, target: NavChangeTarget, value: unknown): DeliveryPayload {
  const nav = { ...(p.navigation || {}) } as Record<string, any>;
  if (typeof target.linkIndex === 'number') {
    const list = target.navList || 'headerLinks';
    const links = Array.isArray(nav[list]) ? [...nav[list]] : [];
    if (!links[target.linkIndex]) return p;
    links[target.linkIndex] = { ...links[target.linkIndex], [target.fieldKey || 'label']: value };
    nav[list] = links;
  } else if (target.promoField) nav.promoBanner = { ...(nav.promoBanner || {}), [target.promoField]: value };
  else if (target.fieldKey) nav[target.fieldKey] = value;
  else return p;
  return { ...p, navigation: nav };
}

/** `INLINE_COLLECTION_ITEM_CHANGE` local. */
export function applyCollectionItemChange(p: DeliveryPayload, collectionSlug: string, itemId: string, fieldKey: string, value: unknown): DeliveryPayload {
  const list = p.collections?.[collectionSlug];
  if (!Array.isArray(list)) return p;
  return { ...p, collections: { ...p.collections, [collectionSlug]: list.map((it) => (it.id === itemId ? setPath(it, fieldKey, value) : it)) } };
}
