'use client';

import React, { useEffect, useMemo } from 'react';
import type { CmsSectionRef, SectionData } from '../types.js';
import { getSection, getSections, normalizePageSlug } from '../delivery.js';
import { sectionAttrs, sectionDomId } from '../attrs.js';
import { buildSectionCss, sectionAnchor } from '../css.js';
import { getBlockSchema } from '../fields.js';
import { SectionContext, useCms, useOptionalCms, type CmsContextValue } from './context.js';

/** `useSection('hero')` (página activa) o `useSection('/producto', 'detalle')`. */
export function useSection<T extends SectionData = SectionData>(pageOrKey: string, key?: string): CmsSectionRef<T> {
  const { payload, pageSlug } = useCms();
  return key ? getSection<T>(payload, pageOrKey, key) : getSection<T>(payload, pageSlug, pageOrKey);
}

/** Secciones visibles y ordenadas de una página (por defecto la activa). */
export function useSections(pageSlug?: string, opts: { includeHidden?: boolean } = {}): CmsSectionRef[] {
  const { payload, pageSlug: active } = useCms();
  const page = pageSlug ?? active;
  return useMemo(() => getSections(payload, page, opts), [payload, page, opts.includeHidden]);
}

type SectionLike = Pick<CmsSectionRef, 'id' | 'key'> & { block?: string | null; data?: SectionData; name?: string };

/**
 * Atributos para que el portal encuentre, resalte y seleccione una sección en tu propio elemento:
 * `<section {...cmsSectionProps(s, cms)}>`. (La selección la hace el runtime del lienzo.)
 */
export function cmsSectionProps(s: SectionLike, _ctx?: Pick<CmsContextValue, 'isBuilder' | 'selectSection'>) {
  return {
    ...sectionAttrs({ id: s.id, key: s.key, block: s.block || s.data?._block }, { withId: false }),
    'data-cms-section': s.key,
  };
}

export interface CmsSectionProps extends Omit<React.HTMLAttributes<HTMLElement>, 'children'> {
  /** Sección (de useSection / getSections). Alias: `section`. */
  s?: SectionLike;
  section?: SectionLike;
  as?: React.ElementType;
  label?: string;
  /** Posición en la página (para habilitar subir/bajar). Si falta se calcula. */
  index?: number;
  total?: number;
  /** Ocultar la barra del editor (p. ej. en cabeceras fijas). */
  toolbar?: boolean;
  children?: React.ReactNode;
}

/**
 * Raíz de sección: `id="cms-section-<key>"`, `data-section-key/-id/-block`, CSS de `_style`,
 * `_elementStyles` y `_customCss`, ancla `_style.anchorId`, ocultar por dispositivo y, en el
 * editor, barra con arrastrar, subir, bajar, duplicar, eliminar, agregar bloque después y Art.
 */
export function CmsSection({ s: sProp, section: sectionProp, as: Tag = 'section', id, className, label, index, total, toolbar = true, style, children, ...rest }: CmsSectionProps) {
  const cms = useCms();
  const s = (sProp || sectionProp)!;
  const full: CmsSectionRef = useMemo(() => {
    if ('data' in s && s.data && 'order' in (s as any)) return s as CmsSectionRef;
    const found = getSection(cms.payload, cms.pageSlug, s.key);
    return { ...found, ...(s as any), data: s.data || found.data, block: s.block ?? found.block };
  }, [s, cms.payload, cms.pageSlug]);
  const data = full.data || {};
  const pageList = useMemo(() => (index === undefined || total === undefined ? getSections(cms.payload, cms.pageSlug) : null), [cms.payload, cms.pageSlug, index, total]);
  const idx = index ?? Math.max(0, pageList?.findIndex((x) => x.id === full.id || x.key === full.key) ?? 0);
  const count = total ?? pageList?.length ?? 1;
  const css = buildSectionCss({ key: full.key, data }, { isBuilder: cms.isBuilder });
  const anchor = sectionAnchor(data);
  const domId = sectionDomId(full.key);
  const rootId = id || domId;
  const needsAnchor = Boolean((anchor && anchor !== rootId) || (id && id !== domId));
  const styled = data._elementStyles && Object.keys(data._elementStyles).length > 0;
  const name = label || full.name || getBlockSchema(full.block)?.label || full.key;

  return (
    <SectionContext.Provider value={{ section: full, index: idx, total: count }}>
      <Tag
        {...rest}
        {...sectionAttrs({ id: full.id, key: full.key, block: full.block || data._block }, { withId: false })}
        id={rootId}
        data-cms-section={full.key}
        data-cms-styled={styled ? 'true' : undefined}
        aria-label={rest['aria-label'] ?? label}
        className={className}
        style={needsAnchor ? { position: 'relative', ...style } : style}
      >
        {css ? <style data-cms-section-css={full.key} dangerouslySetInnerHTML={{ __html: css }} /> : null}
        {needsAnchor && anchor && anchor !== rootId ? <Anchor id={anchor} /> : null}
        {needsAnchor && id && id !== domId ? <Anchor id={domId} /> : null}
        {cms.isBuilder && toolbar ? <SectionToolbar section={full} name={name} index={idx} total={count} /> : null}
        {children}
        {cms.isBuilder && toolbar ? (
          <div className="cms-ui cms-ui-add-after">
            <button type="button" onClick={() => cms.bridge?.openAddBlock(full.id)} title="Agregar un bloque debajo de esta sección">
              + Agregar bloque
            </button>
          </div>
        ) : null}
      </Tag>
    </SectionContext.Provider>
  );
}

function Anchor({ id }: { id: string }) {
  return (
    <span
      id={id}
      aria-hidden="true"
      data-cms-anchor=""
      style={{ position: 'absolute', top: 0, left: 0, width: 0, height: 0, overflow: 'hidden', scrollMarginTop: 'var(--cms-anchor-offset, 80px)' }}
    />
  );
}

function SectionToolbar({ section, name, index, total }: { section: CmsSectionRef; name: string; index: number; total: number }) {
  const cms = useCms();
  const b = cms.bridge;
  const askArt = () => {
    b?.selectSection(section.key, section.id);
    b?.post('OPEN_AI_AGENT_FOR_ELEMENT', {
      sectionKey: section.key,
      sectionId: section.id,
      elementId: `${section.key}::section`,
      label: `Sección: ${name}`,
      tagName: 'section',
      textPreview: '',
      scope: 'section',
    });
  };
  return (
    <div className="cms-ui cms-ui-toolbar" role="toolbar" aria-label={`Sección ${name}`}>
      <span className="cms-ui-btn cms-ui-grip" draggable data-cms-drag-handle="" title="Arrastra para mover la sección" aria-label="Arrastrar sección">
        ⋮⋮
      </span>
      <span className="cms-ui-name" title={name} onClick={() => cms.selectSection(section.key, section.id)}>
        {name}
      </span>
      <span className="cms-ui-sep" />
      <button type="button" disabled={index <= 0} onClick={() => b?.moveSection(section.id, 'UP')} title="Subir sección" aria-label="Subir sección">
        ↑
      </button>
      <button type="button" disabled={index >= total - 1} onClick={() => b?.moveSection(section.id, 'DOWN')} title="Bajar sección" aria-label="Bajar sección">
        ↓
      </button>
      <button type="button" onClick={() => b?.duplicateSection(section.id)} title="Duplicar sección" aria-label="Duplicar sección">
        ⧉
      </button>
      <button type="button" data-tone="danger" onClick={() => b?.deleteSection(section.id)} title="Eliminar sección" aria-label="Eliminar sección">
        ✕
      </button>
      <span className="cms-ui-sep" />
      <button type="button" onClick={() => b?.openAddBlock(section.id)} title="Agregar bloque después" aria-label="Agregar bloque después">
        +
      </button>
      <button type="button" onClick={askArt} title="Pedir cambios a Art" aria-label="Pedir cambios a Art">
        ✦ Art
      </button>
    </div>
  );
}

/** Botón del editor para insertar una sección (al final de la página o después de `afterSectionId`). */
export function CmsAddSection({ afterSectionId, label = 'Agregar sección' }: { afterSectionId?: string; label?: string }) {
  const cms = useOptionalCms();
  if (!cms?.isBuilder) return null;
  return (
    <div className="cms-ui cms-ui-addbar">
      <button type="button" onClick={() => cms.bridge?.openAddBlock(afterSectionId)}>
        {`+ ${label}`}
      </button>
    </div>
  );
}

// ───────────── registro de bloques y <CmsPage> ─────────────

export interface CmsBlockProps<T extends SectionData = SectionData> {
  section: CmsSectionRef<T>;
  data: T;
  index: number;
  pageSlug: string;
}

export type CmsBlockComponent = React.ComponentType<CmsBlockProps<any>>;

/** Clave de sección, tipo de bloque (`hero.split`) o familia (`hero`) → componente. */
export type CmsRegistry = Record<string, CmsBlockComponent | undefined>;

/**
 * Registro global que otros módulos pueden extender (p. ej. el compositor:
 * `defaultRegistry['layout.composer'] = ComposerBlock`). <CmsPage> lo consulta después de su `registry`.
 */
export const defaultRegistry: CmsRegistry = {};

export function registerBlock(type: string, component: CmsBlockComponent): void {
  defaultRegistry[type] = component;
}

/** Componente para una sección: clave → bloque → familia del bloque, en `registry` y luego en `defaultRegistry`. */
export function resolveBlockComponent(section: Pick<CmsSectionRef, 'key' | 'block'>, registry: CmsRegistry = {}, fallback?: CmsBlockComponent): CmsBlockComponent | undefined {
  const block = section.block || '';
  const family = block.split('.')[0];
  for (const reg of [registry, defaultRegistry]) {
    const hit = reg[section.key] || (block ? reg[block] : undefined) || (family ? reg[family] : undefined);
    if (hit) return hit;
  }
  return fallback;
}

export interface CmsPageProps {
  /** Página del CMS ('/', '/servicios', '/producto'…). Por defecto la activa. */
  pageSlug?: string;
  registry?: CmsRegistry;
  /** Para secciones sin componente registrado. Sin fallback: placeholder en el editor, nada en público. */
  fallback?: CmsBlockComponent;
  /** Elemento raíz de cada sección (por defecto `section`). */
  sectionAs?: React.ElementType;
  sectionClassName?: string | ((s: CmsSectionRef) => string | undefined);
  /** Mostrar el botón "Agregar sección" al final en el editor. Por defecto true. */
  addSection?: boolean;
}

/** Renderiza las secciones visibles de la página en el orden del CMS, cada una envuelta en <CmsSection>. */
export function CmsPage({ pageSlug, registry = {}, fallback, sectionAs, sectionClassName, addSection = true }: CmsPageProps) {
  const cms = useCms();
  const page = normalizePageSlug(pageSlug ?? cms.pageSlug);
  const { setActivePage } = cms;
  useEffect(() => {
    if (pageSlug) setActivePage(page);
  }, [pageSlug, page, setActivePage]);
  const sections = useMemo(() => getSections(cms.payload, page), [cms.payload, page]);
  return (
    <>
      {sections.map((s, i) => {
        const Cmp = resolveBlockComponent(s, registry, fallback);
        if (!Cmp && !cms.isBuilder) return null;
        return (
          <CmsSection key={s.id} s={s} as={sectionAs} index={i} total={sections.length} className={typeof sectionClassName === 'function' ? sectionClassName(s) : sectionClassName}>
            {Cmp ? (
              <Cmp section={s} data={s.data} index={i} pageSlug={page} />
            ) : (
              <div className="cms-ui cms-ui-placeholder">
                {`Sección «${s.name || s.key}» (${s.block || 'sin bloque'}): no hay componente registrado en este sitio.`}
              </div>
            )}
          </CmsSection>
        );
      })}
      {addSection ? <CmsAddSection afterSectionId={sections[sections.length - 1]?.id} /> : null}
    </>
  );
}
