import type {
  ComposerColumn,
  ComposerData,
  ComposerElement,
  ComposerElementDef,
  ComposerElementType,
  ComposerFieldDef,
  ComposerRow,
  ComposerSpan,
} from './types.js';

/* ───────────────────────── ids ───────────────────────── */

const ALPHABET = 'abcdefghijklmnopqrstuvwxyz0123456789';

/** Id corto y estable (`r_ab12cd`, `c_…`, `e_…`). */
export function composerId(prefix: 'r' | 'c' | 'e'): string {
  let s = '';
  const rnd =
    typeof crypto !== 'undefined' && typeof (crypto as any).getRandomValues === 'function'
      ? (n: number) => {
          const a = new Uint8Array(n);
          (crypto as any).getRandomValues(a);
          return Array.from(a);
        }
      : (n: number) => Array.from({ length: n }, () => Math.floor(Math.random() * 256));
  for (const b of rnd(6)) s += ALPHABET[b % ALPHABET.length];
  return `${prefix}_${s}`;
}

/* ───────────────────────── field helpers ───────────────────────── */

const opt = (pairs: Array<[string, string]>) => pairs.map(([value, label]) => ({ value, label }));
const f = {
  text: (key: string, label: string, x: Partial<ComposerFieldDef> = {}): ComposerFieldDef => ({ key, type: 'text', label, ...x }),
  area: (key: string, label: string, x: Partial<ComposerFieldDef> = {}): ComposerFieldDef => ({ key, type: 'textarea', label, ...x }),
  rich: (key: string, label: string, x: Partial<ComposerFieldDef> = {}): ComposerFieldDef => ({ key, type: 'richtext', label, ...x }),
  img: (key: string, label: string, x: Partial<ComposerFieldDef> = {}): ComposerFieldDef => ({ key, type: 'image', label, ...x }),
  num: (key: string, label: string, x: Partial<ComposerFieldDef> = {}): ComposerFieldDef => ({ key, type: 'number', label, ...x }),
  bool: (key: string, label: string, x: Partial<ComposerFieldDef> = {}): ComposerFieldDef => ({ key, type: 'boolean', label, ...x }),
  sel: (key: string, label: string, pairs: Array<[string, string]>, x: Partial<ComposerFieldDef> = {}): ComposerFieldDef => ({
    key,
    type: 'select',
    label,
    options: opt(pairs),
    ...x,
  }),
  color: (key: string, label: string, x: Partial<ComposerFieldDef> = {}): ComposerFieldDef => ({ key, type: 'color', label, ...x }),
  link: (key: string, label: string, x: Partial<ComposerFieldDef> = {}): ComposerFieldDef => ({ key, type: 'link', label, ...x }),
  arr: (key: string, label: string, fields: ComposerFieldDef[], x: Partial<ComposerFieldDef> = {}): ComposerFieldDef => ({
    key,
    type: 'array',
    label,
    fields,
    ...x,
  }),
};

export const COMPOSER_ICONS: Array<[string, string]> = [
  ['check', 'Verificación'],
  ['star', 'Estrella'],
  ['heart', 'Corazón'],
  ['shield', 'Escudo'],
  ['clock', 'Reloj'],
  ['truck', 'Envío'],
  ['phone', 'Teléfono'],
  ['mail', 'Correo'],
  ['map-pin', 'Ubicación'],
  ['users', 'Personas'],
  ['award', 'Premio'],
  ['zap', 'Rayo'],
  ['leaf', 'Hoja'],
  ['calendar', 'Calendario'],
  ['chart', 'Gráfica'],
  ['globe', 'Mundo'],
  ['lock', 'Candado'],
  ['message', 'Mensaje'],
  ['sparkles', 'Destellos'],
  ['arrow-right', 'Flecha'],
  ['play', 'Reproducir'],
  ['camera', 'Cámara'],
  ['home', 'Casa'],
  ['briefcase', 'Maletín'],
];

const BUTTON_VARIANTS: Array<[string, string]> = [
  ['primary', 'Principal'],
  ['secondary', 'Secundario'],
  ['outline', 'Contorno'],
  ['link', 'Enlace'],
];

const RATIOS: Array<[string, string]> = [
  ['auto', 'Original'],
  ['1:1', 'Cuadrada 1:1'],
  ['4:3', 'Horizontal 4:3'],
  ['3:2', 'Horizontal 3:2'],
  ['16:9', 'Panorámica 16:9'],
  ['3:4', 'Vertical 3:4'],
  ['4:5', 'Vertical 4:5'],
];

const FORM_FIELD_TYPES: Array<[string, string]> = [
  ['text', 'Texto'],
  ['email', 'Correo'],
  ['tel', 'Teléfono'],
  ['textarea', 'Párrafo'],
  ['select', 'Lista desplegable'],
  ['radio', 'Opción única'],
  ['checkbox', 'Casilla'],
  ['date', 'Fecha'],
  ['number', 'Número'],
];

/* ───────────────────────── element catalog ───────────────────────── */

export const ELEMENT_DEFS: Record<ComposerElementType, ComposerElementDef> = {
  heading: {
    type: 'heading',
    label: 'Título',
    icon: 'heading',
    group: 'basic',
    description: 'Titular con nivel semántico (H1–H6).',
    defaults: () => ({ text: 'Escribe un titular', level: 2, size: 'auto' }),
    fields: [
      f.text('text', 'Texto'),
      f.sel('level', 'Nivel (para buscadores y lectores de pantalla)', [
        ['1', 'H1 — título de la página'],
        ['2', 'H2 — título de sección'],
        ['3', 'H3'],
        ['4', 'H4'],
        ['5', 'H5'],
        ['6', 'H6'],
      ], { required: true }),
      f.sel('size', 'Tamaño visual', [
        ['auto', 'Según el nivel'],
        ['display', 'Muy grande'],
        ['xl', 'Grande'],
        ['lg', 'Mediano'],
        ['md', 'Pequeño'],
        ['sm', 'Muy pequeño'],
      ], { required: true }),
      f.text('eyebrow', 'Antetítulo (opcional)'),
    ],
    inline: ['text', 'eyebrow'],
  },
  text: {
    type: 'text',
    label: 'Párrafo',
    icon: 'text',
    group: 'basic',
    description: 'Texto corrido. Enter con Mayús crea un salto de línea.',
    defaults: () => ({ text: 'Cuenta en una o dos frases qué ofreces y por qué importa.', size: 'md', tone: 'muted' }),
    fields: [
      f.area('text', 'Texto'),
      f.sel('size', 'Tamaño', [
        ['sm', 'Pequeño'],
        ['md', 'Normal'],
        ['lg', 'Destacado'],
      ], { required: true }),
      f.sel('tone', 'Color', [
        ['muted', 'Suave'],
        ['default', 'Igual al título'],
      ], { required: true }),
    ],
    inline: ['text'],
  },
  richtext: {
    type: 'richtext',
    label: 'Texto con formato',
    icon: 'richtext',
    group: 'basic',
    description: 'Negritas, enlaces, listas y subtítulos (Markdown).',
    defaults: () => ({ markdown: 'Escribe aquí. Usa **negrita**, *cursiva*, [enlaces](https://…) y listas:\n\n- Primer punto\n- Segundo punto' }),
    fields: [f.rich('markdown', 'Contenido')],
  },
  image: {
    type: 'image',
    label: 'Imagen',
    icon: 'image',
    group: 'media',
    description: 'Foto con texto alternativo, recorte y enlace opcional.',
    defaults: () => ({ url: '', alt: '', ratio: '4:3', fit: 'cover', focal: '50% 50%', link: '', caption: '', radius: true }),
    fields: [
      f.img('url', 'Imagen'),
      f.text('alt', 'Texto alternativo', { help: 'Describe la imagen para quien no la ve. Déjalo vacío solo si es decorativa.' }),
      f.sel('ratio', 'Proporción', RATIOS, { required: true }),
      f.sel('fit', 'Ajuste', [
        ['cover', 'Rellenar (recorta)'],
        ['contain', 'Completa (sin recortar)'],
      ], { required: true }),
      f.text('focal', 'Punto focal', { placeholder: '50% 50%', help: 'Qué parte se conserva al recortar: «50% 20%» = centro arriba.' }),
      f.text('caption', 'Pie de foto'),
      f.text('link', 'Enlace al hacer clic', { placeholder: '/contacto o https://…' }),
      f.bool('radius', 'Esquinas redondeadas'),
    ],
    inline: ['caption'],
  },
  button: {
    type: 'button',
    label: 'Botón',
    icon: 'button',
    group: 'basic',
    description: 'Un llamado a la acción.',
    defaults: () => ({ label: 'Escríbenos', href: '#contacto', newTab: false, variant: 'primary', size: 'md', fullWidth: false }),
    fields: [
      f.link('link', 'Texto y enlace', { flat: true }),
      f.sel('variant', 'Estilo', BUTTON_VARIANTS, { required: true }),
      f.sel('size', 'Tamaño', [
        ['sm', 'Pequeño'],
        ['md', 'Normal'],
        ['lg', 'Grande'],
      ], { required: true }),
      f.bool('fullWidth', 'Ocupar todo el ancho'),
    ],
    inline: ['label'],
  },
  buttons: {
    type: 'buttons',
    label: 'Grupo de botones',
    icon: 'buttons',
    group: 'basic',
    description: 'Dos o más botones en línea.',
    defaults: () => ({
      items: [
        { label: 'Empezar', href: '#contacto', newTab: false, variant: 'primary' },
        { label: 'Ver más', href: '#', newTab: false, variant: 'secondary' },
      ],
    }),
    fields: [
      f.arr(
        'items',
        'Botones',
        [f.text('label', 'Texto'), f.text('href', 'Enlace', { placeholder: '/contacto, #seccion, https://…' }), f.sel('variant', 'Estilo', BUTTON_VARIANTS, { required: true }), f.bool('newTab', 'Abrir en otra pestaña')],
        { labelField: 'label', singular: 'botón' },
      ),
    ],
    inline: ['items.*.label'],
  },
  spacer: {
    type: 'spacer',
    label: 'Espacio',
    icon: 'spacer',
    group: 'layout',
    description: 'Aire vertical entre elementos.',
    defaults: () => ({ size: 48, sizeMobile: 24 }),
    fields: [f.num('size', 'Alto en computador (px)', { min: 0, max: 400, step: 4 }), f.num('sizeMobile', 'Alto en celular (px)', { min: 0, max: 400, step: 4 })],
  },
  divider: {
    type: 'divider',
    label: 'Separador',
    icon: 'divider',
    group: 'layout',
    description: 'Línea horizontal.',
    defaults: () => ({ width: 'full', thickness: 1, lineStyle: 'solid' }),
    fields: [
      f.sel('width', 'Largo', [
        ['full', 'Todo el ancho'],
        ['short', 'Corto'],
      ], { required: true }),
      f.num('thickness', 'Grosor (px)', { min: 1, max: 8 }),
      f.sel('lineStyle', 'Trazo', [
        ['solid', 'Continuo'],
        ['dashed', 'Guiones'],
        ['dotted', 'Puntos'],
      ], { required: true }),
    ],
  },
  video: {
    type: 'video',
    label: 'Video',
    icon: 'video',
    group: 'media',
    description: 'YouTube, Vimeo o un archivo .mp4.',
    defaults: () => ({ url: '', title: 'Video', ratio: '16:9', poster: '', autoplay: false }),
    fields: [
      f.text('url', 'Enlace del video', { placeholder: 'https://www.youtube.com/watch?v=…' }),
      f.text('title', 'Título (accesibilidad)'),
      f.sel('ratio', 'Proporción', RATIOS.filter(([v]) => v !== 'auto'), { required: true }),
      f.img('poster', 'Imagen de portada (solo .mp4)'),
      f.bool('autoplay', 'Reproducir en silencio y en bucle (solo .mp4)'),
    ],
  },
  embed: {
    type: 'embed',
    label: 'Insertar',
    icon: 'embed',
    group: 'media',
    description: 'Calendly, Typeform, Spotify, Google Calendar y otros servicios seguros.',
    defaults: () => ({ url: '', title: 'Contenido insertado', height: 480 }),
    fields: [
      f.text('url', 'Enlace para insertar', { placeholder: 'https://calendly.com/…', help: 'Solo servicios conocidos (YouTube, Vimeo, Google, Calendly, Typeform, Tally, Spotify, SoundCloud, Airtable).' }),
      f.text('title', 'Título (accesibilidad)'),
      f.num('height', 'Alto (px)', { min: 120, max: 1600, step: 20 }),
    ],
  },
  icon: {
    type: 'icon',
    label: 'Ícono',
    icon: 'sparkles',
    group: 'basic',
    description: 'Ícono decorativo o con significado.',
    defaults: () => ({ name: 'sparkles', size: 32, label: '', framed: true }),
    fields: [
      f.sel('name', 'Ícono', COMPOSER_ICONS, { required: true }),
      f.num('size', 'Tamaño (px)', { min: 12, max: 160 }),
      f.bool('framed', 'Con fondo'),
      f.text('label', 'Significado (si no es decorativo)', { help: 'Déjalo vacío si el texto de al lado ya lo explica.' }),
    ],
  },
  list: {
    type: 'list',
    label: 'Lista',
    icon: 'list',
    group: 'basic',
    description: 'Viñetas, números o íconos.',
    defaults: () => ({
      marker: 'icon',
      icon: 'check',
      items: [{ text: 'Primer beneficio' }, { text: 'Segundo beneficio' }, { text: 'Tercer beneficio' }],
    }),
    fields: [
      f.sel('marker', 'Marcador', [
        ['icon', 'Ícono'],
        ['bullet', 'Viñeta'],
        ['number', 'Números'],
      ], { required: true }),
      f.sel('icon', 'Ícono', COMPOSER_ICONS, { required: true, showIf: { key: 'marker', in: ['icon'] } }),
      f.arr('items', 'Puntos', [f.text('text', 'Texto')], { labelField: 'text', singular: 'punto' }),
    ],
    inline: ['items.*.text'],
  },
  badge: {
    type: 'badge',
    label: 'Etiqueta',
    icon: 'badge',
    group: 'basic',
    description: 'Texto corto destacado: «Nuevo», «Más vendido».',
    defaults: () => ({ text: 'Nuevo', tone: 'accent' }),
    fields: [
      f.text('text', 'Texto'),
      f.sel('tone', 'Color', [
        ['accent', 'Acento'],
        ['primary', 'Principal'],
        ['neutral', 'Neutro'],
        ['outline', 'Contorno'],
      ], { required: true }),
    ],
    inline: ['text'],
  },
  stat: {
    type: 'stat',
    label: 'Cifra',
    icon: 'chart',
    group: 'data',
    description: 'Número grande con su descripción.',
    defaults: () => ({ value: '98%', label: 'clientes que vuelven', prefix: '', suffix: '' }),
    fields: [f.text('prefix', 'Antes del número'), f.text('value', 'Número'), f.text('suffix', 'Después del número'), f.text('label', 'Descripción')],
    inline: ['value', 'label'],
  },
  quote: {
    type: 'quote',
    label: 'Cita',
    icon: 'quote',
    group: 'basic',
    description: 'Testimonio o frase con autor.',
    defaults: () => ({ text: 'El mejor servicio que hemos contratado. Puntuales, claros y atentos.', author: 'Nombre del cliente', role: 'Cargo o ciudad', avatar: '' }),
    fields: [f.area('text', 'Cita'), f.text('author', 'Autor'), f.text('role', 'Cargo o ciudad'), f.img('avatar', 'Foto del autor')],
    inline: ['text', 'author', 'role'],
  },
  form: {
    type: 'form',
    label: 'Formulario',
    icon: 'form',
    group: 'data',
    description: 'Recibe solicitudes en Clientes potenciales.',
    defaults: () => ({
      mode: 'inline',
      formId: 'contacto',
      notifyEmails: '',
      webhookUrl: '',
      submitLabel: 'Enviar',
      successMessage: 'Gracias. Te responderemos muy pronto.',
      redirectTo: '',
      fields: [
        { key: 'nombre', label: 'Nombre', type: 'text', required: true, width: 'half', placeholder: '', options: '' },
        { key: 'email', label: 'Correo', type: 'email', required: true, width: 'half', placeholder: '', options: '' },
        { key: 'telefono', label: 'Teléfono', type: 'tel', required: false, width: 'full', placeholder: '', options: '' },
        { key: 'mensaje', label: '¿En qué te ayudamos?', type: 'textarea', required: false, width: 'full', placeholder: '', options: '' },
      ],
    }),
    fields: [
      f.sel(
        'mode',
        'Campos',
        [
          ['inline', 'Definirlos aquí'],
          ['linked', 'Usar un formulario del sitio (Formulario personalizado)'],
        ],
        { required: true },
      ),
      f.text('formId', 'Identificador del formulario', {
        help: 'Así aparece cada envío en Clientes potenciales. Con «Usar un formulario del sitio», escribe el identificador de esa sección.',
      }),
      f.arr(
        'fields',
        'Campos',
        [
          f.text('label', 'Etiqueta'),
          f.text('key', 'Clave interna', { help: 'Sin espacios: nombre, email, telefono, mensaje…' }),
          f.sel('type', 'Tipo', FORM_FIELD_TYPES, { required: true }),
          f.bool('required', 'Obligatorio'),
          f.sel('width', 'Ancho', [
            ['full', 'Completo'],
            ['half', 'Mitad'],
          ], { required: true }),
          f.text('placeholder', 'Texto de ayuda'),
          f.text('options', 'Opciones (separadas por coma)', { help: 'Solo para lista desplegable u opción única.' }),
        ],
        { labelField: 'label', singular: 'campo', showIf: { key: 'mode', in: ['inline', undefined, ''] } },
      ),
      f.text('notifyEmails', 'Avisar a estos correos (separados por coma)', { showIf: { key: 'mode', in: ['inline', undefined, ''] } }),
      f.text('webhookUrl', 'Webhook (opcional)', { placeholder: 'https://…', showIf: { key: 'mode', in: ['inline', undefined, ''] } }),
      f.text('submitLabel', 'Texto del botón'),
      f.area('successMessage', 'Mensaje al enviar'),
      f.text('redirectTo', 'Ir a esta página al enviar (opcional)', { placeholder: '/gracias' }),
    ],
    inline: ['submitLabel'],
  },
  collection: {
    type: 'collection',
    label: 'Colección',
    icon: 'grid',
    group: 'data',
    description: 'Muestra productos, servicios o entradas de una colección.',
    defaults: () => ({ collection: '', category: '', limit: 6, sort: 'order', layout: 'grid', columns: 3, showFilter: false, showImage: true, showSummary: true, showPrice: true, linkToItem: true }),
    fields: [
      { key: 'source', type: 'collection', label: 'Colección y cantidad', flat: true },
      f.sel(
        'sort',
        'Orden',
        [
          ['order', 'Como en el CMS (destacados primero)'],
          ['newest', 'Más recientes'],
          ['title', 'Alfabético'],
          ['price-asc', 'Precio: menor a mayor'],
          ['price-desc', 'Precio: mayor a menor'],
        ],
        { required: true },
      ),
      f.bool('showFilter', 'Mostrar filtro por categoría'),
      f.sel('layout', 'Disposición', [
        ['grid', 'Cuadrícula'],
        ['list', 'Lista'],
        ['carousel', 'Carrusel'],
      ], { required: true }),
      f.num('columns', 'Columnas (computador)', { min: 1, max: 6 }),
      f.bool('showImage', 'Mostrar imagen'),
      f.bool('showSummary', 'Mostrar resumen'),
      f.bool('showPrice', 'Mostrar precio'),
      f.bool('linkToItem', 'Abrir el detalle al hacer clic'),
    ],
  },
  map: {
    type: 'map',
    label: 'Mapa',
    icon: 'map-pin',
    group: 'media',
    description: 'Ubicación en Google Maps.',
    defaults: () => ({ address: '', height: 360, zoom: 15 }),
    fields: [
      f.text('address', 'Dirección o lugar', { placeholder: 'Calle 10 # 43-12, Medellín' }),
      f.num('height', 'Alto (px)', { min: 160, max: 900, step: 20 }),
      f.num('zoom', 'Acercamiento', { min: 3, max: 20 }),
    ],
  },
  gallery: {
    type: 'gallery',
    label: 'Galería',
    icon: 'gallery',
    group: 'media',
    description: 'Varias fotos en cuadrícula.',
    defaults: () => ({ images: [], columns: 3, ratio: '1:1', gap: 12 }),
    fields: [
      { key: 'images', type: 'gallery', label: 'Fotos' },
      f.num('columns', 'Columnas (computador)', { min: 1, max: 6 }),
      f.sel('ratio', 'Proporción', RATIOS, { required: true }),
      f.num('gap', 'Separación (px)', { min: 0, max: 48 }),
    ],
  },
  card: {
    type: 'card',
    label: 'Tarjeta',
    icon: 'card',
    group: 'layout',
    description: 'Imagen, título, texto y enlace en una caja.',
    defaults: () => ({
      image: '',
      imageAlt: '',
      icon: '',
      eyebrow: '',
      title: 'Título de la tarjeta',
      text: 'Una o dos frases que expliquen este punto.',
      link: { label: '', href: '', newTab: false },
      variant: 'outlined',
    }),
    fields: [
      f.img('image', 'Imagen'),
      f.text('imageAlt', 'Texto alternativo de la imagen'),
      f.sel('icon', 'Ícono (si no hay imagen)', COMPOSER_ICONS),
      f.text('eyebrow', 'Antetítulo'),
      f.text('title', 'Título'),
      f.area('text', 'Texto'),
      f.link('link', 'Enlace'),
      f.sel('variant', 'Estilo', [
        ['outlined', 'Con borde'],
        ['elevated', 'Con sombra'],
        ['filled', 'Con fondo'],
        ['plain', 'Sin caja'],
      ], { required: true }),
    ],
    inline: ['eyebrow', 'title', 'text', 'link.label'],
  },
};

export const ELEMENT_TYPES = Object.keys(ELEMENT_DEFS) as ComposerElementType[];

export const ELEMENT_GROUPS: Array<{ id: ComposerElementDef['group']; label: string }> = [
  { id: 'basic', label: 'Texto y acciones' },
  { id: 'media', label: 'Imágenes y medios' },
  { id: 'layout', label: 'Estructura' },
  { id: 'data', label: 'Datos y formularios' },
];

export function isElementType(t: unknown): t is ComposerElementType {
  return typeof t === 'string' && Object.prototype.hasOwnProperty.call(ELEMENT_DEFS, t);
}

/** Campos de estilo comunes a todos los elementos. */
export const ELEMENT_STYLE_FIELDS: ComposerFieldDef[] = [
  f.sel('align', 'Alineación', [
    ['left', 'Izquierda'],
    ['center', 'Centro'],
    ['right', 'Derecha'],
  ]),
  f.color('color', 'Color del texto'),
  f.color('background', 'Fondo'),
  f.text('fontSize', 'Tamaño de letra', { placeholder: 'sm, md, lg, xl, 2xl o 18px' }),
  f.sel('weight', 'Grosor', [
    ['300', 'Fino'],
    ['400', 'Normal'],
    ['500', 'Medio'],
    ['600', 'Semi negrita'],
    ['700', 'Negrita'],
    ['800', 'Extra negrita'],
  ]),
  f.num('marginTop', 'Margen arriba (px)', { min: -64, max: 240, step: 4 }),
  f.num('marginBottom', 'Margen abajo (px)', { min: -64, max: 240, step: 4 }),
  f.num('padding', 'Relleno (px)', { min: 0, max: 120, step: 4 }),
  f.num('radius', 'Redondeo (px)', { min: 0, max: 64 }),
  f.text('maxWidth', 'Ancho máximo', { placeholder: 'narrow, medium o 480px' }),
  f.bool('hideOnMobile', 'Ocultar en celular'),
  f.bool('hideOnDesktop', 'Ocultar en computador'),
];

export const COLUMN_STYLE_FIELDS: ComposerFieldDef[] = [
  f.sel('align', 'Alineación del contenido', [
    ['start', 'Izquierda'],
    ['center', 'Centro'],
    ['end', 'Derecha'],
  ]),
  f.sel('valign', 'Posición vertical', [
    ['start', 'Arriba'],
    ['center', 'Centro'],
    ['end', 'Abajo'],
    ['stretch', 'Estirar'],
  ]),
  f.num('gap', 'Espacio entre elementos (px)', { min: 0, max: 96, step: 4 }),
  f.color('background', 'Fondo'),
  f.color('color', 'Color del texto'),
  f.num('padding', 'Relleno (px)', { min: 0, max: 120, step: 4 }),
  f.num('radius', 'Redondeo (px)', { min: 0, max: 64 }),
  f.bool('border', 'Borde'),
  f.bool('hideOnMobile', 'Ocultar en celular'),
  f.bool('hideOnDesktop', 'Ocultar en computador'),
];

export const ROW_STYLE_FIELDS: ComposerFieldDef[] = [
  f.num('gap', 'Espacio entre columnas (px)', { min: 0, max: 120, step: 4 }),
  f.sel('align', 'Alineación vertical', [
    ['start', 'Arriba'],
    ['center', 'Centro'],
    ['end', 'Abajo'],
    ['stretch', 'Misma altura'],
  ]),
  f.sel('justify', 'Distribución horizontal', [
    ['start', 'Inicio'],
    ['center', 'Centro'],
    ['end', 'Final'],
    ['between', 'Repartida'],
  ]),
  f.bool('reverseOnMobile', 'Invertir el orden en celular'),
  f.color('background', 'Fondo de la fila'),
  f.color('color', 'Color del texto'),
  f.num('padding', 'Relleno (px)', { min: 0, max: 160, step: 4 }),
  f.num('radius', 'Redondeo (px)', { min: 0, max: 64 }),
  f.num('marginBottom', 'Espacio debajo (px)', { min: 0, max: 240, step: 4 }),
  f.bool('hideOnMobile', 'Ocultar en celular'),
  f.bool('hideOnDesktop', 'Ocultar en computador'),
];

/* ───────────────────────── factories ───────────────────────── */

export function createElement(type: ComposerElementType, props: Record<string, any> = {}): ComposerElement {
  const def = ELEMENT_DEFS[type];
  if (!def) throw new Error(`Tipo de elemento desconocido: ${type}`);
  return { id: composerId('e'), type, props: { ...def.defaults(), ...props }, style: {} };
}

export function clampSpan(n: unknown, fallback = 12): number {
  const v = Math.round(Number(n));
  if (!Number.isFinite(v)) return fallback;
  return Math.min(12, Math.max(1, v));
}

export function normalizeSpan(span: unknown, fallback = 12): ComposerSpan {
  if (typeof span === 'number') return { desktop: clampSpan(span, fallback), tablet: clampSpan(span, fallback), mobile: 12 };
  const s = (span && typeof span === 'object' ? span : {}) as Record<string, unknown>;
  const desktop = clampSpan(s.desktop, fallback);
  return {
    desktop,
    tablet: s.tablet === undefined || s.tablet === null || s.tablet === '' ? desktop : clampSpan(s.tablet, desktop),
    mobile: s.mobile === undefined || s.mobile === null || s.mobile === '' ? 12 : clampSpan(s.mobile, 12),
  };
}

export function createColumn(span: number | ComposerSpan = 12, elements: ComposerElement[] = []): ComposerColumn {
  return { id: composerId('c'), span: normalizeSpan(span), style: {}, elements };
}

/** `createRow([6, 6])` → dos columnas a la mitad (en celular, una debajo de otra). */
export function createRow(spans: number[] = [12], columns?: ComposerColumn[]): ComposerRow {
  return {
    id: composerId('r'),
    style: { gap: 32 },
    columns: columns || spans.map((s) => createColumn({ desktop: s, tablet: spans.length > 2 ? Math.max(6, s) : s, mobile: 12 })),
  };
}

/** Plantillas de fila del botón «Añadir fila». */
export const ROW_LAYOUTS: Array<{ id: string; label: string; spans: number[] }> = [
  { id: '12', label: '1 columna', spans: [12] },
  { id: '6-6', label: '2 columnas', spans: [6, 6] },
  { id: '4-8', label: '1/3 + 2/3', spans: [4, 8] },
  { id: '8-4', label: '2/3 + 1/3', spans: [8, 4] },
  { id: '5-7', label: '5 + 7', spans: [5, 7] },
  { id: '4-4-4', label: '3 columnas', spans: [4, 4, 4] },
  { id: '3-3-3-3', label: '4 columnas', spans: [3, 3, 3, 3] },
];

/** Copia profunda con ids nuevos (duplicar, pegar, insertar diseños). */
export function withFreshIds<T>(node: T): T {
  const walk = (v: any): any => {
    if (Array.isArray(v)) return v.map(walk);
    if (!v || typeof v !== 'object') return v;
    const out: Record<string, any> = {};
    for (const [k, val] of Object.entries(v)) out[k] = walk(val);
    if (typeof out.id === 'string') {
      if (Array.isArray(out.columns)) out.id = composerId('r');
      else if (Array.isArray(out.elements)) out.id = composerId('c');
      else if (typeof out.type === 'string' && out.props) out.id = composerId('e');
    }
    return out;
  };
  return walk(node);
}

/* ───────────────────────── normalize & validate ───────────────────────── */

function obj(v: unknown): Record<string, any> {
  return v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, any>) : {};
}

/**
 * Datos seguros para renderizar: ids presentes, spans 1–12, props por defecto del tipo.
 * No muta la entrada. Los elementos de tipo desconocido se conservan (el renderer los omite).
 * Los ids que faltan se derivan de la posición (`e_x0_1_2`) para que sean estables entre renders.
 */
export function normalizeComposer(input: unknown): ComposerData {
  const data = obj(input);
  const rows = Array.isArray(data.rows) ? data.rows : [];
  return {
    ...data,
    rows: rows.map((r: any, ri: number) => {
      const row = obj(r);
      const cols = Array.isArray(row.columns) && row.columns.length ? row.columns : [{}];
      return {
        ...row,
        id: typeof row.id === 'string' && row.id ? row.id : `r_x${ri}`,
        style: obj(row.style),
        columns: cols.map((c: any, ci: number) => {
          const col = obj(c);
          const els = Array.isArray(col.elements) ? col.elements : [];
          return {
            ...col,
            id: typeof col.id === 'string' && col.id ? col.id : `c_x${ri}_${ci}`,
            span: normalizeSpan(col.span, Math.max(1, Math.floor(12 / cols.length))),
            style: obj(col.style),
            elements: els
              .filter((e: any) => e && typeof e === 'object')
              .map((e: any, ei: number) => {
                const el = obj(e);
                const def = isElementType(el.type) ? ELEMENT_DEFS[el.type] : null;
                return {
                  ...el,
                  id: typeof el.id === 'string' && el.id ? el.id : `e_x${ri}_${ci}_${ei}`,
                  type: el.type,
                  props: def ? { ...def.defaults(), ...obj(el.props) } : obj(el.props),
                  style: obj(el.style),
                };
              }),
          };
        }),
      };
    }),
  } as ComposerData;
}

export interface ComposerIssue {
  path: string;
  level: 'error' | 'warning';
  message: string;
}

const SAFE_HREF = /^(https?:\/\/|mailto:|tel:|#|\/(?!\/)|whatsapp:|cart:|tracking:)/i;

/** Revisa estructura, spans, ids duplicados, enlaces y accesibilidad (alt, niveles de título). */
export function validateComposer(input: unknown): { ok: boolean; issues: ComposerIssue[] } {
  const issues: ComposerIssue[] = [];
  const err = (path: string, message: string) => issues.push({ path, level: 'error', message });
  const warn = (path: string, message: string) => issues.push({ path, level: 'warning', message });
  const data = obj(input);
  if (!Array.isArray(data.rows)) {
    err('rows', 'Falta la lista de filas (rows).');
    return { ok: false, issues };
  }
  const ids = new Set<string>();
  const seeId = (id: unknown, path: string) => {
    if (typeof id !== 'string' || !id) return err(`${path}.id`, 'Falta el id.');
    if (ids.has(id)) err(`${path}.id`, `Id duplicado: ${id}.`);
    ids.add(id);
  };
  let h1 = 0;
  data.rows.forEach((row: any, ri: number) => {
    const rp = `rows.${ri}`;
    if (!row || typeof row !== 'object') return err(rp, 'La fila no es un objeto.');
    seeId(row.id, rp);
    if (!Array.isArray(row.columns) || row.columns.length === 0) return err(`${rp}.columns`, 'La fila no tiene columnas.');
    if (row.columns.length > 12) err(`${rp}.columns`, 'Máximo 12 columnas por fila.');
    row.columns.forEach((col: any, ci: number) => {
      const cp = `${rp}.columns.${ci}`;
      if (!col || typeof col !== 'object') return err(cp, 'La columna no es un objeto.');
      seeId(col.id, cp);
      const span = col.span;
      for (const bp of ['desktop', 'tablet', 'mobile']) {
        const v = typeof span === 'number' ? span : span?.[bp];
        if (v === undefined && bp !== 'desktop') continue;
        if (!Number.isInteger(Number(v)) || Number(v) < 1 || Number(v) > 12) err(`${cp}.span.${bp}`, 'El ancho debe ser un entero entre 1 y 12.');
      }
      if (!Array.isArray(col.elements)) return err(`${cp}.elements`, 'Falta la lista de elementos.');
      col.elements.forEach((el: any, ei: number) => {
        const ep = `${cp}.elements.${ei}`;
        if (!el || typeof el !== 'object') return err(ep, 'El elemento no es un objeto.');
        seeId(el.id, ep);
        if (!isElementType(el.type)) return err(`${ep}.type`, `Tipo desconocido: ${String(el.type)}.`);
        const p = obj(el.props);
        const hrefs: Array<[string, unknown]> = [];
        switch (el.type) {
          case 'heading': {
            const lvl = Number(p.level);
            if (!(lvl >= 1 && lvl <= 6)) err(`${ep}.props.level`, 'El nivel debe estar entre 1 y 6.');
            if (lvl === 1) h1++;
            if (!String(p.text || '').trim()) warn(`${ep}.props.text`, 'Título vacío.');
            break;
          }
          case 'image':
            if (p.url && !String(p.alt || '').trim()) warn(`${ep}.props.alt`, 'Imagen sin texto alternativo.');
            hrefs.push([`${ep}.props.link`, p.link]);
            break;
          case 'button':
            if (!String(p.label || '').trim()) warn(`${ep}.props.label`, 'Botón sin texto.');
            hrefs.push([`${ep}.props.href`, p.href]);
            break;
          case 'buttons':
            (Array.isArray(p.items) ? p.items : []).forEach((b: any, bi: number) => hrefs.push([`${ep}.props.items.${bi}.href`, b?.href]));
            break;
          case 'card':
            if (p.image && !String(p.imageAlt || '').trim()) warn(`${ep}.props.imageAlt`, 'Imagen de tarjeta sin texto alternativo.');
            hrefs.push([`${ep}.props.link.href`, p.link?.href]);
            break;
          case 'gallery':
            (Array.isArray(p.images) ? p.images : []).forEach((g: any, gi: number) => {
              if (g && typeof g === 'object' && g.url && !String(g.alt || '').trim()) warn(`${ep}.props.images.${gi}.alt`, 'Foto sin texto alternativo.');
            });
            break;
          case 'form': {
            const fields = Array.isArray(p.fields) ? p.fields : [];
            if (!fields.length) err(`${ep}.props.fields`, 'El formulario no tiene campos.');
            const keys = new Set<string>();
            fields.forEach((fl: any, fi: number) => {
              const k = String(fl?.key || '').trim();
              if (!k) err(`${ep}.props.fields.${fi}.key`, 'Campo sin clave.');
              else if (keys.has(k)) err(`${ep}.props.fields.${fi}.key`, `Clave repetida: ${k}.`);
              keys.add(k);
            });
            const hasContact = fields.some((fl: any) => ['email', 'tel'].includes(fl?.type) || /^(email|correo|phone|telefono|tel)$/i.test(String(fl?.key || '')));
            if (fields.length && !hasContact) err(`${ep}.props.fields`, 'Agrega un campo de correo o teléfono para poder responder.');
            break;
          }
          default:
            break;
        }
        for (const [hp, href] of hrefs) {
          const h = String(href || '').trim();
          if (h && !SAFE_HREF.test(h)) err(hp, `Enlace no válido: ${h}.`);
        }
      });
    });
  });
  if (h1 > 1) warn('rows', 'Hay más de un título H1 en la sección.');
  return { ok: !issues.some((i) => i.level === 'error'), issues };
}

/** Cuenta filas, columnas y elementos (resúmenes en el inspector y en agentes). */
export function composerStats(input: unknown): { rows: number; columns: number; elements: number } {
  const rows = Array.isArray(obj(input).rows) ? (obj(input).rows as any[]) : [];
  let columns = 0;
  let elements = 0;
  for (const r of rows) {
    const cols = Array.isArray(r?.columns) ? r.columns : [];
    columns += cols.length;
    for (const c of cols) elements += Array.isArray(c?.elements) ? c.elements.length : 0;
  }
  return { rows: rows.length, columns, elements };
}

/** Texto corto que identifica un elemento (árbol de estructura). */
export function elementSummary(el: ComposerElement | undefined | null): string {
  if (!el) return '';
  const p = obj(el.props);
  const pick =
    p.text || p.label || p.title || p.value || p.markdown || p.alt || p.address || p.formId || p.collection || p.url || '';
  const s = String(pick).replace(/[*_#>\[\]()`]/g, '').replace(/\s+/g, ' ').trim();
  if (el.type === 'buttons') return (Array.isArray(p.items) ? p.items : []).map((b: any) => b?.label).filter(Boolean).join(' · ');
  if (el.type === 'list') return (Array.isArray(p.items) ? p.items : []).map((b: any) => b?.text).filter(Boolean).slice(0, 3).join(' · ');
  if (el.type === 'gallery') return `${Array.isArray(p.images) ? p.images.length : 0} fotos`;
  if (el.type === 'spacer') return `${p.size ?? 0} px`;
  return s.length > 42 ? `${s.slice(0, 41)}…` : s;
}
