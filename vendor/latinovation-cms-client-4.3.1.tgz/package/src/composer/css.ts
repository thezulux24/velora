/**
 * Estilos del compositor. Todo valor visual sale de las variables del design system v2
 * (`--cms-*`, docs/EDITING-V4.1.md §A) con respaldos neutros; nada de colores de marca fijos.
 * Las reglas viven bajo `.cmp` y los cortes de dispositivo usan container queries, así una
 * sección angosta (o el lienzo del portal en modo celular) se comporta como en un teléfono.
 *
 * El cromo del editor (`[data-cmp-builder]`) usa un azul fijo de herramienta, igual al del
 * lienzo del portal, porque no forma parte del diseño del sitio.
 */
const RAW = /* css */ `
.cmp {
  --cmp-fg: var(--cms-text, currentColor);
  --cmp-muted: var(--cms-muted, color-mix(in srgb, currentColor 70%, transparent));
  --cmp-border: var(--cms-border, color-mix(in srgb, currentColor 16%, transparent));
  --cmp-surface: var(--cms-surface, color-mix(in srgb, currentColor 4%, transparent));
  --cmp-surface-alt: var(--cms-surface-alt, color-mix(in srgb, currentColor 7%, transparent));
  --cmp-primary: var(--cms-primary, #1f2937);
  --cmp-primary-fg: var(--cms-primary-text, #fff);
  --cmp-secondary: var(--cms-secondary, var(--cmp-surface-alt));
  --cmp-secondary-fg: var(--cms-secondary-text, var(--cmp-fg));
  --cmp-accent: var(--cms-accent, var(--cmp-primary));
  --cmp-danger: var(--cms-danger, #b42318);
  --cmp-success: var(--cms-success, #1e7a4c);
  --cmp-font-h: var(--cms-font-heading, inherit);
  --cmp-font-b: var(--cms-font-body, inherit);
  --cmp-h-weight: var(--cms-heading-weight, 600);
  --cmp-h-case: var(--cms-heading-case, none);
  --cmp-h-track: var(--cms-heading-tracking, -0.015em);
  --cmp-lh: var(--cms-line-height, 1.6);
  --cmp-r-sm: var(--cms-radius-sm, 4px);
  --cmp-r-md: var(--cms-radius-md, 8px);
  --cmp-r-lg: var(--cms-radius-lg, 16px);
  --cmp-r-full: var(--cms-radius-full, 999px);
  --cmp-bw: var(--cms-border-width, 1px);
  --cmp-shadow: var(--cms-shadow-md, 0 10px 30px -14px rgb(0 0 0 / 0.22));
  --cmp-btn-r: var(--cms-btn-radius, var(--cmp-r-md));
  --cmp-btn-py: var(--cms-btn-py, 12px);
  --cmp-btn-px: var(--cms-btn-px, 22px);
  --cmp-btn-w: var(--cms-btn-weight, 600);
  --cmp-btn-case: var(--cms-btn-case, none);
  --cmp-max: var(--cms-max-width, 1240px);
  --cmp-gutter: var(--cms-gutter, clamp(20px, 4vw, 48px));
  --cmp-y: var(--cms-section-y, clamp(64px, 8vw, 112px));
  --cmp-y-m: var(--cms-section-y-mobile, 64px);
  --cmp-dur: var(--cms-duration, 200ms);
  --cmp-ease: cubic-bezier(0.22, 1, 0.36, 1);
  container: cmp / inline-size;
  color: var(--cmp-fg);
  font-family: var(--cmp-font-b);
  line-height: var(--cmp-lh);
}
.cmp *, .cmp *::before, .cmp *::after { box-sizing: border-box; }
.cmp-wrap { --py: var(--cmp-y); width: 100%; max-width: var(--cmp-max); margin-inline: auto; padding: var(--py) var(--cmp-gutter); display: flex; flex-direction: column; }
.cmp[data-spacing='none'] > .cmp-wrap { --py: 0px; }
.cmp[data-spacing='sm'] > .cmp-wrap { --py: calc(var(--cmp-y) * 0.5); }
.cmp[data-spacing='lg'] > .cmp-wrap { --py: calc(var(--cmp-y) * 1.35); }
.cmp[data-width='narrow'] .cmp-wrap { max-width: 800px; }
.cmp[data-width='wide'] .cmp-wrap { max-width: 1480px; }
.cmp[data-width='full'] .cmp-wrap { max-width: none; padding-inline: 0; }

.cmp-row {
  --g: 32px;
  display: flex;
  flex-wrap: wrap;
  gap: var(--g);
  align-items: flex-start;
  justify-content: flex-start;
  position: relative;
}
.cmp-row + .cmp-row { margin-top: var(--cmp-row-space, 48px); }
.cmp-row[data-align='center'] { align-items: center; }
.cmp-row[data-align='end'] { align-items: flex-end; }
.cmp-row[data-align='stretch'] { align-items: stretch; }
.cmp-row[data-justify='center'] { justify-content: center; }
.cmp-row[data-justify='end'] { justify-content: flex-end; }
.cmp-row[data-justify='between'] { justify-content: space-between; }
.cmp-row[data-boxed] { padding: var(--rp, 32px); border-radius: var(--rr, var(--cmp-r-lg)); }

.cmp-col {
  --span: var(--d, 12);
  flex: 0 0 auto;
  width: calc(var(--span) / 12 * (100% + var(--g)) - var(--g));
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: var(--cg, 16px);
  text-align: left;
  position: relative;
}
.cmp-col[data-valign='start'] { align-self: flex-start; }
.cmp-col[data-valign='center'] { align-self: center; justify-content: center; }
.cmp-col[data-valign='end'] { align-self: flex-end; justify-content: flex-end; }
.cmp-col[data-valign='stretch'] { align-self: stretch; }
.cmp-col[data-boxed] { padding: var(--cp, 0px); border-radius: var(--cr, 0px); }
.cmp-col[data-border] { border: var(--cmp-bw) solid var(--cmp-border); }

.cmp-el { min-width: 0; position: relative; }
.cmp-el[data-align='center'] { text-align: center; }
.cmp-el[data-align='right'] { text-align: right; }
.cmp-el[data-align='center'] > :is(.cmp-p, .cmp-h, .cmp-prose, .cmp-quote, .cmp-list) { margin-inline: auto; }
.cmp-el[data-align='right'] > :is(.cmp-p, .cmp-h, .cmp-prose, .cmp-quote, .cmp-list) { margin-left: auto; }
.cmp-el[data-mw] > * { max-width: var(--mw); }
.cmp-el[data-fs] { font-size: var(--fs); }
.cmp-el[data-fs] > :is(.cmp-h, .cmp-p) { font-size: inherit; }

@container cmp (max-width: 1024px) {
  .cmp-col { --span: var(--t, var(--d, 12)); }
}
@container cmp (max-width: 640px) {
  .cmp-wrap { --py: var(--cmp-y-m); }
  .cmp[data-spacing='none'] > .cmp-wrap { --py: 0px; }
  .cmp[data-spacing='sm'] > .cmp-wrap { --py: calc(var(--cmp-y-m) * 0.5); }
  .cmp[data-spacing='lg'] > .cmp-wrap { --py: calc(var(--cmp-y-m) * 1.25); }
  .cmp-col { --span: var(--m, 12); }
  .cmp-row[data-reverse] { flex-direction: column-reverse; flex-wrap: nowrap; }
  .cmp-row[data-reverse] > .cmp-col { width: 100%; }
  .cmp-row + .cmp-row { margin-top: var(--cmp-row-space-m, 36px); }
  .cmp-hide-m { display: none !important; }
  .cmp-row[data-boxed] { padding: min(var(--rp, 32px), 24px); }
}
@container cmp (min-width: 641px) {
  .cmp-hide-d { display: none !important; }
}

/* Text */
.cmp-eyebrow { display: block; font-size: 0.8125rem; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; color: var(--cmp-accent); margin: 0 0 0.75rem; }
.cmp-h {
  margin: 0;
  font-family: var(--cmp-font-h);
  font-weight: var(--cmp-h-weight);
  text-transform: var(--cmp-h-case);
  letter-spacing: var(--cmp-h-track);
  line-height: 1.12;
  color: inherit;
  text-wrap: balance;
  overflow-wrap: break-word;
}
.cmp-h[data-size='display'] { font-size: clamp(2.5rem, 1.55rem + 4.2vw, 4.75rem); line-height: 1.02; letter-spacing: calc(var(--cmp-h-track) - 0.01em); }
.cmp-h[data-size='xl'] { font-size: clamp(2rem, 1.4rem + 2.4vw, 3.25rem); line-height: 1.06; }
.cmp-h[data-size='lg'] { font-size: clamp(1.5rem, 1.25rem + 1vw, 2.125rem); }
.cmp-h[data-size='md'] { font-size: 1.3125rem; line-height: 1.25; }
.cmp-h[data-size='sm'] { font-size: 1.0625rem; line-height: 1.35; }
.cmp-p { margin: 0; max-width: 68ch; white-space: pre-line; text-wrap: pretty; color: var(--cmp-muted); }
.cmp-p[data-tone='default'] { color: inherit; }
.cmp-p[data-size='sm'] { font-size: 0.9375rem; }
.cmp-p[data-size='md'] { font-size: 1.0625rem; }
.cmp-p[data-size='lg'] { font-size: clamp(1.125rem, 1.05rem + 0.4vw, 1.3125rem); line-height: 1.55; }
.cmp-prose { max-width: 68ch; color: var(--cmp-muted); }
.cmp-prose > * { margin: 0; }
.cmp-prose > * + * { margin-top: 0.9em; }
.cmp-prose :is(h2, h3, h4) { color: var(--cmp-fg); font-family: var(--cmp-font-h); font-weight: var(--cmp-h-weight); letter-spacing: var(--cmp-h-track); line-height: 1.2; margin-top: 1.6em; }
.cmp-prose h2 { font-size: 1.625rem; }
.cmp-prose h3 { font-size: 1.3125rem; }
.cmp-prose h4 { font-size: 1.0625rem; }
.cmp-prose :is(h2, h3, h4):first-child { margin-top: 0; }
.cmp-prose strong { color: var(--cmp-fg); font-weight: 600; }
.cmp-prose a { color: var(--cmp-fg); text-decoration: underline; text-underline-offset: 0.18em; text-decoration-thickness: 1px; }
.cmp-prose ul, .cmp-prose ol { padding-left: 1.25em; }
.cmp-prose ul { list-style: disc; }
.cmp-prose ol { list-style: decimal; }
.cmp-prose li + li { margin-top: 0.35em; }
.cmp-prose blockquote { border-left: 2px solid var(--cmp-accent); padding-left: 1em; color: var(--cmp-fg); }
.cmp-prose code { font-size: 0.9em; padding: 0.1em 0.35em; border-radius: var(--cmp-r-sm); background: var(--cmp-surface-alt); }

/* Buttons */
.cmp-btns { display: flex; flex-wrap: wrap; gap: 12px; }
.cmp-el[data-align='center'] .cmp-btns { justify-content: center; }
.cmp-el[data-align='right'] .cmp-btns { justify-content: flex-end; }
.cmp-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.5em;
  min-height: 44px;
  padding: var(--cmp-btn-py) var(--cmp-btn-px);
  border-radius: var(--cmp-btn-r);
  border: var(--cmp-bw) solid transparent;
  font: inherit;
  font-size: 0.9375rem;
  font-weight: var(--cmp-btn-w);
  text-transform: var(--cmp-btn-case);
  line-height: 1.15;
  text-decoration: none;
  cursor: pointer;
  white-space: nowrap;
  transition: background-color var(--cmp-dur) var(--cmp-ease), border-color var(--cmp-dur) var(--cmp-ease), color var(--cmp-dur) var(--cmp-ease), transform 120ms var(--cmp-ease);
}
.cmp-btn:active { transform: scale(0.98); }
.cmp-btn:focus-visible { outline: 2px solid var(--cmp-accent); outline-offset: 3px; }
.cmp-btn[data-variant='primary'] { background: var(--cmp-primary); color: var(--cmp-primary-fg); }
.cmp-btn[data-variant='primary']:hover { background: color-mix(in srgb, var(--cmp-primary) 86%, var(--cmp-primary-fg)); }
.cmp-btn[data-variant='secondary'] { background: var(--cmp-secondary); color: var(--cmp-secondary-fg); }
.cmp-btn[data-variant='secondary']:hover { background: color-mix(in srgb, var(--cmp-secondary) 88%, var(--cmp-secondary-fg)); }
.cmp-btn[data-variant='outline'] { background: transparent; color: var(--cmp-fg); border-color: color-mix(in srgb, var(--cmp-fg) 30%, transparent); }
.cmp-btn[data-variant='outline']:hover { border-color: var(--cmp-fg); }
.cmp-btn[data-variant='link'] { min-height: 0; padding: 0.25em 0; background: none; color: var(--cmp-fg); text-decoration: underline; text-underline-offset: 0.22em; text-decoration-thickness: 1px; border-radius: 0; }
.cmp-btn[data-variant='link']:hover { text-decoration-thickness: 2px; }
.cmp-btn[data-size='sm'] { min-height: 36px; padding: calc(var(--cmp-btn-py) * 0.66) calc(var(--cmp-btn-px) * 0.7); font-size: 0.875rem; }
.cmp-btn[data-size='lg'] { min-height: 52px; padding: calc(var(--cmp-btn-py) * 1.25) calc(var(--cmp-btn-px) * 1.3); font-size: 1.0625rem; }
.cmp-btn[data-full] { width: 100%; }
.cmp-btn svg { width: 1.1em; height: 1.1em; }

/* Media */
.cmp-fig { margin: 0; }
.cmp-frame { position: relative; overflow: hidden; width: 100%; background: var(--cmp-surface-alt); }
.cmp-frame[data-ratio] { aspect-ratio: var(--ratio); }
.cmp-frame[data-round] { border-radius: var(--cmp-r-lg); }
.cmp-frame > img, .cmp-frame > video, .cmp-frame > iframe { display: block; width: 100%; height: 100%; border: 0; }
.cmp-frame[data-ratio] > img { position: absolute; inset: 0; object-fit: var(--fit, cover); }
.cmp-frame:not([data-ratio]) { background: none; }
.cmp-frame:not([data-ratio]) > img { height: auto; }
.cmp-frame a { display: block; height: 100%; }
.cmp-frame a > img { width: 100%; height: 100%; object-fit: var(--fit, cover); }
.cmp-cap { margin-top: 0.625rem; font-size: 0.875rem; color: var(--cmp-muted); }
.cmp-embed { width: 100%; border: 0; border-radius: var(--cmp-r-md); display: block; background: var(--cmp-surface-alt); }
.cmp-maplink { display: inline-block; margin-top: 0.5rem; font-size: 0.875rem; color: var(--cmp-muted); text-decoration: underline; text-underline-offset: 0.2em; }
.cmp-gallery { display: grid; grid-template-columns: repeat(var(--cols, 3), minmax(0, 1fr)); gap: var(--gg, 12px); }
@container cmp (max-width: 1024px) { .cmp-gallery { grid-template-columns: repeat(min(var(--cols, 3), 3), minmax(0, 1fr)); } }
@container cmp (max-width: 640px) { .cmp-gallery { grid-template-columns: repeat(min(var(--cols, 3), 2), minmax(0, 1fr)); } }

/* Small pieces */
.cmp-spacer { height: var(--h, 48px); }
@container cmp (max-width: 640px) { .cmp-spacer { height: var(--hm, var(--h, 24px)); } }
.cmp-hr { border: 0; border-top: var(--th, 1px) var(--ls, solid) var(--cmp-border); margin: 0; width: 100%; }
.cmp-hr[data-short] { width: 64px; }
.cmp-el[data-align='center'] .cmp-hr[data-short] { margin-inline: auto; }
.cmp-el[data-align='right'] .cmp-hr[data-short] { margin-left: auto; }
.cmp-icon { display: inline-flex; align-items: center; justify-content: center; color: var(--cmp-accent); }
.cmp-icon[data-framed] { padding: 0.55em; border-radius: var(--cmp-r-md); background: color-mix(in srgb, var(--cmp-accent) 12%, transparent); }
.cmp-badge { display: inline-flex; align-items: center; gap: 0.4em; padding: 0.3em 0.75em; border-radius: var(--cmp-r-full); font-size: 0.8125rem; font-weight: 600; line-height: 1.2; }
.cmp-badge[data-tone='accent'] { background: color-mix(in srgb, var(--cmp-accent) 15%, transparent); color: color-mix(in srgb, var(--cmp-accent) 70%, var(--cmp-fg)); }
.cmp-badge[data-tone='primary'] { background: var(--cmp-primary); color: var(--cmp-primary-fg); }
.cmp-badge[data-tone='neutral'] { background: var(--cmp-surface-alt); color: var(--cmp-fg); }
.cmp-badge[data-tone='outline'] { border: var(--cmp-bw) solid var(--cmp-border); color: var(--cmp-fg); }
.cmp-list { display: grid; gap: 0.7rem; margin: 0; padding: 0; list-style: none; max-width: 60ch; }
.cmp-list li { display: flex; gap: 0.7rem; align-items: flex-start; text-align: left; }
.cmp-list__mark { flex: none; display: inline-flex; align-items: center; justify-content: center; width: 1.5em; height: 1.6em; color: var(--cmp-accent); font-weight: 600; font-variant-numeric: tabular-nums; }
.cmp-list__mark svg { width: 1.15em; height: 1.15em; }
.cmp-list__dot { width: 6px; height: 6px; border-radius: 50%; background: currentColor; }
.cmp-el[data-align='center'] .cmp-list li { justify-content: center; }
.cmp-stat { display: grid; gap: 0.35rem; }
.cmp-stat__v { font-family: var(--cmp-font-h); font-weight: var(--cmp-h-weight); font-size: clamp(2.25rem, 1.7rem + 2.2vw, 3.5rem); line-height: 1; letter-spacing: var(--cmp-h-track); font-variant-numeric: tabular-nums; }
.cmp-stat__l { color: var(--cmp-muted); font-size: 0.9375rem; }
.cmp-quote { margin: 0; display: grid; gap: 1.25rem; max-width: 46ch; }
.cmp-quote__t { margin: 0; font-family: var(--cmp-font-h); font-size: clamp(1.1875rem, 1.05rem + 0.6vw, 1.5rem); line-height: 1.4; font-weight: var(--cmp-h-weight); text-wrap: pretty; }
.cmp-quote__by { display: flex; align-items: center; gap: 0.75rem; font-size: 0.9375rem; }
.cmp-el[data-align='center'] .cmp-quote__by { justify-content: center; }
.cmp-quote__by img { width: 44px; height: 44px; border-radius: 50%; object-fit: cover; }
.cmp-quote__a { font-weight: 600; font-style: normal; display: block; }
.cmp-quote__r { color: var(--cmp-muted); display: block; }

/* Card */
.cmp-card { display: flex; flex-direction: column; gap: 0.75rem; height: 100%; text-align: inherit; }
.cmp-card[data-variant='outlined'] { border: var(--cmp-bw) solid var(--cmp-border); border-radius: var(--cmp-r-lg); padding: 24px; }
.cmp-card[data-variant='elevated'] { border-radius: var(--cmp-r-lg); padding: 24px; background: var(--cms-surface, transparent); box-shadow: var(--cmp-shadow); }
.cmp-card[data-variant='filled'] { border-radius: var(--cmp-r-lg); padding: 24px; background: var(--cmp-surface-alt); }
.cmp-card__media { margin: -24px -24px 0.5rem; aspect-ratio: 16 / 10; overflow: hidden; border-radius: var(--cmp-r-lg) var(--cmp-r-lg) 0 0; background: var(--cmp-surface-alt); }
.cmp-card[data-variant='plain'] .cmp-card__media { margin: 0 0 0.5rem; border-radius: var(--cmp-r-lg); }
.cmp-card__media img { width: 100%; height: 100%; object-fit: cover; display: block; }
.cmp-card__icon { align-self: flex-start; }
.cmp-el[data-align='center'] .cmp-card__icon { align-self: center; }
.cmp-card__t { margin: 0; font-family: var(--cmp-font-h); font-weight: var(--cmp-h-weight); letter-spacing: var(--cmp-h-track); font-size: 1.25rem; line-height: 1.25; }
.cmp-card__x { margin: 0; color: var(--cmp-muted); white-space: pre-line; }
.cmp-card__l { margin-top: auto; padding-top: 0.25rem; display: inline-flex; align-items: center; gap: 0.4em; font-weight: 600; color: var(--cmp-fg); text-decoration: none; }
.cmp-card__l:hover { text-decoration: underline; text-underline-offset: 0.2em; }
.cmp-card__l svg { width: 1em; height: 1em; transition: transform var(--cmp-dur) var(--cmp-ease); }
.cmp-card__l:hover svg { transform: translateX(2px); }

/* Collection */
.cmp-items { display: grid; gap: 24px; grid-template-columns: repeat(var(--cols, 3), minmax(0, 1fr)); }
@container cmp (max-width: 1024px) { .cmp-items { grid-template-columns: repeat(min(var(--cols, 3), 2), minmax(0, 1fr)); } }
@container cmp (max-width: 640px) { .cmp-items { grid-template-columns: minmax(0, 1fr); } }
.cmp-items[data-layout='list'] { grid-template-columns: minmax(0, 1fr); gap: 0; }
.cmp-items[data-layout='carousel'] { display: flex; overflow-x: auto; scroll-snap-type: x mandatory; gap: 20px; padding-bottom: 8px; scrollbar-width: thin; }
.cmp-items[data-layout='carousel'] > * { flex: 0 0 calc((100% - (var(--cols, 3) - 1) * 20px) / var(--cols, 3)); scroll-snap-align: start; }
@container cmp (max-width: 640px) { .cmp-items[data-layout='carousel'] > * { flex-basis: 82%; } }
.cmp-item { display: flex; flex-direction: column; gap: 0.5rem; text-decoration: none; color: inherit; min-width: 0; }
.cmp-item__img { aspect-ratio: 4 / 3; overflow: hidden; border-radius: var(--cmp-r-md); background: var(--cmp-surface-alt); margin-bottom: 0.375rem; }
.cmp-item__img img { width: 100%; height: 100%; object-fit: cover; display: block; transition: transform 500ms var(--cmp-ease); }
a.cmp-item:hover .cmp-item__img img { transform: scale(1.03); }
.cmp-item__t { margin: 0; font-weight: 600; font-size: 1.0625rem; line-height: 1.3; }
.cmp-item__s { margin: 0; color: var(--cmp-muted); font-size: 0.9375rem; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
.cmp-item__p { font-weight: 600; font-variant-numeric: tabular-nums; }
.cmp-items[data-layout='list'] .cmp-item { flex-direction: row; align-items: center; gap: 1rem; padding-block: 1rem; border-bottom: var(--cmp-bw) solid var(--cmp-border); }
.cmp-items[data-layout='list'] .cmp-item__img { flex: none; width: 96px; margin: 0; }
.cmp-items[data-layout='list'] .cmp-item__body { flex: 1; min-width: 0; display: grid; gap: 0.25rem; }
.cmp-chips { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 20px; }
.cmp-chip { font: inherit; font-size: 0.875rem; min-height: 36px; padding: 6px 14px; border-radius: var(--cmp-r-full); border: var(--cmp-bw) solid var(--cmp-border); background: transparent; color: var(--cmp-fg); cursor: pointer; transition: background-color var(--cmp-dur) var(--cmp-ease), border-color var(--cmp-dur) var(--cmp-ease); }
.cmp-chip:hover { border-color: var(--cmp-fg); }
.cmp-chip[aria-pressed='true'] { background: var(--cmp-fg); color: var(--cms-bg, #fff); border-color: var(--cmp-fg); }
.cmp-chip:focus-visible { outline: 2px solid var(--cmp-accent); outline-offset: 2px; }
.cmp-empty { padding: 1.25rem; border: 1px dashed var(--cmp-border); border-radius: var(--cmp-r-md); color: var(--cmp-muted); font-size: 0.875rem; text-align: center; }

/* Form */
.cmp-form { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; text-align: left; }
.cmp-field { grid-column: span 2; display: grid; gap: 6px; min-width: 0; }
.cmp-field[data-half] { grid-column: span 1; }
@container cmp (max-width: 640px) { .cmp-field[data-half] { grid-column: span 2; } }
.cmp-field > label, .cmp-field > legend { font-size: 0.875rem; font-weight: 500; color: var(--cmp-fg); padding: 0; }
.cmp-field fieldset { border: 0; margin: 0; padding: 0; display: grid; gap: 8px; }
.cmp-req { color: var(--cmp-danger); margin-left: 2px; }
.cmp-input {
  width: 100%;
  min-height: 46px;
  padding: 10px 14px;
  font: inherit;
  font-size: 1rem;
  color: var(--cmp-fg);
  background: var(--cms-surface, transparent);
  border: var(--cmp-bw) solid color-mix(in srgb, var(--cmp-fg) 22%, transparent);
  border-radius: var(--cmp-r-md);
  transition: border-color var(--cmp-dur) var(--cmp-ease), box-shadow var(--cmp-dur) var(--cmp-ease);
}
textarea.cmp-input { min-height: 120px; resize: vertical; line-height: 1.5; }
.cmp-input:hover { border-color: color-mix(in srgb, var(--cmp-fg) 40%, transparent); }
.cmp-input:focus { outline: none; border-color: var(--cmp-primary); box-shadow: 0 0 0 3px color-mix(in srgb, var(--cmp-primary) 22%, transparent); }
.cmp-input[aria-invalid='true'] { border-color: var(--cmp-danger); }
.cmp-check { display: flex; align-items: center; gap: 10px; font-size: 0.9375rem; min-height: 32px; cursor: pointer; }
.cmp-check input { width: 18px; height: 18px; accent-color: var(--cmp-primary); margin: 0; }
.cmp-form__foot { grid-column: span 2; display: flex; flex-wrap: wrap; align-items: center; gap: 12px 16px; }
.cmp-form__err { grid-column: span 2; color: var(--cmp-danger); font-size: 0.875rem; margin: 0; }
.cmp-form__ok { padding: 20px; border-radius: var(--cmp-r-md); background: color-mix(in srgb, var(--cmp-success) 10%, transparent); color: var(--cmp-fg); border: var(--cmp-bw) solid color-mix(in srgb, var(--cmp-success) 35%, transparent); }
.cmp-hp { position: absolute !important; left: -10000px !important; width: 1px; height: 1px; overflow: hidden; }

@media (prefers-reduced-motion: reduce) {
  .cmp *, .cmp *::before, .cmp *::after { transition-duration: 0.01ms !important; animation-duration: 0.01ms !important; }
}

/* Builder chrome (only with data-cmp-builder) */
.cmp[data-cmp-builder] .cmp-el { cursor: default; border-radius: 2px; }
.cmp[data-cmp-builder] .cmp-el:hover { outline: 1px dashed rgb(37 99 235 / 0.6); outline-offset: 4px; }
.cmp[data-cmp-builder] .cmp-el[data-selected] { outline: 2px solid #2563eb; outline-offset: 4px; }
.cmp[data-cmp-builder] .cmp-col { outline: 1px dashed transparent; outline-offset: 8px; transition: outline-color 120ms; }
.cmp[data-cmp-builder] .cmp-row:hover > .cmp-col { outline-color: rgb(37 99 235 / 0.18); }
.cmp[data-cmp-builder] .cmp-col[data-drop] { outline: 2px dashed #2563eb; background: rgb(37 99 235 / 0.04); }
.cmp[data-cmp-builder] .cmp-el[data-drop='before']::before,
.cmp[data-cmp-builder] .cmp-el[data-drop='after']::after { content: ''; position: absolute; left: 0; right: 0; height: 3px; border-radius: 2px; background: #2563eb; z-index: 5; }
.cmp[data-cmp-builder] .cmp-el[data-drop='before']::before { top: calc(var(--cg, 16px) / -2 - 1px); }
.cmp[data-cmp-builder] .cmp-el[data-drop='after']::after { bottom: calc(var(--cg, 16px) / -2 - 1px); }
.cmp[data-cmp-builder] .cmp-el[data-dragging] { opacity: 0.4; }
.cmp[data-cmp-builder] .cmp-hide-m, .cmp[data-cmp-builder] .cmp-hide-d { display: revert !important; opacity: 0.38; }
.cmp[data-cmp-builder] .cmp-col.cmp-hide-m, .cmp[data-cmp-builder] .cmp-col.cmp-hide-d { display: flex !important; }
.cmp[data-cmp-builder] .cmp-row.cmp-hide-m, .cmp[data-cmp-builder] .cmp-row.cmp-hide-d { display: flex !important; }
.cmp [data-cmp-edit] { outline: none; cursor: text; }
.cmp [data-cmp-edit]:focus { box-shadow: 0 0 0 2px rgb(37 99 235 / 0.35); border-radius: 2px; }
.cmp [data-cmp-edit][data-empty]::before { content: attr(data-placeholder); opacity: 0.45; pointer-events: none; }
.cmp-el:not([data-selected]) [data-cmp-optional][data-empty]:not(:focus) { display: none; }
.cmp-el:not([data-selected]) .cmp-card__l:has(> [data-cmp-optional][data-empty]:not(:focus)) { display: none; }
.cmp-tools {
  position: absolute;
  z-index: 30;
  top: -6px;
  right: 0;
  transform: translateY(-100%);
  display: none;
  align-items: center;
  gap: 1px;
  padding: 3px;
  border-radius: 8px;
  background: #0f172a;
  color: #f8fafc;
  box-shadow: 0 6px 20px -6px rgb(15 23 42 / 0.45);
  font: 500 11px/1 ui-sans-serif, system-ui, sans-serif;
  letter-spacing: 0;
  text-transform: none;
  white-space: nowrap;
}
.cmp-el:hover > .cmp-tools, .cmp-el[data-selected] > .cmp-tools, .cmp-el:focus-within > .cmp-tools { display: inline-flex; }
.cmp-tools__label { padding: 0 6px 0 4px; color: #cbd5e1; }
.cmp-tools button, .cmp-tools [draggable] {
  all: unset;
  box-sizing: border-box;
  width: 26px;
  height: 26px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 5px;
  cursor: pointer;
  color: inherit;
}
.cmp-tools [draggable] { cursor: grab; }
.cmp-tools button:hover, .cmp-tools [draggable]:hover { background: rgb(255 255 255 / 0.12); }
.cmp-tools button:focus-visible { outline: 2px solid #60a5fa; outline-offset: 1px; }
.cmp-tools button[data-danger]:hover { background: rgb(239 68 68 / 0.25); color: #fecaca; }
.cmp-tools button:disabled { opacity: 0.3; cursor: default; background: none; }
.cmp-tools svg { width: 14px; height: 14px; }
.cmp-rowbar { position: absolute; z-index: 25; left: 0; top: -10px; transform: translateY(-100%); display: none; }
.cmp-row:hover > .cmp-rowbar, .cmp-row[data-selected] > .cmp-rowbar, .cmp-row:focus-within > .cmp-rowbar { display: inline-flex; }
.cmp-row[data-selected] { outline: 2px solid rgb(37 99 235 / 0.5); outline-offset: 12px; border-radius: 4px; }
.cmp-rowbar .cmp-tools { position: static; display: inline-flex; transform: none; }
.cmp-add {
  all: unset;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  width: 100%;
  min-height: 56px;
  padding: 12px;
  border: 1px dashed rgb(37 99 235 / 0.45);
  border-radius: 8px;
  color: #1d4ed8;
  background: rgb(37 99 235 / 0.03);
  font: 500 13px/1.2 ui-sans-serif, system-ui, sans-serif;
  cursor: pointer;
  text-align: center;
}
.cmp-add:hover { background: rgb(37 99 235 / 0.08); border-style: solid; }
.cmp-add:focus-visible { outline: 2px solid #2563eb; outline-offset: 2px; }
.cmp-add svg { width: 16px; height: 16px; }
.cmp-add--row { margin-top: 32px; min-height: 44px; opacity: 0; transition: opacity 150ms; }
.cmp:hover .cmp-add--row, .cmp-add--row:focus-visible { opacity: 1; }
.cmp-layouts { display: grid; gap: 12px; padding: 28px; border: 1px dashed rgb(37 99 235 / 0.45); border-radius: 12px; text-align: center; font: 13px/1.4 ui-sans-serif, system-ui, sans-serif; color: #334155; background: rgb(255 255 255 / 0.6); }
.cmp-layouts__opts { display: flex; flex-wrap: wrap; justify-content: center; gap: 8px; }
.cmp-layouts__opts .cmp-add { width: auto; min-height: 40px; padding: 8px 14px; }
.cmp-ph { display: flex; align-items: center; justify-content: center; gap: 8px; width: 100%; height: 100%; min-height: 160px; color: #475569; font: 500 13px/1.3 ui-sans-serif, system-ui, sans-serif; background: repeating-linear-gradient(135deg, rgb(148 163 184 / 0.12) 0 10px, rgb(148 163 184 / 0.05) 10px 20px); border-radius: inherit; cursor: pointer; }
.cmp-hint { font: 12px/1.4 ui-sans-serif, system-ui, sans-serif; color: #475569; padding: 10px 12px; border-radius: 6px; background: rgb(148 163 184 / 0.12); }
`;

/** CSS minificado (sin comentarios ni espacios redundantes). */
export const COMPOSER_CSS = RAW.replace(/\/\*[\s\S]*?\*\//g, '')
  .replace(/\s+/g, ' ')
  .replace(/\s*([{};,>])\s*/g, '$1')
  .replace(/;}/g, '}')
  .trim();
