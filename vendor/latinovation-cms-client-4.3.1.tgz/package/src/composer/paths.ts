import type { ComposerColumn, ComposerData, ComposerElement, ComposerOp, ComposerRow, ComposerSpan } from './types.js';
import { clampSpan, createColumn, createElement, createRow, isElementType, normalizeSpan, withFreshIds } from './model.js';

/**
 * Rutas del compositor (las mismas que usa el lienzo en INLINE_FIELD_CHANGE y FOCUS_FIELD):
 *
 *   rows.0                               fila
 *   rows.0.columns.1                     columna
 *   rows.0.columns.1.elements.2          elemento
 *   rows.0.columns.1.elements.2.props.text   campo de un elemento
 */
export type NodeKind = 'row' | 'column' | 'element';

export interface ParsedPath {
  kind: NodeKind;
  row: number;
  col: number;
  el: number;
  /** Lo que sigue al nodo (`props.text`), vacío si la ruta apunta al nodo. */
  rest: string;
  /** Ruta del nodo sin `rest`. */
  node: string;
}

const RE = /^rows\.(\d+)(?:\.columns\.(\d+)(?:\.elements\.(\d+))?)?(?:\.(.+))?$/;

export function parseComposerPath(path: string): ParsedPath | null {
  const m = RE.exec(String(path || '').trim());
  if (!m) return null;
  const row = Number(m[1]);
  const col = m[2] === undefined ? -1 : Number(m[2]);
  const el = m[3] === undefined ? -1 : Number(m[3]);
  const kind: NodeKind = el >= 0 ? 'element' : col >= 0 ? 'column' : 'row';
  const node = kind === 'element' ? `rows.${row}.columns.${col}.elements.${el}` : kind === 'column' ? `rows.${row}.columns.${col}` : `rows.${row}`;
  return { kind, row, col, el, rest: m[4] || '', node };
}

export const rowPath = (r: number) => `rows.${r}`;
export const columnPath = (r: number, c: number) => `rows.${r}.columns.${c}`;
export const elementPath = (r: number, c: number, e: number) => `rows.${r}.columns.${c}.elements.${e}`;

export function getPath(obj: any, path: string): any {
  if (!path) return obj;
  return path.split('.').reduce((acc, k) => (acc == null ? undefined : acc[k]), obj);
}

/** Asignación inmutable por ruta con puntos (los segmentos numéricos indexan arrays). */
export function setPath<T>(obj: T, path: string, value: unknown): T {
  if (!path) return value as T;
  const [head, ...rest] = path.split('.');
  const isIndex = /^\d+$/.test(head);
  const base: any = obj == null ? (isIndex ? [] : {}) : obj;
  const copy: any = Array.isArray(base) ? [...base] : { ...base };
  const k = isIndex ? Number(head) : head;
  copy[k] = rest.length ? setPath(base[k], rest.join('.'), value) : value;
  return copy;
}

/** Nodo (fila, columna o elemento) en la ruta, o undefined. */
export function getNode(data: ComposerData, path: string): ComposerRow | ComposerColumn | ComposerElement | undefined {
  const p = parseComposerPath(path);
  if (!p) return undefined;
  const row = data?.rows?.[p.row];
  if (p.kind === 'row') return row;
  const col = row?.columns?.[p.col];
  if (p.kind === 'column') return col;
  return col?.elements?.[p.el];
}

/** Busca la ruta de un nodo por id. */
export function findPathById(data: ComposerData, id: string): string | null {
  const rows = data?.rows || [];
  for (let r = 0; r < rows.length; r++) {
    if (rows[r]?.id === id) return rowPath(r);
    const cols = rows[r]?.columns || [];
    for (let c = 0; c < cols.length; c++) {
      if (cols[c]?.id === id) return columnPath(r, c);
      const els = cols[c]?.elements || [];
      for (let e = 0; e < els.length; e++) if (els[e]?.id === id) return elementPath(r, c, e);
    }
  }
  return null;
}

/* ───────────────────────── internals ───────────────────────── */

function cloneRows(data: ComposerData): ComposerRow[] {
  return (data?.rows || []).map((r) => ({ ...r, columns: (r.columns || []).map((c) => ({ ...c, elements: [...(c.elements || [])] })) }));
}

function clampIndex(i: number, len: number) {
  return Math.max(0, Math.min(len, i));
}

function rebalance(columns: ComposerColumn[]): ComposerColumn[] {
  const n = columns.length;
  if (!n || 12 % n !== 0) return columns;
  const s = 12 / n;
  return columns.map((c) => ({ ...c, span: { desktop: s, tablet: n > 2 ? Math.max(6, s) : s, mobile: 12 } }));
}

function evenlySplit(columns: ComposerColumn[]): boolean {
  if (!columns.length) return true;
  const first = normalizeSpan(columns[0].span).desktop;
  return columns.every((c) => normalizeSpan(c.span).desktop === first);
}

export interface OpResult {
  data: ComposerData;
  /** Ruta del nodo afectado o creado (para mantener la selección). */
  path: string | null;
}

export class ComposerOpError extends Error {}

function fail(msg: string): never {
  throw new ComposerOpError(msg);
}

function nodeKindOf(node: any): NodeKind | null {
  if (!node || typeof node !== 'object') return null;
  if (Array.isArray(node.columns)) return 'row';
  if (Array.isArray(node.elements)) return 'column';
  if (isElementType(node.type)) return 'element';
  return null;
}

/** Inserta un elemento en la columna `r,c` en el índice `at`. */
function insertElement(rows: ComposerRow[], r: number, c: number, at: number, el: ComposerElement): string {
  const col = rows[r]?.columns?.[c];
  if (!col) fail('Columna inexistente.');
  const i = clampIndex(at, col.elements.length);
  col.elements.splice(i, 0, el);
  return elementPath(r, c, i);
}

/**
 * Aplica una operación del compositor (mismas `op` que COMPOSER_ACTION). Es pura: devuelve datos nuevos.
 *
 * - `add_row`      path: fila de referencia o '' (al final). payload: { spans?, row?, position?: 'before'|'after' }
 * - `add_column`   path: fila (al final) o columna (después). payload: { span? }
 * - `add_element`  path: columna (al final), elemento (después; position 'before' para antes) o fila (1.ª columna).
 *                  payload: { type, props?, element? }
 * - `duplicate`, `remove`, `move_up`, `move_down`  path: cualquier nodo
 * - `move_to`      path: nodo origen. payload: { targetPath, position?: 'before'|'after' }
 *                  elemento → columna (al final) o elemento (antes); columna → fila o columna; fila → fila
 * - `set_span`     path: columna. payload: { span: { desktop?, tablet?, mobile? } } o { breakpoint, value }
 * - `wrap_in_row`  path: elemento o columna → lo saca a una fila nueva debajo de su fila
 * - `update`       path: nodo. payload: { props?, style?, span? } (se fusionan) o path con campo + { value }
 * - `paste`        path: destino. payload: { node } (fila, columna o elemento copiado)
 */
export function applyComposerOp(data: ComposerData, op: ComposerOp, path: string, payload: Record<string, any> = {}): OpResult {
  const rows = cloneRows(data);
  const base: ComposerData = { ...(data || {}), rows };
  const p = path ? parseComposerPath(path) : null;
  if (path && !p) fail(`Ruta no válida: ${path}`);

  switch (op) {
    case 'add_row': {
      const row: ComposerRow = payload.row ? withFreshIds(payload.row) : createRow(Array.isArray(payload.spans) && payload.spans.length ? payload.spans.map((s: any) => clampSpan(s)) : [12]);
      const at = p ? (payload.position === 'before' ? p.row : p.row + 1) : rows.length;
      const i = clampIndex(at, rows.length);
      rows.splice(i, 0, row);
      return { data: base, path: rowPath(i) };
    }

    case 'add_column': {
      if (!p) fail('add_column necesita una fila o columna.');
      const row = rows[p.row];
      if (!row) fail('Fila inexistente.');
      if (row.columns.length >= 12) fail('Una fila admite máximo 12 columnas.');
      const wasEven = evenlySplit(row.columns);
      const at = p.kind === 'row' ? row.columns.length : p.col + 1;
      const col = createColumn(payload.span ? normalizeSpan(payload.span) : 6);
      const cols = [...row.columns];
      cols.splice(clampIndex(at, cols.length), 0, col);
      rows[p.row] = { ...row, columns: wasEven && !payload.span ? rebalance(cols) : cols };
      return { data: base, path: columnPath(p.row, clampIndex(at, cols.length - 1)) };
    }

    case 'add_element': {
      const el: ComposerElement = payload.element
        ? withFreshIds(payload.element)
        : isElementType(payload.type)
          ? createElement(payload.type, payload.props || {})
          : fail(`Tipo de elemento desconocido: ${String(payload.type)}`);
      if (!p) {
        if (!rows.length) rows.push(createRow([12]));
        const r = rows.length - 1;
        return { data: base, path: insertElement(rows, r, 0, rows[r].columns[0].elements.length, el) };
      }
      if (p.kind === 'row') return { data: base, path: insertElement(rows, p.row, 0, rows[p.row]?.columns?.[0]?.elements.length ?? 0, el) };
      if (p.kind === 'column') return { data: base, path: insertElement(rows, p.row, p.col, rows[p.row]?.columns?.[p.col]?.elements.length ?? 0, el) };
      return { data: base, path: insertElement(rows, p.row, p.col, payload.position === 'before' ? p.el : p.el + 1, el) };
    }

    case 'duplicate': {
      if (!p) fail('duplicate necesita una ruta.');
      const node = getNode(base, p.node);
      if (!node) fail('Nodo inexistente.');
      const copy = withFreshIds(node);
      if (p.kind === 'row') {
        rows.splice(p.row + 1, 0, copy as ComposerRow);
        return { data: base, path: rowPath(p.row + 1) };
      }
      if (p.kind === 'column') {
        const row = rows[p.row];
        if (row.columns.length >= 12) fail('Una fila admite máximo 12 columnas.');
        const cols = [...row.columns];
        cols.splice(p.col + 1, 0, copy as ComposerColumn);
        rows[p.row] = { ...row, columns: evenlySplit(row.columns) ? rebalance(cols) : cols };
        return { data: base, path: columnPath(p.row, p.col + 1) };
      }
      return { data: base, path: insertElement(rows, p.row, p.col, p.el + 1, copy as ComposerElement) };
    }

    case 'remove': {
      if (!p) fail('remove necesita una ruta.');
      if (!getNode(base, p.node)) fail('Nodo inexistente.');
      if (p.kind === 'row') {
        rows.splice(p.row, 1);
        return { data: base, path: rows.length ? rowPath(Math.min(p.row, rows.length - 1)) : null };
      }
      if (p.kind === 'column') {
        const row = rows[p.row];
        if (row.columns.length <= 1) {
          rows.splice(p.row, 1);
          return { data: base, path: null };
        }
        const wasEven = evenlySplit(row.columns);
        const cols = row.columns.filter((_, i) => i !== p.col);
        rows[p.row] = { ...row, columns: wasEven ? rebalance(cols) : cols };
        return { data: base, path: columnPath(p.row, Math.min(p.col, cols.length - 1)) };
      }
      const col = rows[p.row].columns[p.col];
      col.elements.splice(p.el, 1);
      return { data: base, path: col.elements.length ? elementPath(p.row, p.col, Math.min(p.el, col.elements.length - 1)) : columnPath(p.row, p.col) };
    }

    case 'move_up':
    case 'move_down': {
      if (!p) fail(`${op} necesita una ruta.`);
      const d = op === 'move_up' ? -1 : 1;
      const swap = <T,>(list: T[], i: number): number => {
        const j = i + d;
        if (i < 0 || i >= list.length || j < 0 || j >= list.length) return i;
        [list[i], list[j]] = [list[j], list[i]];
        return j;
      };
      if (p.kind === 'row') return { data: base, path: rowPath(swap(rows, p.row)) };
      if (p.kind === 'column') {
        const row = rows[p.row];
        const cols = [...row.columns];
        const j = swap(cols, p.col);
        rows[p.row] = { ...row, columns: cols };
        return { data: base, path: columnPath(p.row, j) };
      }
      const els = rows[p.row]?.columns?.[p.col]?.elements;
      if (!els) fail('Columna inexistente.');
      return { data: base, path: elementPath(p.row, p.col, swap(els, p.el)) };
    }

    case 'move_to': {
      if (!p) fail('move_to necesita una ruta.');
      const t = parseComposerPath(String(payload.targetPath || ''));
      if (!t) fail('move_to necesita payload.targetPath.');
      const node = getNode(base, p.node);
      if (!node) fail('Nodo inexistente.');
      const after = payload.position === 'after';

      if (p.kind === 'element') {
        // Destination column and index computed before removing the source.
        let tr = t.row;
        let tc = t.kind === 'row' ? 0 : t.col;
        const target = rows[tr]?.columns?.[tc];
        if (!target) fail('Columna de destino inexistente.');
        let ti = t.kind === 'element' ? t.el + (after ? 1 : 0) : target.elements.length;
        rows[p.row].columns[p.col].elements.splice(p.el, 1);
        if (tr === p.row && tc === p.col && p.el < ti) ti -= 1;
        return { data: base, path: insertElement(rows, tr, tc, ti, node as ComposerElement) };
      }

      if (p.kind === 'column') {
        const tr = t.row;
        if (!rows[tr]) fail('Fila de destino inexistente.');
        let ti = t.kind === 'row' ? rows[tr].columns.length : t.col + (after ? 1 : 0);
        if (tr !== p.row && rows[tr].columns.length >= 12) fail('Una fila admite máximo 12 columnas.');
        const src = rows[p.row];
        const srcCols = src.columns.filter((_, i) => i !== p.col);
        let removedRow = false;
        if (!srcCols.length) {
          rows.splice(p.row, 1);
          removedRow = true;
        } else rows[p.row] = { ...src, columns: srcCols };
        let r2 = removedRow && p.row < tr ? tr - 1 : tr;
        if (r2 === p.row && !removedRow && p.col < ti) ti -= 1;
        const dest = rows[r2];
        const cols = [...dest.columns];
        ti = clampIndex(ti, cols.length);
        cols.splice(ti, 0, node as ComposerColumn);
        rows[r2] = { ...dest, columns: cols };
        return { data: base, path: columnPath(r2, ti) };
      }

      let ti = t.row + (after ? 1 : 0);
      rows.splice(p.row, 1);
      if (p.row < ti) ti -= 1;
      ti = clampIndex(ti, rows.length);
      rows.splice(ti, 0, node as ComposerRow);
      return { data: base, path: rowPath(ti) };
    }

    case 'set_span': {
      if (!p || p.kind !== 'column') fail('set_span necesita una columna.');
      const col = rows[p.row]?.columns?.[p.col];
      if (!col) fail('Columna inexistente.');
      const cur = normalizeSpan(col.span);
      let patch: Partial<ComposerSpan> = {};
      if (payload.span && typeof payload.span === 'object') patch = payload.span;
      else if (typeof payload.span === 'number') patch = { desktop: payload.span };
      else if (payload.breakpoint) patch = { [payload.breakpoint]: payload.value } as any;
      const next: ComposerSpan = { ...cur };
      for (const bp of ['desktop', 'tablet', 'mobile'] as const) if (patch[bp] !== undefined) next[bp] = clampSpan(patch[bp]);
      rows[p.row].columns[p.col] = { ...col, span: next };
      return { data: base, path: p.node };
    }

    case 'wrap_in_row': {
      if (!p || p.kind === 'row') fail('wrap_in_row necesita un elemento o columna.');
      const node = getNode(base, p.node);
      if (!node) fail('Nodo inexistente.');
      const src = rows[p.row];
      let newRow: ComposerRow;
      if (p.kind === 'element') {
        src.columns[p.col].elements.splice(p.el, 1);
        newRow = createRow([12]);
        newRow.columns[0].elements.push(node as ComposerElement);
        newRow.style = { ...(src.style || {}) };
      } else {
        if (src.columns.length <= 1) return { data: base, path: p.node };
        rows[p.row] = { ...src, columns: src.columns.filter((_, i) => i !== p.col) };
        newRow = createRow([12], [{ ...(node as ComposerColumn), span: { desktop: 12, tablet: 12, mobile: 12 } }]);
      }
      rows.splice(p.row + 1, 0, newRow);
      return { data: base, path: p.kind === 'element' ? elementPath(p.row + 1, 0, 0) : columnPath(p.row + 1, 0) };
    }

    case 'update': {
      if (!p) fail('update necesita una ruta.');
      const node: any = getNode(base, p.node);
      if (!node) fail('Nodo inexistente.');
      let next: any;
      if (p.rest) next = setPath(node, p.rest, payload.value);
      else {
        next = { ...node };
        if (payload.props) next.props = { ...(node.props || {}), ...payload.props };
        if (payload.style) {
          const style = { ...(node.style || {}), ...payload.style };
          for (const [k, v] of Object.entries(style)) if (v === null || v === undefined) delete style[k];
          next.style = style;
        }
        if (payload.span && p.kind === 'column') next.span = normalizeSpan({ ...normalizeSpan(node.span), ...payload.span });
      }
      if (p.kind === 'row') rows[p.row] = next;
      else if (p.kind === 'column') rows[p.row].columns[p.col] = next;
      else rows[p.row].columns[p.col].elements[p.el] = next;
      return { data: base, path: p.node };
    }

    case 'paste': {
      const node = payload.node;
      const kind = nodeKindOf(node);
      if (!kind) fail('Nada que pegar.');
      const copy = withFreshIds(node);
      if (kind === 'row') {
        const at = p ? p.row + 1 : rows.length;
        rows.splice(at, 0, copy);
        return { data: base, path: rowPath(at) };
      }
      if (kind === 'column') {
        if (!p) {
          rows.push(createRow([12], [{ ...copy, span: { desktop: 12, tablet: 12, mobile: 12 } }]));
          return { data: base, path: columnPath(rows.length - 1, 0) };
        }
        const row = rows[p.row];
        if (row.columns.length >= 12) fail('Una fila admite máximo 12 columnas.');
        const at = p.kind === 'row' ? row.columns.length : p.col + 1;
        const cols = [...row.columns];
        cols.splice(at, 0, copy);
        rows[p.row] = { ...row, columns: cols };
        return { data: base, path: columnPath(p.row, at) };
      }
      return applyComposerOp(base, 'add_element', p ? p.node : '', { element: copy });
    }

    default:
      fail(`Operación desconocida: ${String(op)}`);
  }
}

export const COMPOSER_OPS: ComposerOp[] = [
  'add_row',
  'add_column',
  'add_element',
  'duplicate',
  'remove',
  'move_up',
  'move_down',
  'move_to',
  'set_span',
  'wrap_in_row',
  'update',
  'paste',
];
