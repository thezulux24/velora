'use client';

/**
 * Capa React del SDK (Next.js App Router compatible: todo es componente cliente, seguro en SSR).
 * Los atributos §8.1 se emiten siempre; la edición solo existe con ?builder=1 dentro del portal.
 *
 *   // app/layout.tsx (Server Component)
 *   const initial = await fetchDelivery({ slug: 'demo' });
 *   <CmsProvider initial={initial} slug="demo">{children}</CmsProvider>
 *
 *   // components/Site.tsx ('use client')
 *   <CmsPage pageSlug="/" registry={{ hero: Hero, 'faq.accordion': Faq }} />
 *
 *   function Hero() {
 *     return <CmsContainer><CmsText f="headline" as="h1" /><CmsImage f="image" /><CmsLink f="primaryCta" /></CmsContainer>;
 *   }
 *
 * Nota: las re-exportaciones son nombradas a propósito (Next no admite `export *` en un límite 'use client').
 */

export { useCms, useOptionalCms, useCurrentSection, CmsContext, SectionContext, PathContext, ItemContext } from './react/context.js';
export type { CmsContextValue, CmsActions, SectionScope, ItemScope } from './react/context.js';
export { CmsProvider, CmsDesignSystem, useLivePreview } from './react/provider.js';
export type { LivePreviewOptions } from './react/provider.js';
export {
  CmsSection,
  CmsPage,
  CmsAddSection,
  cmsSectionProps,
  useSection,
  useSections,
  defaultRegistry,
  registerBlock,
  resolveBlockComponent,
} from './react/section.js';
export type { CmsSectionProps, CmsPageProps, CmsRegistry, CmsBlockComponent, CmsBlockProps } from './react/section.js';
export { CmsText, CmsRichText, CmsImage, CmsGallery, CmsLink, CmsList, CmsField, CmsContainer, useElementId, useFieldPath } from './react/primitives.js';
export type { CmsTextProps, CmsRichTextProps, CmsImageProps, CmsGalleryProps, CmsLinkProps, CmsListProps, CmsListHelpers, CmsFieldProps } from './react/primitives.js';
export {
  CmsItem,
  CmsItemText,
  CmsItemImage,
  CmsAddItem,
  CmsGlobalText,
  CmsGlobalImage,
  CmsNav,
  CmsNavLink,
  CmsNavText,
  useNavLinks,
  useGlobal,
  useProducts,
  useProduct,
  useItem,
  useItemRoute,
  useCollectionQuery,
} from './react/data.js';
export type { CmsItemTextProps, CmsItemImageProps, CmsGlobalTextProps, CmsNavLinkProps, NavList, UseCollectionQuery } from './react/data.js';
export { ElementStudio, parseColorToHexAndAlpha, hexAndAlphaToRgba } from './react/studio.js';
export { ShopAccountProvider, useShopAccount, useOptionalShopAccount } from './react/shop.js';
export type { ShopAccountValue, ShopAccountProviderProps } from './react/shop.js';
