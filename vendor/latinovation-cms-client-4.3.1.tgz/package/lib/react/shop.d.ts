import React from 'react';
import { type ShopAuthResult, type ShopClient, type ShopClientOptions, type ShopCustomer, type ShopError, type ShopRegisterInput } from '../shop.js';
export interface ShopAccountValue {
    /** Cliente con sesión, o null si no hay (o se venció). */
    customer: ShopCustomer | null;
    /** true mientras se valida el token guardado (también en el primer render, para que SSR e hidratación coincidan). */
    loading: boolean;
    /** Último error de refresh() (los de login/register se lanzan al llamador). */
    error: ShopError | null;
    login(input: {
        email: string;
        password: string;
    }): Promise<ShopCustomer>;
    register(input: ShopRegisterInput): Promise<ShopAuthResult & {
        claimedOrders: string[];
    }>;
    /** Cierra la sesión en este navegador. */
    logout(): void;
    /** Vuelve a leer /me (p. ej. tras editar el perfil o las direcciones). */
    refresh(): Promise<ShopCustomer | null>;
    client: ShopClient;
}
export type ShopAccountProviderProps = {
    children?: React.ReactNode;
} & ({
    client: ShopClient;
    slug?: never;
    apiUrl?: never;
    storage?: never;
    fetch?: never;
} | ({
    client?: undefined;
} & ShopClientOptions));
/**
 * Sesión de cliente de la tienda para storefronts React / Next.js ('use client').
 *
 *   <ShopAccountProvider slug="arsenal">{children}</ShopAccountProvider>
 *   const { customer, loading, login, logout } = useShopAccount();
 */
export declare function ShopAccountProvider(props: ShopAccountProviderProps): React.JSX.Element;
/** Sesión del cliente de la tienda. Requiere <ShopAccountProvider>. */
export declare function useShopAccount(): ShopAccountValue;
/** Igual que useShopAccount() pero devuelve null fuera del provider. */
export declare function useOptionalShopAccount(): ShopAccountValue | null;
