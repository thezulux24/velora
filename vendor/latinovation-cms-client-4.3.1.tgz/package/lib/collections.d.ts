import type { CollectionItem, DeliveryPayload } from './types.js';
import { type FetchDeliveryOptions } from './delivery.js';
/**
 * Colecciones dinámicas (docs/EDITING-V4.1.md §C.1): rutas de detalle, búsqueda, filtros,
 * orden y paginación sobre las colecciones que ya trae delivery (sin pedir nada más al servidor).
 */
export interface ItemRouteOptions {
    /** Patrón explícito: "/producto/:slug" (también `:id`). Tiene prioridad sobre `routeBase`. */
    pattern?: string;
    /** Prefijo del sitio (p. ej. "/site/demo"). */
    basePath?: string;
}
/**
 * Ruta de detalle de un ítem: `collectionDefinitions[col].routeBase + '/' + slug`, o el `pattern`.
 * `undefined` si la colección no tiene páginas de detalle.
 */
export declare function getItemRoute(p: DeliveryPayload | null | undefined, collection: string, item: Pick<CollectionItem, 'slug' | 'id'> | string, opts?: ItemRouteOptions): string | undefined;
/** Inverso de getItemRoute: qué colección/ítem corresponde a una ruta (`/blog/mi-post`). */
export declare function matchItemRoute(p: DeliveryPayload | null | undefined, pathname: string): {
    collection: string;
    slug: string;
    item?: CollectionItem;
} | undefined;
export type FilterValue = string | number | boolean | string[] | {
    min?: number;
    max?: number;
} | null | undefined;
export interface CollectionQuery {
    /** Slug de la colección (por defecto, la de tienda). */
    collection?: string;
    /** `{ category: 'Proteínas', price: { min: 0, max: 90000 }, isFeatured: true, tags: ['vegano'] }`. */
    filters?: Record<string, FilterValue>;
    /** "price:asc", "createdAt:desc", "title" (asc). Por defecto `listDefaults.sort` o el orden del CMS. */
    sort?: string;
    /** Página (desde 1). */
    page?: number;
    /** Por defecto `listDefaults.pageSize` o todo. */
    pageSize?: number;
    /** Busca en título y en todos los campos de texto. */
    search?: string;
    /** Incluir ítems no publicados (solo llegan en preview). */
    includeUnpublished?: boolean;
}
export interface FacetOption {
    value: string;
    count: number;
}
export interface CollectionFacet {
    field: string;
    type: string;
    label?: string;
    /** select: opciones con conteo (sobre el resultado sin ese filtro). */
    options?: FacetOption[];
    /** range: mínimo y máximo disponibles. */
    min?: number;
    max?: number;
    /** boolean: ítems con valor verdadero. */
    count?: number;
}
export interface CollectionQueryResult<T = CollectionItem> {
    collection: string | undefined;
    items: T[];
    total: number;
    page: number;
    pageSize: number;
    pageCount: number;
    facets: CollectionFacet[];
}
/** Aplica búsqueda, filtros, orden y paginación. Puro: úsalo en servidor o cliente. */
export declare function queryCollection<T extends CollectionItem = CollectionItem>(p: DeliveryPayload | null | undefined, q?: CollectionQuery): CollectionQueryResult<T>;
/** Ítem por slug o id. */
export declare function getItem(p: DeliveryPayload | null | undefined, collection: string, slugOrId: string): CollectionItem | undefined;
/** URL de `GET /api/v1/delivery/:slug/collections/:col/:itemSlug` (ítem publicado individual, §C.1). */
export declare function itemDeliveryUrl(opts: Pick<FetchDeliveryOptions, 'slug' | 'baseUrl'> & {
    collection: string;
    item: string;
}): string;
/** Descarga un ítem individual (útil para rutas de detalle sin bajar todo el sitio). Devuelve null si no existe. */
export declare function fetchItem(opts: Pick<FetchDeliveryOptions, 'slug' | 'baseUrl' | 'fetch' | 'revalidate' | 'tags' | 'init'> & {
    collection: string;
    item: string;
}): Promise<CollectionItem | null>;
