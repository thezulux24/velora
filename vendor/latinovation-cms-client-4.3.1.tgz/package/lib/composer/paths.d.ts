import type { ComposerColumn, ComposerData, ComposerElement, ComposerOp, ComposerRow } from './types.js';
/**
 * Rutas del compositor (las mismas que usa el lienzo en INLINE_FIELD_CHANGE y FOCUS_FIELD):
 *
 *   rows.0                               fila
 *   rows.0.columns.1                     columna
 *   rows.0.columns.1.elements.2          elemento
 *   rows.0.columns.1.elements.2.props.text   campo de un elemento
 */
export type NodeKind = 'row' | 'column' | 'element';
export interface ParsedPath {
    kind: NodeKind;
    row: number;
    col: number;
    el: number;
    /** Lo que sigue al nodo (`props.text`), vacío si la ruta apunta al nodo. */
    rest: string;
    /** Ruta del nodo sin `rest`. */
    node: string;
}
export declare function parseComposerPath(path: string): ParsedPath | null;
export declare const rowPath: (r: number) => string;
export declare const columnPath: (r: number, c: number) => string;
export declare const elementPath: (r: number, c: number, e: number) => string;
export declare function getPath(obj: any, path: string): any;
/** Asignación inmutable por ruta con puntos (los segmentos numéricos indexan arrays). */
export declare function setPath<T>(obj: T, path: string, value: unknown): T;
/** Nodo (fila, columna o elemento) en la ruta, o undefined. */
export declare function getNode(data: ComposerData, path: string): ComposerRow | ComposerColumn | ComposerElement | undefined;
/** Busca la ruta de un nodo por id. */
export declare function findPathById(data: ComposerData, id: string): string | null;
export interface OpResult {
    data: ComposerData;
    /** Ruta del nodo afectado o creado (para mantener la selección). */
    path: string | null;
}
export declare class ComposerOpError extends Error {
}
/**
 * Aplica una operación del compositor (mismas `op` que COMPOSER_ACTION). Es pura: devuelve datos nuevos.
 *
 * - `add_row`      path: fila de referencia o '' (al final). payload: { spans?, row?, position?: 'before'|'after' }
 * - `add_column`   path: fila (al final) o columna (después). payload: { span? }
 * - `add_element`  path: columna (al final), elemento (después; position 'before' para antes) o fila (1.ª columna).
 *                  payload: { type, props?, element? }
 * - `duplicate`, `remove`, `move_up`, `move_down`  path: cualquier nodo
 * - `move_to`      path: nodo origen. payload: { targetPath, position?: 'before'|'after' }
 *                  elemento → columna (al final) o elemento (antes); columna → fila o columna; fila → fila
 * - `set_span`     path: columna. payload: { span: { desktop?, tablet?, mobile? } } o { breakpoint, value }
 * - `wrap_in_row`  path: elemento o columna → lo saca a una fila nueva debajo de su fila
 * - `update`       path: nodo. payload: { props?, style?, span? } (se fusionan) o path con campo + { value }
 * - `paste`        path: destino. payload: { node } (fila, columna o elemento copiado)
 */
export declare function applyComposerOp(data: ComposerData, op: ComposerOp, path: string, payload?: Record<string, any>): OpResult;
export declare const COMPOSER_OPS: ComposerOp[];
