/** CSS minificado (sin comentarios ni espacios redundantes). */
export declare const COMPOSER_CSS: string;
