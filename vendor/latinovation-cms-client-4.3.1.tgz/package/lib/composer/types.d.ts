/**
 * Compositor libre (`layout.composer`, docs/EDITING-V4.1.md §B).
 *
 * Una sección se arma con filas → columnas (12 columnas, ancho por dispositivo) → elementos.
 * Todo es flujo (sin coordenadas absolutas), así que se ve bien en cualquier pantalla.
 */
export type ComposerElementType = 'heading' | 'text' | 'richtext' | 'image' | 'button' | 'buttons' | 'spacer' | 'divider' | 'video' | 'embed' | 'icon' | 'list' | 'badge' | 'stat' | 'quote' | 'form' | 'collection' | 'map' | 'gallery' | 'card';
export type Breakpoint = 'desktop' | 'tablet' | 'mobile';
export interface ComposerSpan {
    desktop: number;
    tablet?: number;
    mobile?: number;
}
export interface ComposerElementStyle {
    align?: '' | 'left' | 'center' | 'right';
    color?: string;
    background?: string;
    /** Tamaño de letra: token (`sm|md|lg|xl|2xl`) o valor CSS (`18px`, `1.25rem`). */
    fontSize?: string;
    weight?: '' | '300' | '400' | '500' | '600' | '700' | '800';
    marginTop?: number;
    marginBottom?: number;
    padding?: number;
    radius?: number;
    /** `''`, `narrow` (40ch), `medium` (60ch) o un valor CSS (`480px`). */
    maxWidth?: string;
    hideOnMobile?: boolean;
    hideOnDesktop?: boolean;
}
export interface ComposerElement<P extends Record<string, any> = Record<string, any>> {
    id: string;
    type: ComposerElementType;
    props: P;
    style?: ComposerElementStyle;
}
export interface ComposerColumnStyle {
    align?: '' | 'start' | 'center' | 'end';
    /** Alineación vertical dentro de la fila. */
    valign?: '' | 'start' | 'center' | 'end' | 'stretch';
    background?: string;
    color?: string;
    padding?: number;
    radius?: number;
    border?: boolean;
    gap?: number;
    hideOnMobile?: boolean;
    hideOnDesktop?: boolean;
}
export interface ComposerColumn {
    id: string;
    span: ComposerSpan;
    style?: ComposerColumnStyle;
    elements: ComposerElement[];
}
export interface ComposerRowStyle {
    gap?: number;
    align?: '' | 'start' | 'center' | 'end' | 'stretch';
    justify?: '' | 'start' | 'center' | 'end' | 'between';
    reverseOnMobile?: boolean;
    background?: string;
    color?: string;
    /** Relleno interno en px (número) o valor CSS. */
    padding?: number | string;
    radius?: number;
    marginBottom?: number;
    hideOnMobile?: boolean;
    hideOnDesktop?: boolean;
}
export interface ComposerRow {
    id: string;
    style?: ComposerRowStyle;
    columns: ComposerColumn[];
}
export interface ComposerData {
    _block?: 'layout.composer';
    rows: ComposerRow[];
    /** Ancho del contenido: `narrow | standard | wide | full`. */
    width?: string;
    /** Espaciado vertical de la sección: `none | sm | md | lg`. */
    spacing?: string;
    tone?: string;
    anchor?: string;
    [extra: string]: any;
}
export type ComposerOp = 'add_row' | 'add_column' | 'add_element' | 'duplicate' | 'remove' | 'move_up' | 'move_down' | 'move_to' | 'set_span' | 'wrap_in_row' | 'update' | 'paste';
/** Mensaje `COMPOSER_ACTION` (sitio → portal). */
export interface ComposerActionMessage {
    sectionKey: string;
    sectionId: string;
    op: ComposerOp;
    path: string;
    payload?: Record<string, any>;
}
/** Definición de un campo editable (misma forma que los campos del catálogo de bloques). */
export interface ComposerFieldDef {
    key: string;
    type: 'text' | 'textarea' | 'richtext' | 'image' | 'gallery' | 'number' | 'boolean' | 'select' | 'color' | 'link' | 'array' | 'collection';
    label: string;
    help?: string;
    placeholder?: string;
    options?: Array<{
        value: string;
        label: string;
    }>;
    fields?: ComposerFieldDef[];
    min?: number;
    max?: number;
    step?: number;
    /** Arrays: sub-campo que nombra cada fila y sustantivo singular para «Añadir …». */
    labelField?: string;
    singular?: string;
    /** `link` plano: el valor vive en props.label / props.href / props.newTab. */
    flat?: boolean;
    /** Siempre tiene valor (los selectores no muestran «Sin definir»). */
    required?: boolean;
    /** Solo se muestra si otro prop tiene uno de estos valores. */
    showIf?: {
        key: string;
        in: any[];
    };
}
export interface ComposerElementDef {
    type: ComposerElementType;
    label: string;
    /** Nombre del ícono (ver icons.tsx). */
    icon: string;
    group: 'basic' | 'media' | 'layout' | 'data';
    description: string;
    defaults: () => Record<string, any>;
    fields: ComposerFieldDef[];
    /** Props de texto editables en línea en el lienzo. */
    inline?: string[];
}
