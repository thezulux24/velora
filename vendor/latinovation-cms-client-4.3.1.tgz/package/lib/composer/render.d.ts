/**
 * Renderer de referencia del compositor (`layout.composer`). Lo usan los sitios headless con el SDK
 * y el renderer del CMS (copia generada en frontend/src/sdk-generated/composer), así ambos pintan
 * exactamente el mismo HTML.
 *
 *   <Composer data={section.data} sectionKey="intro" sectionId="…" host={{ projectSlug: 'mi-sitio' }} />
 *
 * En el editor (`host.isBuilder`) cada elemento se selecciona, los textos se editan en línea y una
 * barra flotante permite duplicar, borrar, mover y arrastrar entre columnas. Todo se comunica al
 * portal con `CMS_CANVAS_ACTION` (INLINE_FIELD_CHANGE, FOCUS_FIELD, COMPOSER_ACTION).
 */
import React from 'react';
import type { ComposerData } from './types.js';
export interface ResolvedHref {
    href: string;
    external?: boolean;
    onClick?: (e: React.MouseEvent) => void;
}
export interface LeadSubmission {
    fullName: string;
    email: string;
    phone: string;
    message: string;
    formName: string;
    /** Identificador del formulario (el backend valida contra el formulario publicado con ese id). */
    formId: string;
    payload: Record<string, unknown>;
    sourcePage: string;
    sourceSection?: string;
    website: string;
}
/** Lo que el sitio anfitrión (CMS o headless) le presta al compositor. */
export interface ComposerHost {
    /** Dentro del iframe del portal con ?builder=1. */
    isBuilder?: boolean;
    projectSlug?: string;
    /** Origen del CMS para formularios (por defecto https://webproai.tech). */
    apiBase?: string;
    /** Ítems publicados por colección (payload de delivery). */
    collections?: Record<string, any[]>;
    collectionDefinitions?: Record<string, any>;
    /** Número de WhatsApp del sitio para enlaces `whatsapp:`. */
    whatsappNumber?: string;
    /** Prefijo de rutas internas (`/site/<slug>` en el host de la plataforma). */
    basePath?: string;
    /** Resuelve hrefs especiales (`whatsapp:`, `cart:`, rutas). Por defecto `resolveComposerHref`. */
    resolveHref?: (href: string) => ResolvedHref;
    /** URL de detalle de un ítem de colección (o null si no tiene). */
    itemHref?: (item: any, collectionSlug: string) => string | null;
    /** Clic en un ítem (el CMS abre el detalle en un panel). */
    onItemClick?: (item: any, collectionSlug: string, e: React.MouseEvent) => void;
    /** Redimensiona imágenes de CDN (`url`, ancho) y su srcset. */
    imageUrl?: (url: string, width: number) => string;
    imageSrcSet?: (url: string) => string | undefined;
    formatPrice?: (value: unknown) => string;
    /** Envía `CMS_CANVAS_ACTION` al portal. Sin esto, el editor no emite nada. */
    emit?: (action: string, payload: Record<string, unknown>) => void;
    /** Reemplaza el envío del formulario (por defecto POST /api/public/leads/:slug). */
    submitLead?: (lead: LeadSubmission) => Promise<void>;
    /** Formulario publicado del sitio (`form.custom` o un formulario de compositor) por su formId. */
    findForm?: (formId: string) => LinkedForm | null;
}
export interface LinkedForm {
    formId: string;
    fields: any[];
    submitLabel?: string;
    successMessage?: string;
    redirectTo?: string;
}
/** Normaliza un identificador de formulario igual que el backend (`Contacto Obra` → `contacto-obra`). */
export declare function formIdOf(v: unknown): string;
/**
 * Formularios definidos en las páginas de un payload de delivery: secciones `form.custom` y elementos
 * `form` (modo «aquí») de compositores. Útil para `host.findForm`.
 */
export declare function formsFromPayload(payload: any): Record<string, LinkedForm>;
export interface ComposerProps {
    data: Partial<ComposerData> | Record<string, any>;
    sectionKey: string;
    sectionId?: string;
    host?: ComposerHost;
    className?: string;
    style?: React.CSSProperties;
    /** Etiqueta raíz (por defecto `div`; usa `section` si no hay otro contenedor de sección). */
    as?: any;
    /** Incluye la hoja de estilos del compositor (desactívala si pones <ComposerStyles/> una vez). */
    styles?: boolean;
    id?: string;
}
/** Resolución por defecto de enlaces del compositor. */
export declare function resolveComposerHref(href: string, opts?: {
    basePath?: string;
    whatsappNumber?: string;
}): ResolvedHref;
/** YouTube / Vimeo → URL embebible; null para archivos directos o enlaces desconocidos. */
export declare function videoEmbedUrl(url: string): string | null;
export declare function safeEmbedUrl(url: string): string | null;
/** Hoja de estilos del compositor (inclúyela una vez si renderizas con `styles={false}`). */
export declare function ComposerStyles(): React.JSX.Element;
export declare function Composer({ data, sectionKey, sectionId, host, className, style, as: Tag, styles, id }: ComposerProps): React.JSX.Element;
