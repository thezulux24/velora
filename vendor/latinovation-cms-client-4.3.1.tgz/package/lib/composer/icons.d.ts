import React from 'react';
export declare const COMPOSER_ICON_NAMES: string[];
export declare function hasComposerIcon(name: string | undefined | null): boolean;
export declare function ComposerIcon({ name, size, strokeWidth, className, label, }: {
    name: string;
    size?: number;
    strokeWidth?: number;
    className?: string;
    /** Si se da, el ícono es informativo (role="img"); si no, decorativo (aria-hidden). */
    label?: string;
}): React.JSX.Element | null;
