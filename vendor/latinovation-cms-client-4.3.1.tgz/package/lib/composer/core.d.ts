/**
 * Núcleo puro del compositor (sin React): modelo, catálogo de elementos, rutas y operaciones,
 * validación y markdown. Úsalo en agentes, CLI, backend o tests.
 *
 *   import { applyComposerOp, validateComposer } from '@latinovation/cms-client/composer/core';
 */
export * from './types.js';
export * from './model.js';
export * from './paths.js';
export * from './markdown.js';
