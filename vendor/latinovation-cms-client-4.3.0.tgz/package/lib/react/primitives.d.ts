import React from 'react';
import type { CmsSectionRef, FieldType } from '../types.js';
import { type CmsContextValue } from './context.js';
type SectionLike = Pick<CmsSectionRef, 'id' | 'key'> & {
    block?: string | null;
    data: Record<string, any>;
};
/** Ruta absoluta: relativa al repetidor actual; `/items.0.title` es absoluta. */
export declare function useFieldPath(f: string): string;
/** `data-el-id` estable para un elemento propio dentro de la sección actual: `<div {...useElementId('tarjeta')}>`. */
export declare function useElementId(name: string): {
    'data-el-id': string;
};
type Rest = Omit<React.HTMLAttributes<HTMLElement>, 'children'> & Record<string, any>;
export interface CmsTextProps extends Rest {
    /** Ruta del campo (`headline`, `cta.label`, `items.2.title`; relativa dentro de <CmsList>). */
    f: string;
    s?: SectionLike;
    /** Índice de widget (s.data.widgets[widget][f]) — compatibilidad v4.0. */
    widget?: number;
    as?: React.ElementType;
    fallback?: string;
    /** Permite saltos de línea (Enter no confirma). Por defecto true si as="p". */
    multiline?: boolean;
    placeholder?: string;
    /** false: no editable en línea (un clic abre el campo en el inspector). */
    editable?: boolean;
    /** Formato de presentación (p. ej. precio). Con formato el campo se edita desde el inspector. */
    format?: (value: unknown) => string;
}
/**
 * Texto de un campo de sección. Siempre emite `data-cms-field`/`data-cms-type`/`data-el-id`;
 * en el editor es contentEditable y al salir envía INLINE_FIELD_CHANGE con la ruta completa.
 */
export declare function CmsText({ f, s, widget, as: Tag, fallback, multiline, placeholder, editable, format, className, ...rest }: CmsTextProps): React.JSX.Element | null;
export interface CmsRichTextProps extends Rest {
    f: string;
    s?: SectionLike;
    as?: React.ElementType;
    placeholder?: string;
    /** Render propio del Markdown (por defecto el subconjunto seguro del CMS). */
    render?: (markdown: string) => string;
}
/** Markdown como HTML seguro. En el editor, un clic abre el campo en el inspector (FOCUS_FIELD richtext). */
export declare function CmsRichText({ f, s, as: Tag, placeholder, render, className, ...rest }: CmsRichTextProps): React.JSX.Element | null;
export interface CmsImageProps extends Omit<React.ImgHTMLAttributes<HTMLImageElement>, 'src' | 'alt'> {
    f: string;
    s?: SectionLike;
    /** Texto alternativo si no hay `<campo>Alt`. */
    alt?: string;
    /** Componente de imagen propio (p. ej. `next/image`): recibe src, alt, style y los atributos de marcado. */
    as?: React.ElementType;
    priority?: boolean;
    /** Resolver URLs relativas (`/uploads/…`) contra el CMS. Por defecto true. */
    absolute?: boolean;
    emptyLabel?: string;
}
/** Imagen con compañeros `<campo>Alt` y `<campo>Focal` (§8.4). En el editor: "Cambiar imagen" → FOCUS_FIELD image. */
export declare function CmsImage({ f, s, alt, as: Img, priority, absolute, emptyLabel, style, className, ...rest }: CmsImageProps): React.JSX.Element | null;
export interface CmsGalleryProps extends Rest {
    f: string;
    s?: SectionLike;
    as?: React.ElementType;
    /** Render de cada imagen (por defecto `<img>`). */
    renderImage?: (img: {
        url: string;
        alt: string;
    }, index: number) => React.ReactNode;
    imageClassName?: string;
}
/** Galería (lista de URLs). En el editor, un clic abre la mediateca (FOCUS_FIELD gallery). */
export declare function CmsGallery({ f, s, as: Tag, renderImage, imageClassName, className, ...rest }: CmsGalleryProps): React.JSX.Element | null;
export interface CmsLinkProps extends Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, 'href'> {
    /** Campo `link` ({label, href, newTab}). */
    f?: string;
    /** Alternativa con campos planos: `labelField="ctaText" hrefField="ctaHref"`. */
    labelField?: string;
    hrefField?: string;
    s?: SectionLike;
    as?: React.ElementType;
    fallbackLabel?: string;
    /** Contenido propio en lugar de la etiqueta editable. */
    children?: React.ReactNode;
}
/** Enlace/botón. Etiqueta editable en línea; botón 🔗 en el editor → FOCUS_FIELD link (editor de enlace). */
export declare function CmsLink({ f, labelField, hrefField, s, as: A, fallbackLabel, children, className, target, rel, ...rest }: CmsLinkProps): React.JSX.Element | null;
export interface CmsListHelpers {
    /** Ruta del elemento (`items.2`). */
    path: string;
    index: number;
    isFirst: boolean;
    isLast: boolean;
    /** Atributos de marcado del elemento (si `wrap={false}`, espárcelos en tu raíz). */
    attrs: Record<string, string | undefined>;
    /** Mini barra del editor (si `wrap={false}`, renderízala dentro de tu raíz). */
    toolbar: React.ReactNode;
}
export interface CmsListProps<T = any> extends Rest {
    f: string;
    s?: SectionLike;
    as?: React.ElementType;
    itemAs?: React.ElementType;
    itemClassName?: string | ((item: T, index: number) => string | undefined);
    /** false: no envuelve cada elemento; usa `helpers.attrs` y `helpers.toolbar`. */
    wrap?: boolean;
    renderItem: (item: T, index: number, helpers: CmsListHelpers) => React.ReactNode;
    /** Contenido público cuando la lista está vacía (por defecto nada). */
    empty?: React.ReactNode;
    addLabel?: string;
    /** Máximo de elementos (oculta "agregar" al llegar). */
    max?: number;
}
/**
 * Repetidor (`items`, `plans`, `columns.0.links`…). Cada elemento lleva `data-cms-field="<ruta>.<i>"`
 * y, en el editor, mini barra agregar/duplicar/quitar/subir/bajar (ARRAY_ITEM_ACTION). Los campos
 * dentro de `renderItem` usan rutas relativas: `<CmsText f="title" />` → `items.2.title`.
 */
export declare function CmsList<T = any>({ f, s, as: Tag, itemAs: ItemTag, itemClassName, wrap, renderItem, empty, addLabel, max, className, ...rest }: CmsListProps<T>): React.JSX.Element | null;
export interface CmsFieldProps extends Rest {
    f: string;
    s?: SectionLike;
    /** Tipo explícito; si falta, el del catálogo del bloque o el inferido del valor. */
    type?: FieldType;
    as?: React.ElementType;
}
/** Despacha al primitivo según el tipo del campo (text/textarea/richtext/image/gallery/link; el resto se muestra como texto y abre el inspector). */
export declare function CmsField({ f, s, type, as, ...rest }: CmsFieldProps): React.JSX.Element | null;
/** Contenedor que respeta `_style.contentWidth`/`maxWidth` de la sección (`data-cms-container`). */
export declare function CmsContainer({ as: Tag, children, ...rest }: Rest & {
    as?: React.ElementType;
    children?: React.ReactNode;
}): React.JSX.Element;
export type { CmsContextValue };
