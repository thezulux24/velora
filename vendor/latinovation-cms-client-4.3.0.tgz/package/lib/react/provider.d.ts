import React from 'react';
import type { DeliveryPayload } from '../types.js';
import { type CmsContextValue } from './context.js';
export interface LivePreviewOptions {
    /** Slug del proyecto en el CMS. */
    slug: string;
    /** URL del CMS (por defecto https://webproai.tech). Su origen es el único aceptado en postMessage. */
    cmsUrl?: string;
    /** Página del CMS que se muestra ('/', '/producto'…). Si falta, se deduce de `pathname`. */
    pageSlug?: string;
    /** Ruta actual del sitio (p. ej. `usePathname()` de Next); se traduce con `pageSlugFromPath`. */
    pathname?: string;
    /** Prefijo del sitio a quitar de la ruta (p. ej. "/site/demo"). */
    basePath?: string;
    /** Token de vista previa (si no, se lee de `?previewToken=`). */
    previewToken?: string;
    /** Orígenes extra del portal (ej. http://localhost:3005). */
    allowedOrigins?: string[];
    /** Registrar una visita (POST /api/public/analytics/:slug/track) fuera del editor. Por defecto true. */
    trackPageview?: boolean;
    /** Emitir `--cms-*` del design system, fuentes y `globalCss`. Por defecto true. */
    designSystem?: boolean;
    /** Barra de estilos por elemento en el editor. Por defecto true. */
    elementStudio?: boolean;
    fetch?: typeof fetch;
}
/** Estado del sitio con vista previa en vivo. Úsalo directo o vía <CmsProvider>. */
export declare function useLivePreview(initial: DeliveryPayload, opts: LivePreviewOptions): CmsContextValue;
/** `--cms-*` del design system, enlaces de Google Fonts, `@font-face` propios y `globalCss` saneado. */
export declare function CmsDesignSystem({ global }: {
    global: Record<string, any> | undefined;
}): React.JSX.Element;
export declare function CmsProvider({ initial, children, ...opts }: LivePreviewOptions & {
    initial: DeliveryPayload;
    children: React.ReactNode;
}): React.JSX.Element;
