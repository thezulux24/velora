import React from 'react';
export declare function parseColorToHexAndAlpha(colorStr: string): {
    hex: string;
    alpha: number;
};
export declare function hexAndAlphaToRgba(hex: string, alphaPercent: number): string;
/**
 * Barra flotante del elemento seleccionado (como ElementStudioToolbar del CMS): fondo y opacidad,
 * color de texto, posición, mover libremente, caja padre, Art y restablecer.
 */
export declare function ElementStudio(): React.JSX.Element | null;
