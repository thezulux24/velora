import React from 'react';
import type { CmsSectionRef, SectionData } from '../types.js';
import { type CmsContextValue } from './context.js';
/** `useSection('hero')` (página activa) o `useSection('/producto', 'detalle')`. */
export declare function useSection<T extends SectionData = SectionData>(pageOrKey: string, key?: string): CmsSectionRef<T>;
/** Secciones visibles y ordenadas de una página (por defecto la activa). */
export declare function useSections(pageSlug?: string, opts?: {
    includeHidden?: boolean;
}): CmsSectionRef[];
type SectionLike = Pick<CmsSectionRef, 'id' | 'key'> & {
    block?: string | null;
    data?: SectionData;
    name?: string;
};
/**
 * Atributos para que el portal encuentre, resalte y seleccione una sección en tu propio elemento:
 * `<section {...cmsSectionProps(s, cms)}>`. (La selección la hace el runtime del lienzo.)
 */
export declare function cmsSectionProps(s: SectionLike, _ctx?: Pick<CmsContextValue, 'isBuilder' | 'selectSection'>): {
    'data-cms-section': string;
};
export interface CmsSectionProps extends Omit<React.HTMLAttributes<HTMLElement>, 'children'> {
    /** Sección (de useSection / getSections). Alias: `section`. */
    s?: SectionLike;
    section?: SectionLike;
    as?: React.ElementType;
    label?: string;
    /** Posición en la página (para habilitar subir/bajar). Si falta se calcula. */
    index?: number;
    total?: number;
    /** Ocultar la barra del editor (p. ej. en cabeceras fijas). */
    toolbar?: boolean;
    children?: React.ReactNode;
}
/**
 * Raíz de sección: `id="cms-section-<key>"`, `data-section-key/-id/-block`, CSS de `_style`,
 * `_elementStyles` y `_customCss`, ancla `_style.anchorId`, ocultar por dispositivo y, en el
 * editor, barra con arrastrar, subir, bajar, duplicar, eliminar, agregar bloque después y Art.
 */
export declare function CmsSection({ s: sProp, section: sectionProp, as: Tag, id, className, label, index, total, toolbar, style, children, ...rest }: CmsSectionProps): React.JSX.Element;
/** Botón del editor para insertar una sección (al final de la página o después de `afterSectionId`). */
export declare function CmsAddSection({ afterSectionId, label }: {
    afterSectionId?: string;
    label?: string;
}): React.JSX.Element | null;
export interface CmsBlockProps<T extends SectionData = SectionData> {
    section: CmsSectionRef<T>;
    data: T;
    index: number;
    pageSlug: string;
}
export type CmsBlockComponent = React.ComponentType<CmsBlockProps<any>>;
/** Clave de sección, tipo de bloque (`hero.split`) o familia (`hero`) → componente. */
export type CmsRegistry = Record<string, CmsBlockComponent | undefined>;
/**
 * Registro global que otros módulos pueden extender (p. ej. el compositor:
 * `defaultRegistry['layout.composer'] = ComposerBlock`). <CmsPage> lo consulta después de su `registry`.
 */
export declare const defaultRegistry: CmsRegistry;
export declare function registerBlock(type: string, component: CmsBlockComponent): void;
/** Componente para una sección: clave → bloque → familia del bloque, en `registry` y luego en `defaultRegistry`. */
export declare function resolveBlockComponent(section: Pick<CmsSectionRef, 'key' | 'block'>, registry?: CmsRegistry, fallback?: CmsBlockComponent): CmsBlockComponent | undefined;
export interface CmsPageProps {
    /** Página del CMS ('/', '/servicios', '/producto'…). Por defecto la activa. */
    pageSlug?: string;
    registry?: CmsRegistry;
    /** Para secciones sin componente registrado. Sin fallback: placeholder en el editor, nada en público. */
    fallback?: CmsBlockComponent;
    /** Elemento raíz de cada sección (por defecto `section`). */
    sectionAs?: React.ElementType;
    sectionClassName?: string | ((s: CmsSectionRef) => string | undefined);
    /** Mostrar el botón "Agregar sección" al final en el editor. Por defecto true. */
    addSection?: boolean;
}
/** Renderiza las secciones visibles de la página en el orden del CMS, cada una envuelta en <CmsSection>. */
export declare function CmsPage({ pageSlug, registry, fallback, sectionAs, sectionClassName, addSection }: CmsPageProps): React.JSX.Element;
export {};
