/**
 * Compositor conectado a <CmsProvider> (sitios headless).
 *
 *   // Con <CmsPage>: importar este módulo registra `layout.composer` en defaultRegistry.
 *   import '@latinovation/cms-client/composer/react';
 *   <CmsPage pageSlug="/" registry={{ hero: Hero }} />
 *
 *   // Sección suelta:
 *   const s = useSection('intro');
 *   <CmsComposer s={s} />
 *
 * Toma colecciones, WhatsApp, medios y el modo editor del provider; en el portal emite las mismas
 * acciones que el renderer del CMS (INLINE_FIELD_CHANGE, FOCUS_FIELD, COMPOSER_ACTION).
 */
import React from 'react';
import { type CmsBlockProps } from '../react.js';
import { type ComposerHost } from './render.js';
type SectionLike = {
    id: string;
    key: string;
    data: Record<string, any>;
    isVisible?: boolean;
    block?: string | null;
};
/** Host del compositor a partir del provider (sobrescribible con `host`). */
export declare function useComposerHost(host?: Partial<ComposerHost>, apiBase?: string): ComposerHost;
/** Componente de bloque para <CmsPage> (ya va envuelto en <CmsSection>). */
export declare function ComposerBlock({ section, data }: CmsBlockProps): React.JSX.Element;
/** Sección de compositor independiente (incluye <CmsSection> para selección y anclas). */
export declare function CmsComposer({ s, host, apiBase, className, styles, }: {
    s: SectionLike;
    host?: Partial<ComposerHost>;
    /** Origen del CMS para los formularios (por defecto el `cmsUrl` del provider). */
    apiBase?: string;
    className?: string;
    styles?: boolean;
}): React.JSX.Element | null;
/** Registra `layout.composer` en el defaultRegistry del SDK (idempotente). */
export declare function registerComposer(): void;
export {};
