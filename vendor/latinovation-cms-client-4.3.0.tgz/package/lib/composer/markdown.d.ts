/**
 * Markdown mínimo y seguro para el elemento «Texto con formato»: párrafos, ## / ### títulos,
 * listas (- y 1.), citas (>), **negrita**, *cursiva*, `código` y [enlaces](url).
 * Todo el texto se escapa antes de aplicar formato; los enlaces solo aceptan esquemas seguros.
 */
export declare function escapeHtml(s: string): string;
export declare function markdownToHtml(md: string): string;
