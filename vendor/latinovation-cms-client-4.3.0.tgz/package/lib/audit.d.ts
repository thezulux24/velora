import type { DeliveryPayload, SectionData } from './types.js';
/**
 * Auditoría de editabilidad (docs/LIVE-PREVIEW.md §8.5): compara cada campo con valor de cada
 * sección visible (y globales, navegación e ítems de colecciones que se muestran) contra el
 * marcado §8.1 del HTML público. Sin dependencias: incluye un tokenizador HTML pequeño.
 */
export interface HtmlMarks {
    /** Por clave de sección: rutas marcadas con `data-cms-field` (fuera de ítems) y su tipo. */
    sections: Record<string, {
        id?: string;
        block?: string;
        fields: Map<string, string>;
    }>;
    /** `data-cms-global`. */
    globals: Set<string>;
    /** `data-cms-nav`. */
    nav: Set<string>;
    /** `coleccion:itemId` → campos marcados. */
    items: Map<string, Set<string>>;
    /** Texto visible normalizado (sin script/style). */
    text: string;
    /** Valores de `src`/`srcset`/`poster`/`href` de imágenes y medios. */
    media: string[];
    /** Total de elementos con `data-el-id` en el HTML del servidor. */
    elementIds: number;
}
export declare function decodeEntities(s: string): string;
export declare function parseAttrs(src: string): Record<string, string>;
export declare function normalizeText(s: string): string;
/** Recorre el HTML y extrae el marcado §8.1, el texto visible y las URLs de medios. */
export declare function collectMarks(html: string): HtmlMarks;
/** Claves de configuración que no son contenido visible (no cuentan en la cobertura). */
export declare const DEFAULT_IGNORED_KEYS: string[];
export interface ExpectedField {
    path: string;
    type: string;
    value: string;
    /** Ítems referenciados (`reference`): `coleccion:id`. */
    refs?: string[];
}
/** Campos con valor que una sección debería exponer en el lienzo. */
export declare function expectedSectionFields(data: SectionData, block: string | null | undefined, p?: DeliveryPayload | null, ignore?: string[]): ExpectedField[];
export interface FieldResult extends ExpectedField {
    covered: boolean;
    /** El valor aparece en el HTML pero sin marcado (visible y no editable desde el lienzo). */
    shownUnmarked?: boolean;
}
export interface UnitReport {
    page: string;
    path: string;
    /** Clave de sección, o `[global]`, `[nav]`, `[items:<coleccion>]`. */
    unit: string;
    block?: string | null;
    rendered: boolean;
    total: number;
    covered: number;
    pct: number;
    fields: FieldResult[];
}
export interface AuditPageInput {
    /** Ruta pedida (`/`, `/producto/creatina`). */
    path: string;
    /** Página del CMS que corresponde. */
    pageSlug: string;
    html: string;
    /** Si no se pudo descargar. */
    error?: string;
}
export interface AuditOptions {
    ignore?: string[];
    /** Incluir globales, navegación e ítems (por defecto true). */
    extras?: boolean;
}
export interface AuditReport {
    units: UnitReport[];
    pages: Array<{
        path: string;
        pageSlug: string;
        error?: string;
        total: number;
        covered: number;
        pct: number;
    }>;
    total: number;
    covered: number;
    pct: number;
}
/** Calcula la cobertura de editabilidad. Puro: el CLI descarga el HTML y llama a esta función. */
export declare function auditEditability(payload: DeliveryPayload, pages: AuditPageInput[], opts?: AuditOptions): AuditReport;
/** Tabla de texto para la terminal. */
export declare function formatAuditTable(r: AuditReport, { maxMissing }?: {
    maxMissing?: number | undefined;
}): string;
