import type { FieldType } from './types.js';
/**
 * Atributos de marcado del contrato §8.1 (docs/LIVE-PREVIEW.md). Se emiten siempre — también en
 * producción — para que el portal y la auditoría de editabilidad los lean del HTML. La
 * interactividad (contentEditable, toolbars, listeners) solo existe en modo editor.
 */
export type CmsAttrs = Record<string, string | undefined>;
/** Tipo de `data-cms-type`. Además de los del catálogo, el SDK usa `array` (repetidor) e `item` (elemento de un repetidor). */
export type MarkupType = FieldType | 'item';
export interface EditAttrsInput {
    /** Ruta del campo (`headline`, `items.2.title`). */
    field?: string;
    type?: MarkupType | string;
    /** Ítem de colección: `{ collection, id }` o `"coleccion:itemId"`. */
    item?: {
        collection: string;
        id: string;
    } | string;
    /** Campo de `globalData`. */
    global?: string;
    /** Navegación: índice de `headerLinks` (`2`), `footer.<i>`, `promoBanner.<campo>` o un campo plano (`headerCtaText`). */
    nav?: number | string;
    /** Id estable para estilos por elemento (`_elementStyles`). */
    elId?: string;
}
/** `{ 'data-cms-field': 'items.2.title', 'data-cms-type': 'text', … }` sin claves vacías. */
export declare function editAttrs(input: EditAttrsInput): CmsAttrs;
export interface SectionAttrsInput {
    id: string;
    key: string;
    block?: string | null;
}
/** Raíz de sección: `data-section-key`, `data-section-id`, `data-cms-block` e `id="cms-section-<key>"`. */
export declare function sectionAttrs(s: SectionAttrsInput, { withId }?: {
    withId?: boolean | undefined;
}): CmsAttrs;
export declare function sectionDomId(key: string): string;
/** Id de elemento estable derivado de la sección y del campo: `hero::headline`. */
export declare function elementId(sectionKey: string, name: string): string;
/** Interpreta `data-cms-item="coleccion:itemId"`. */
export declare function parseItemAttr(v: string | null | undefined): {
    collection: string;
    id: string;
} | null;
export type NavTarget = {
    kind: 'link';
    list: 'header' | 'footer';
    index: number;
} | {
    kind: 'promo';
    field: string;
} | {
    kind: 'field';
    field: string;
};
/** Interpreta `data-cms-nav`: `"2"`, `"footer.1"`, `"promoBanner.title"`, `"headerCtaText"`. */
export declare function parseNavAttr(v: string | null | undefined): NavTarget | null;
/** Tipos que se editan en línea (contentEditable) en vez de abrir el inspector. */
export declare const INLINE_TYPES: Set<string>;
