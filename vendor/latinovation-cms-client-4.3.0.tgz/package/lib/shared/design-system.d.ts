// GENERADO desde shared/src/design-system.d.mts por scripts/sync-shared.mjs. No editar a mano.
// Types for design-system.mjs (Design System v2, docs/EDITING-V4.1.md §A).

export type FontSource = 'google' | 'custom' | 'system';
export type FontCategory = 'serif' | 'sans-serif' | 'display' | 'handwriting' | 'monospace';

export interface FontRef {
  family: string;
  source?: FontSource;
  weights?: number[];
  category?: FontCategory;
  url?: string;
}

export interface CustomFont {
  family: string;
  url: string;
  weight?: number;
  style?: 'normal' | 'italic';
}

export interface DesignColors {
  background?: string;
  surface?: string;
  surfaceAlt?: string;
  /** Text on `surface` (legacy `cardText`); derived when absent. */
  surfaceText?: string;
  text?: string;
  muted?: string;
  border?: string;
  primary?: string;
  primaryText?: string;
  secondary?: string;
  secondaryText?: string;
  accent?: string;
  success?: string;
  danger?: string;
  custom?: Array<{ name: string; value: string }>;
}

export interface DesignSystemV2 {
  version: 2;
  name?: string;
  preset?: string;
  mode?: 'light' | 'dark';
  colors?: DesignColors;
  typography?: {
    headingFont?: FontRef;
    bodyFont?: FontRef;
    baseSize?: number;
    scaleRatio?: number;
    headingWeight?: number;
    bodyWeight?: number;
    headingCase?: 'none' | 'uppercase' | 'capitalize';
    headingTracking?: number;
    bodyLineHeight?: number;
    customFonts?: CustomFont[];
  };
  shape?: { radiusSm?: number; radiusMd?: number; radiusLg?: number; radiusFull?: number; borderWidth?: number };
  shadow?: { sm?: string; md?: string; lg?: string };
  spacing?: { sectionY?: number; sectionYMobile?: number; gutter?: number; maxWidth?: number; density?: 'compact' | 'comfortable' | 'airy' };
  buttons?: {
    style?: 'solid' | 'outline' | 'soft' | 'link';
    shape?: 'square' | 'rounded' | 'pill';
    case?: 'none' | 'uppercase';
    weight?: number;
    paddingY?: number;
    paddingX?: number;
  };
  motion?: { level?: 'none' | 'subtle' | 'expressive'; durationMs?: number };
  header?: { variant?: 'simple' | 'centered' | 'split' | 'minimal'; sticky?: boolean; transparentOnHero?: boolean; showSearch?: boolean; showCart?: boolean };
  footer?: { variant?: 'columns' | 'simple' | 'big'; showNewsletter?: boolean };
  globalCss?: string;
}

type Required2<T> = { [K in keyof T]-?: T[K] extends object ? (T[K] extends any[] ? T[K] : Required2<T[K]>) : T[K] };
export type ResolvedDesignSystem = Required2<Omit<DesignSystemV2, 'name' | 'preset'>> & { name?: string; preset?: string };

export interface ContrastPair {
  id: string;
  label: string;
  fg: string;
  bg: string;
  ratio: number;
  min: number;
  level: 'AAA' | 'AA' | 'AA-large' | 'fail';
  pass: boolean;
}

export interface DesignPreset {
  id: string;
  label: string;
  description: string;
  designSystem: DesignSystemV2;
}

export const DESIGN_SYSTEM_VERSION: 2;
export const DEFAULT_DESIGN_SYSTEM: Readonly<ResolvedDesignSystem>;
export const COLOR_ROLES: Array<{ key: keyof DesignColors; var: string; label: string }>;
export const LEGACY_KEYS: string[];
export const CSS_VAR_NAMES: string[];
export const DESIGN_PRESETS: DesignPreset[];

export function parseColor(input: unknown): [number, number, number] | null;
export function isColor(v: unknown): v is string;
export function toHex(rgb: [number, number, number] | number[]): string;
export function normalizeHex(v: unknown): string | null;
export function relativeLuminance(color: string | number[]): number;
export function contrastRatio(a: string, b: string): number;
export function mixColors(a: string, b: string, weightOfA: number): string;
export function readableOn(bg: string, candidates: string[], min?: number): string;
export function colorSlug(name: string): string;
export function isSerifFont(name: string): boolean;
export function fontCategory(name: string): FontCategory;
export function fontStack(family: string, category?: FontCategory): string;

export function normalizeDesignSystem(ds: unknown): DesignSystemV2;
export function resolveDesignSystem(ds: unknown): ResolvedDesignSystem;
export function hasToken(normalized: DesignSystemV2, path: string): boolean;
export function designSystemToCssVars(ds: unknown): Record<string, string>;
export function designSystemToCss(ds: unknown, scope?: string): string;
export function designSystemFontLinks(ds: unknown): string[];
export function designSystemFontFaceCss(ds: unknown): string;
export function designSystemFontFaces(ds: unknown): string;
export function designSystemGlobalCss(ds: unknown): string;
export function contrastReport(ds: unknown): ContrastPair[];
export function sanitizeGlobalCss(css: unknown): { css: string; errors: string[]; valid: boolean };
export function applyPreset(current: unknown, presetId: string): DesignSystemV2;
